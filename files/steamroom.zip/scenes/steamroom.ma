//Maya ASCII 2023 scene
//Name: steamroom.ma
//Last modified: Thu, Aug 03, 2023 07:00:16 PM
//Codeset: 1252
requires maya "2023";
requires "stereoCamera" "10.0";
requires -nodeType "rmanVolumeAggregateSet" "rfm_volume_aggregate_set.py" "1.0";
requires -nodeType "PxrColorCorrect" -nodeType "PxrDispScalarLayer" -nodeType "PxrManifold2D"
		 -nodeType "PxrTexture" -nodeType "PxrToFloat" -nodeType "d_openexr" -nodeType "PxrCamera"
		 -nodeType "PxrDefault" -nodeType "PxrDirectLighting" -nodeType "PxrDiskLight" -nodeType "PxrDisplace"
		 -nodeType "PxrOcclusion" -nodeType "PxrPathTracer" -nodeType "PxrRectLight" -nodeType "PxrSphereLight"
		 -nodeType "PxrSurface" -nodeType "PxrUnified" -nodeType "PxrVCM" -nodeType "PxrVisualizer"
		 -nodeType "PxrVolume" -nodeType "rmanBakingGlobals" -nodeType "rmanDisplay" -nodeType "rmanDisplayChannel"
		 -nodeType "rmanGlobals" "RenderMan_for_Maya.py" "25.2 @ 2282507";
requires -nodeType "aiOptions" -nodeType "aiAOVDriver" -nodeType "aiAOVFilter" "mtoa" "5.2.1.1";
currentUnit -l centimeter -a degree -t film;
fileInfo "application" "maya";
fileInfo "product" "Maya 2023";
fileInfo "version" "2023";
fileInfo "cutIdentifier" "202211021031-847a9f9623";
fileInfo "osv" "Windows 10 Pro v2009 (Build: 19045)";
fileInfo "UUID" "D0615958-4A93-6DCC-F9C0-AC9AB8239AB8";
createNode transform -s -n "persp";
	rename -uid "F492F46B-469B-54EA-6BD4-1AB39DEF6666";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 17.374516556216385 24.197726494412329 16.938904717728832 ;
	setAttr ".r" -type "double3" -16.856351401852375 38.696017521233166 1.0187896182186067e-15 ;
	setAttr ".rp" -type "double3" 1.3322676295501878e-15 -1.7763568394002505e-15 0 ;
	setAttr ".rpt" -type "double3" 3.4731183197068433e-15 5.4560914764329844e-15 3.7674788614753857e-15 ;
createNode camera -s -n "perspShape" -p "persp";
	rename -uid "A151738F-4102-2129-42A9-7F9800057204";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".fl" 34.999999999999993;
	setAttr ".coi" 34.136561652473958;
	setAttr ".imn" -type "string" "persp";
	setAttr ".den" -type "string" "persp_depth";
	setAttr ".man" -type "string" "persp_mask";
	setAttr ".tp" -type "double3" -11.174351484249909 6.9999999548636698 3.3749997375385812 ;
	setAttr ".hc" -type "string" "viewSet -p %camera";
createNode transform -n "render";
	rename -uid "AA712396-4BF5-AD48-295B-4B856DD4EB21";
	setAttr ".t" -type "double3" 1843.9661103075523 1517.4526668587155 1843.9661103075616 ;
	setAttr -l on ".tx";
	setAttr -l on ".ty";
	setAttr -l on ".tz";
	setAttr ".r" -type "double3" -29.999999999999996 44.999999999999964 0 ;
	setAttr -l on ".rx";
	setAttr -l on ".ry";
	setAttr -l on ".rz";
	setAttr ".rp" -type "double3" 2.6645352591003757e-15 -1.7763568394002505e-15 -7.1054273576010019e-15 ;
	setAttr ".rpt" -type "double3" -3.4449595677802187e-15 -4.5040129953348484e-15 2.5567811480800951e-15 ;
createNode camera -n "renderShape" -p "render";
	rename -uid "B339513F-4C35-3AD3-356C-CF839D8867D0";
	setAttr -k off ".v";
	setAttr ".ovr" 1.3;
	setAttr ".fl" 2062.5948183047158;
	setAttr ".ncp" 50;
	setAttr ".fcp" 150000;
	setAttr -l on ".coi" 601.0972659169089;
	setAttr -l on ".ow" 67.186550775674306;
	setAttr ".imn" -type "string" "persp1";
	setAttr ".den" -type "string" "persp1_depth";
	setAttr ".man" -type "string" "persp1_mask";
	setAttr ".tp" -type "double3" 0.50000024068123317 12.500000247302237 0.50000042911515052 ;
	setAttr ".hc" -type "string" "viewSet -p %camera";
	setAttr ".dr" yes;
	setAttr ".rman_enableCameraProjection" yes;
createNode transform -s -n "top";
	rename -uid "249FA75D-4C8D-9654-D2F5-718E48CFA21F";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 0.50000011920928955 2119.0724189359707 -8.0022232772787625 ;
	setAttr ".r" -type "double3" -90 0 0 ;
createNode camera -s -n "topShape" -p "top";
	rename -uid "59BD0D4F-400C-9ACE-60F1-93B5273C7D29";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 2099.8692880947156;
	setAttr ".ow" 20.704930205094186;
	setAttr ".imn" -type "string" "top";
	setAttr ".den" -type "string" "top_depth";
	setAttr ".man" -type "string" "top_mask";
	setAttr ".tp" -type "double3" 0.50000011920928955 19.203130841255188 -8.0022232772787625 ;
	setAttr ".hc" -type "string" "viewSet -t %camera";
	setAttr ".o" yes;
createNode transform -s -n "front";
	rename -uid "CBBCC251-48D3-5422-9076-B59B841805BD";
	setAttr ".v" no;
	setAttr ".t" -type "double3" -4.9275252556230722 21.636583674926573 1002.8009828534654 ;
createNode camera -s -n "frontShape" -p "front";
	rename -uid "32867BFA-4D73-85EE-02E0-A895E69E96C1";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 1002.2635495932335;
	setAttr ".ow" 26.495578509772926;
	setAttr ".imn" -type "string" "front";
	setAttr ".den" -type "string" "front_depth";
	setAttr ".man" -type "string" "front_mask";
	setAttr ".tp" -type "double3" 0.49726063719527502 17.940159799122441 0.53743326023186722 ;
	setAttr ".hc" -type "string" "viewSet -f %camera";
	setAttr ".o" yes;
createNode transform -s -n "side";
	rename -uid "54F73FA3-479A-F0A0-90D7-A28EF2111772";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 1000.1261860399577 6.2497912413056573 3.2129840697723133 ;
	setAttr ".r" -type "double3" 0 90 0 ;
createNode camera -s -n "sideShape" -p "side";
	rename -uid "59599FF4-453F-A2B2-B0B3-4E9AC1DC0BC2";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 1011.3018403882583;
	setAttr ".ow" 9.3726790946752949;
	setAttr ".imn" -type "string" "side";
	setAttr ".den" -type "string" "side_depth";
	setAttr ".man" -type "string" "side_mask";
	setAttr ".tp" -type "double3" -11.175654348300586 6.067475223330181 5.5513381523023817 ;
	setAttr ".hc" -type "string" "viewSet -s %camera";
	setAttr ".o" yes;
createNode transform -n "PxrDiskLight";
	rename -uid "B51874A7-4001-B717-6E16-F0ADEBB50084";
	setAttr ".t" -type "double3" -6.9999995231628418 19.203130722045898 -10.999155751923555 ;
	setAttr ".r" -type "double3" 0 179.99999999999994 0 ;
	setAttr ".s" -type "double3" 1.4070402677325666 1.4070402677325666 1.4070402677325666 ;
createNode PxrDiskLight -n "PxrDiskLightShape" -p "PxrDiskLight";
	rename -uid "6F734F9A-46B1-F045-76B1-C195A7D9AEBD";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 8;
	setAttr ".lightColor" -type "float3" 0.18113856 0.23904081 0.88372844 ;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 6500;
	setAttr ".emissionFocus" 5;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 90;
	setAttr ".coneSoftness" 0;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" yes;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 0.18113856 0.23904081 0.88372844 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrDiskLight1";
	rename -uid "49656EB3-42AD-82A4-72F1-AAADE240B615";
	setAttr ".t" -type "double3" 8 19.203130722045898 -10.999155751923555 ;
	setAttr ".r" -type "double3" 0 179.99999999999994 0 ;
	setAttr ".s" -type "double3" 1.4070402677325666 1.4070402677325666 1.4070402677325666 ;
createNode PxrDiskLight -n "PxrDiskLight1Shape" -p "PxrDiskLight1";
	rename -uid "5F30E122-4129-74FC-D27E-92883E498751";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 8;
	setAttr ".lightColor" -type "float3" 0.18113856 0.23904081 0.88372844 ;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 6500;
	setAttr ".emissionFocus" 5;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 90;
	setAttr ".coneSoftness" 0;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" yes;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 0.18113856 0.23904081 0.88372844 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrSphereLight";
	rename -uid "C8A39BF3-4584-0B7D-9955-1EB08A1386D9";
	setAttr ".t" -type "double3" -21.997516631951012 15.357317498153632 -9.6014286485181906 ;
	setAttr ".s" -type "double3" 18.974478305683817 18.974478305683817 18.974478305683817 ;
createNode PxrSphereLight -n "PxrSphereLightShape" -p "PxrSphereLight";
	rename -uid "A14DC2FE-4AA4-7481-3A0E-9BBEE8B1270D";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 0;
	setAttr ".lightColor" -type "float3" 0.84316224 0.97655267 0.99641359 ;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 9000;
	setAttr ".emissionFocus" 0;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 90;
	setAttr ".coneSoftness" 0;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" no;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 0.84316224 0.97655267 0.99641359 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrRectLight";
	rename -uid "A739DA1C-429D-A700-8723-F3A4061BF2D5";
	setAttr ".t" -type "double3" -15.593755215866402 8.1815208314183003 6.3692802994383904 ;
	setAttr ".r" -type "double3" 0 -50.016199202661099 0 ;
	setAttr ".s" -type "double3" 8.3854631217361142 11.686748914716068 8.6707104285196301 ;
createNode PxrRectLight -n "PxrRectLightShape" -p "PxrRectLight";
	rename -uid "549D7D8F-49AC-78B2-65AA-77A9306B5583";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 3;
	setAttr ".lightColor" -type "float3" 0.70574552 0.92252606 0.99302047 ;
	setAttr ".lightColorMap" -type "string" "";
	setAttr ".colorMapGamma" -type "float3" 1 1 1 ;
	setAttr ".colorMapSaturation" 1;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 6500;
	setAttr ".emissionFocus" 3.1099998950958252;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 90;
	setAttr ".coneSoftness" 0;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" no;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 0.70574552 0.92252606 0.99302047 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrRectLight1";
	rename -uid "2552C9BC-4E57-6F13-A7A3-8F9AAF1CDA96";
	setAttr ".t" -type "double3" -10.442029091802439 3.1927018613303195 3.7310159602522894 ;
	setAttr ".r" -type "double3" 0 -90 0 ;
	setAttr ".s" -type "double3" 4.5929654257900276 4.303834473874268 5.9066699364880222 ;
createNode PxrRectLight -n "PxrRectLight1Shape" -p "PxrRectLight1";
	rename -uid "D33A31AD-445F-0979-90EE-A0A7EA1D2067";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 1;
	setAttr ".lightColor" -type "float3" 1 1 1 ;
	setAttr ".lightColorMap" -type "string" "";
	setAttr ".colorMapGamma" -type "float3" 1 1 1 ;
	setAttr ".colorMapSaturation" 1;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 5000;
	setAttr ".emissionFocus" 0;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 70.096153259277344;
	setAttr ".coneSoftness" 0.67788463830947876;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" yes;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 1 1 1 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrRectLight2";
	rename -uid "63916A61-497F-622D-9ECF-3B9EE6C1E41D";
	setAttr ".t" -type "double3" -12.347079105825044 1.9117699985484895 3.2375125611501758 ;
	setAttr ".r" -type "double3" -24.128142818094851 -90.267304370875337 0 ;
	setAttr ".s" -type "double3" 6.8921190690409748 0.57843879029938872 5.9066699364880222 ;
createNode PxrRectLight -n "PxrRectLight2Shape" -p "PxrRectLight2";
	rename -uid "EBBE10E5-41DC-284B-EE9E-E49F13B743BE";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 1.8181818723678589;
	setAttr ".lightColor" -type "float3" 1 1 1 ;
	setAttr ".lightColorMap" -type "string" "";
	setAttr ".colorMapGamma" -type "float3" 1 1 1 ;
	setAttr ".colorMapSaturation" 1;
	setAttr ".enableTemperature" yes;
	setAttr ".temperature" 5000;
	setAttr ".emissionFocus" 0;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 80.480766296386719;
	setAttr ".coneSoftness" 0.66826921701431274;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" no;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 1 1 1 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "PxrRectLight3";
	rename -uid "07D62B76-41AC-8D81-0460-55BBABBB50AF";
	setAttr ".t" -type "double3" 0.49726063719527591 23.844818467285155 0.53743326023186488 ;
	setAttr ".r" -type "double3" -90.000000000000028 0 0 ;
	setAttr ".s" -type "double3" 22.256130308873225 22.256130308873225 22.256130308873225 ;
createNode PxrRectLight -n "PxrRectLight3Shape" -p "PxrRectLight3";
	rename -uid "0699B2C0-488F-FDB3-9662-23B45F71E079";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".isc" no;
	setAttr ".bbx" no;
	setAttr ".icn" -type "string" "";
	setAttr ".vwm" 2;
	setAttr ".tpv" 0;
	setAttr ".uit" 0;
	setAttr -k off ".v" yes;
	setAttr ".io" no;
	setAttr ".tmp" no;
	setAttr ".obcc" -type "float3" 0 0 0 ;
	setAttr ".wfcc" -type "float3" 0 0 0 ;
	setAttr ".uoc" 0;
	setAttr ".oc" 0;
	setAttr ".ovdt" 0;
	setAttr ".ovlod" 0;
	setAttr ".ovs" no;
	setAttr ".ovt" yes;
	setAttr ".ovp" yes;
	setAttr ".ove" yes;
	setAttr ".ovv" yes;
	setAttr ".hpb" no;
	setAttr ".ovrgbf" no;
	setAttr ".ovc" 0;
	setAttr ".ovrgb" -type "float3" 0 0 0 ;
	setAttr ".ovca" 1;
	setAttr ".lodv" yes;
	setAttr ".sech" yes;
	setAttr ".rlid" 0;
	setAttr ".rndr" yes;
	setAttr ".lovc" 0;
	setAttr ".gh" no;
	setAttr ".gm" 0;
	setAttr ".gprf" 3;
	setAttr ".gpof" 3;
	setAttr ".gstp" 1;
	setAttr ".golr" -type "float2" 0.15000001 0.5 ;
	setAttr ".gcp" -type "float3" 0.447 1 1 ;
	setAttr ".gac" -type "float3" 0.87800002 0.67799997 0.66299999 ;
	setAttr ".rt" 0;
	setAttr ".rv" no;
	setAttr ".vf" 1;
	setAttr ".hfm" 1;
	setAttr ".mb" yes;
	setAttr ".vir" no;
	setAttr ".vif" no;
	setAttr ".csh" yes;
	setAttr ".rcsh" yes;
	setAttr ".asbg" no;
	setAttr ".vbo" no;
	setAttr ".mvs" 1;
	setAttr ".gao" no;
	setAttr ".gal" 1;
	setAttr ".sso" no;
	setAttr ".ssa" 1;
	setAttr ".msa" 1;
	setAttr ".vso" no;
	setAttr ".vss" 1;
	setAttr ".dej" no;
	setAttr ".iss" no;
	setAttr ".vis" no;
	setAttr ".tw" no;
	setAttr ".rtw" yes;
	setAttr ".pv" -type "double2" 0 0 ;
	setAttr ".di" no;
	setAttr ".dcol" no;
	setAttr ".dcc" -type "string" "color";
	setAttr ".ih" no;
	setAttr ".ds" yes;
	setAttr ".op" no;
	setAttr ".hot" no;
	setAttr ".smo" yes;
	setAttr ".bbs" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".fbda" yes;
	setAttr ".dsr" 6;
	setAttr ".xsr" 5;
	setAttr ".fth" 0;
	setAttr ".nat" 30;
	setAttr ".dhe" no;
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".intensity" 1;
	setAttr ".exposure" 0;
	setAttr ".lightColor" -type "float3" 0.30491495 0.31468314 0.90347755 ;
	setAttr ".lightColorMap" -type "string" "";
	setAttr ".colorMapGamma" -type "float3" 1 1 1 ;
	setAttr ".colorMapSaturation" 1;
	setAttr ".enableTemperature" no;
	setAttr ".temperature" 6500;
	setAttr ".emissionFocus" 0;
	setAttr ".emissionFocusNormalize" no;
	setAttr ".emissionFocusTint" -type "float3" 0 0 0 ;
	setAttr ".specular" 1;
	setAttr ".diffuse" 1;
	setAttr ".intensityNearDist" 0;
	setAttr ".specularNearDist" 0;
	setAttr ".diffuseNearDist" 0;
	setAttr ".coneAngle" 19.903846740722656;
	setAttr ".coneSoftness" 0.8461538553237915;
	setAttr ".iesProfile" -type "string" "";
	setAttr ".iesProfileScale" 0;
	setAttr ".iesProfileNormalize" no;
	setAttr ".enableShadows" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowDistance" -1;
	setAttr ".shadowFalloff" -1;
	setAttr ".shadowFalloffGamma" 1;
	setAttr ".shadowSubset" -type "string" "";
	setAttr ".shadowExcludeSubset" -type "string" "";
	setAttr ".areaNormalize" no;
	setAttr ".traceLightPaths" no;
	setAttr ".thinShadow" yes;
	setAttr ".visibleInRefractionPath" yes;
	setAttr ".cheapCaustics" no;
	setAttr ".cheapCausticsExcludeGroup" -type "string" "";
	setAttr ".fixedSampleCount" 0;
	setAttr ".lightGroup" -type "string" "";
	setAttr ".importanceMultiplier" 1;
	setAttr ".msApprox" 0;
	setAttr ".msApproxBleed" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".msApproxContribution" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rman__lightfilters[0]" -type "float3"  0 0 0;
	setAttr ".cl" -type "float3" 0.30491495 0.31468314 0.90347755 ;
	setAttr ".ed" yes;
	setAttr ".sn" yes;
	setAttr ".lls" 1;
	setAttr ".de" 2;
	setAttr ".urs" yes;
	setAttr ".col" 5;
	setAttr ".hio" no;
	setAttr ".uocol" no;
	setAttr ".oclr" -type "float3" 0 0 0 ;
	setAttr ".rman_coneAngleDepth" 10;
	setAttr ".rman_coneAngleOpacity" 0.5;
createNode transform -n "room";
	rename -uid "74CBFEDA-4B94-257A-E865-E79FE59DB4B5";
	setAttr ".rp" -type "double3" 0 12 0 ;
	setAttr ".sp" -type "double3" 0 12 0 ;
createNode mesh -n "roomShape" -p "room";
	rename -uid "8C87113E-41CA-2DD0-E420-74B56A9DC444";
	setAttr -k off ".v";
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:422]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 6 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "back";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "f[302]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottom";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 1 "f[303]";
	setAttr ".gtag[2].gtagnm" -type "string" "front";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 1 "f[300]";
	setAttr ".gtag[3].gtagnm" -type "string" "left";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "f[305]";
	setAttr ".gtag[4].gtagnm" -type "string" "right";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "f[304]";
	setAttr ".gtag[5].gtagnm" -type "string" "top";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 1 "f[301]";
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 885 ".uvst[0].uvsp";
	setAttr ".uvst[0].uvsp[0:249]" -type "float2" 0.65501791 0.86333334 0.65134114
		 0.88260782 0.57567054 0.86317891 0.57750899 0.85354167 0.64527762 0.90126944 0.57263881
		 0.87250972 0.63692296 0.91902399 0.56846148 0.881387 0.62640893 0.93559146 0.56320447
		 0.88967073 0.61390138 0.95071048 0.55695069 0.89723027 0.59959751 0.96414268 0.54979879
		 0.90394634 0.58372295 0.97567624 0.54186147 0.90971315 0.56652808 0.98512924 0.53326404
		 0.91443962 0.54828393 0.9923526 0.52414197 0.9180513 0.5292784 0.99723244 0.5146392
		 0.92049122 0.50981104 0.99969172 0.50490552 0.92172086 0.49018902 0.99969172 0.49509451
		 0.92172086 0.47072169 0.99723244 0.48536086 0.92049122 0.45171613 0.9923526 0.47585806
		 0.9180513 0.43347201 0.9851293 0.46673602 0.91443968 0.41627708 0.9756763 0.45813853
		 0.90971315 0.40040249 0.9641428 0.45020124 0.9039464 0.38609865 0.95071054 0.44304931
		 0.89723027 0.37359107 0.93559152 0.43679553 0.88967073 0.36307704 0.91902411 0.43153852
		 0.88138705 0.35472238 0.90126956 0.42736119 0.87250978 0.34865883 0.88260788 0.4243294
		 0.86317897 0.34498203 0.86333334 0.42249101 0.85354173 0.34374994 0.84375006 0.42187497
		 0.84375 0.344982 0.82416677 0.42249101 0.83395839 0.3486588 0.80489224 0.4243294
		 0.82432115 0.35472232 0.78623056 0.42736116 0.81499028 0.36307698 0.76847601 0.43153849
		 0.806113 0.37359098 0.75190854 0.43679547 0.79782927 0.38609853 0.73678946 0.44304925
		 0.79026973 0.4004024 0.72335726 0.45020118 0.7835536 0.41627693 0.7118237 0.45813847
		 0.77778685 0.43347186 0.70237076 0.46673593 0.77306038 0.45171598 0.69514734 0.475858
		 0.76944864 0.47072157 0.69026756 0.48536077 0.76700878 0.4901889 0.68780822 0.49509445
		 0.76577914 0.50981092 0.68780822 0.50490546 0.76577914 0.52927828 0.69026744 0.51463914
		 0.76700872 0.54828387 0.69514728 0.52414191 0.76944864 0.56652796 0.70237064 0.53326398
		 0.77306032 0.58372295 0.71182358 0.54186147 0.77778679 0.59959751 0.72335714 0.54979873
		 0.7835536 0.61390138 0.73678935 0.55695069 0.79026967 0.62640893 0.75190836 0.56320447
		 0.79782915 0.63692296 0.76847577 0.56846148 0.80611289 0.64527768 0.78623033 0.57263881
		 0.81499016 0.65134126 0.80489206 0.5756706 0.82432103 0.65501809 0.82416654 0.57750905
		 0.83395827 0.65625 0.84375 0.578125 0.84375 0.57567054 0.86317891 0.57750899 0.85354167
		 0.57263881 0.87250972 0.56846148 0.881387 0.56320447 0.88967073 0.55695069 0.89723027
		 0.54979879 0.90394634 0.54186147 0.90971315 0.53326404 0.91443962 0.52414197 0.9180513
		 0.5146392 0.92049122 0.50490552 0.92172086 0.49509451 0.92172086 0.48536086 0.92049122
		 0.47585806 0.9180513 0.46673602 0.91443968 0.45813853 0.90971315 0.45020124 0.9039464
		 0.44304931 0.89723027 0.43679553 0.88967073 0.43153852 0.88138705 0.42736119 0.87250978
		 0.4243294 0.86317897 0.42249101 0.85354173 0.42187497 0.84375 0.42249101 0.83395839
		 0.4243294 0.82432115 0.42736116 0.81499028 0.43153849 0.806113 0.43679547 0.79782927
		 0.44304925 0.79026973 0.45020118 0.7835536 0.45813847 0.77778685 0.46673593 0.77306038
		 0.475858 0.76944864 0.48536077 0.76700878 0.49509445 0.76577914 0.50490546 0.76577914
		 0.51463914 0.76700872 0.52414191 0.76944864 0.53326398 0.77306032 0.54186147 0.77778679
		 0.54979873 0.7835536 0.55695069 0.79026967 0.56320447 0.79782915 0.56846148 0.80611289
		 0.57263881 0.81499016 0.5756706 0.82432103 0.57750905 0.83395827 0.578125 0.84375
		 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0
		 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0
		 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1
		 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0
		 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1;
	setAttr ".uvst[0].uvsp[250:499]" 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1
		 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1
		 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0
		 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1
		 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0
		 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0.65501791 0.86333334 0.65134114 0.88260782 0.57567054
		 0.86317891 0.57750899 0.85354167 0.64527762 0.90126944 0.57263881 0.87250972 0.63692296
		 0.91902399 0.56846148 0.881387 0.62640893 0.93559146 0.56320447 0.88967073 0.61390138
		 0.95071048 0.55695069 0.89723027 0.59959751 0.96414268 0.54979879 0.90394634 0.58372295
		 0.97567624 0.54186147 0.90971315 0.56652808 0.98512924 0.53326404 0.91443962 0.54828393
		 0.9923526 0.52414197 0.9180513 0.5292784 0.99723244 0.5146392 0.92049122 0.50981104
		 0.99969172 0.50490552 0.92172086 0.49018902 0.99969172 0.49509451 0.92172086 0.47072169
		 0.99723244 0.48536086 0.92049122 0.45171613 0.9923526 0.47585806 0.9180513 0.43347201
		 0.9851293 0.46673602 0.91443968 0.41627708 0.9756763 0.45813853 0.90971315 0.40040249
		 0.9641428 0.45020124 0.9039464 0.38609865 0.95071054 0.44304931 0.89723027 0.37359107
		 0.93559152 0.43679553 0.88967073 0.36307704 0.91902411 0.43153852 0.88138705 0.35472238
		 0.90126956 0.42736119 0.87250978 0.34865883 0.88260788 0.4243294 0.86317897 0.34498203
		 0.86333334 0.42249101 0.85354173 0.34374994 0.84375006 0.42187497 0.84375 0.344982
		 0.82416677 0.42249101 0.83395839 0.3486588 0.80489224 0.4243294 0.82432115 0.35472232
		 0.78623056 0.42736116 0.81499028 0.36307698 0.76847601 0.43153849 0.806113 0.37359098
		 0.75190854 0.43679547 0.79782927 0.38609853 0.73678946 0.44304925 0.79026973 0.4004024
		 0.72335726 0.45020118 0.7835536 0.41627693 0.7118237 0.45813847 0.77778685 0.43347186
		 0.70237076 0.46673593 0.77306038 0.45171598 0.69514734 0.475858 0.76944864 0.47072157
		 0.69026756 0.48536077 0.76700878 0.4901889 0.68780822 0.49509445 0.76577914 0.50981092
		 0.68780822 0.50490546 0.76577914 0.52927828 0.69026744 0.51463914 0.76700872 0.54828387
		 0.69514728 0.52414191 0.76944864 0.56652796 0.70237064 0.53326398 0.77306032 0.58372295
		 0.71182358 0.54186147 0.77778679 0.59959751 0.72335714 0.54979873 0.7835536 0.61390138
		 0.73678935 0.55695069 0.79026967 0.62640893 0.75190836 0.56320447 0.79782915 0.63692296
		 0.76847577 0.56846148 0.80611289 0.64527768 0.78623033 0.57263881 0.81499016 0.65134126
		 0.80489206 0.5756706 0.82432103 0.65501809 0.82416654 0.57750905 0.83395827 0.65625
		 0.84375 0.578125 0.84375 0.57567054 0.86317891 0.57750899 0.85354167 0.57263881 0.87250972
		 0.56846148 0.881387 0.56320447 0.88967073 0.55695069 0.89723027 0.54979879 0.90394634
		 0.54186147 0.90971315 0.53326404 0.91443962 0.52414197 0.9180513 0.5146392 0.92049122
		 0.50490552 0.92172086 0.49509451 0.92172086 0.48536086 0.92049122 0.47585806 0.9180513
		 0.46673602 0.91443968 0.45813853 0.90971315 0.45020124 0.9039464 0.44304931 0.89723027
		 0.43679553 0.88967073 0.43153852 0.88138705 0.42736119 0.87250978 0.4243294 0.86317897
		 0.42249101 0.85354173 0.42187497 0.84375 0.42249101 0.83395839 0.4243294 0.82432115
		 0.42736116 0.81499028 0.43153849 0.806113 0.43679547 0.79782927 0.44304925 0.79026973
		 0.45020118 0.7835536 0.45813847 0.77778685 0.46673593 0.77306038 0.475858 0.76944864
		 0.48536077 0.76700878 0.49509445 0.76577914 0.50490546 0.76577914 0.51463914 0.76700872
		 0.52414191 0.76944864 0.53326398 0.77306032 0.54186147 0.77778679 0.54979873 0.7835536
		 0.55695069 0.79026967 0.56320447 0.79782915 0.56846148 0.80611289 0.57263881 0.81499016
		 0.5756706 0.82432103 0.57750905 0.83395827 0.578125 0.84375;
	setAttr ".uvst[0].uvsp[500:749]" 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1
		 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1
		 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0
		 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1
		 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0
		 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0
		 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1
		 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0
		 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1
		 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1
		 0 1 0 0 1 0 1 1 0 1 0.375 0 0.40055168 0 0.40055168 0.016751489 0.375 0.016751489
		 0.375 0.47419783 0.375 0.4181484 0.40055168 0.4181484 0.40055168 0.47419783 0.375
		 0.73324847 0.40055168 0.73324847 0.40055168 0.75 0.375 0.75 0.40055168 0.8318516
		 0.375 0.8318516 0.375 0.77580214 0.40055168 0.77580214 0.7931484 0.016751489 0.7931484
		 0 0.8491978 0 0.84919786 0.016751489 0.20685162 0 0.20685162 0.016751485 0.15080217
		 0.016751483 0.15080217 0 0.47536778 0.73324847 0.47536778 0.75 0.47536778 0.8318516
		 0.47536778 0.77580214 0.47536778 0.016751489 0.47536778 0 0.125 0 0.125 0.016751483
		 0.875 0 0.875 0.016751483 0.40055168 0.5 0.47536778 0.4741978 0.47536778 0.5 0.375
		 0.5 0.375 0.13337575 0.40055168 0.13337575 0.40055168 0.21887326 0.375 0.21887326
		 0.15080217 0.13337573 0.20685162 0.13337575 0.20685162 0.21887326 0.15080217 0.21887326
		 0.125 0.13337573 0.125 0.21887326 0.40055168 0.61662424 0.375 0.61662424;
	setAttr ".uvst[0].uvsp[750:884]" 0.375 0.53112674 0.40055168 0.53112674 0.47536778
		 0.61662424 0.47536778 0.53112674 0.84919786 0.13337575 0.875 0.13337573 0.875 0.21887326
		 0.8491978 0.21887326 0.24999999 0.5 0 0.5 0 0.13344887 0.24999999 0.13344887 1 0.13344887
		 1 0.5 0.66666669 0.5 0.66666669 0.13344887 0.47536778 1 0.40055168 1 0.40055168 0.94395053
		 0.47536778 0.94395053 0.375 1 0.375 0.94395053 0.31895053 0.016751487 0.31895053
		 0 0.31895053 0.21887326 0.31895053 0.13337575 0.40055168 0.30604947 0.375 0.30604947
		 0.375 0.25 0.40055168 0.25 1 0.5 0.75 0.5 0.75 0.13344887 1 0.13344887 0.625 0.016751489
		 0.625 0 0.68104947 0 0.68104947 0.016751489 0.40055168 0.88790107 0.47536778 0.88790107
		 0.375 0.88790107 0.26290107 0.016751487 0.26290107 0 0.26290107 0.21887326 0.26290107
		 0.13337575 0.40055168 0.36209893 0.375 0.36209893 0.49999997 0.5 0.49999997 0.13344887
		 0.73709893 0 0.73709893 0.016751489 0.49999997 1 0.24999999 1 0 1 0.66666669 1 1
		 1 1 1 0.75 1 0.49999997 0.5 0.49999997 1 0.75 0.5 0.75 1 0 0.13344887 0.33333337
		 0.13344887 0.33333337 0.5 0 0.5 0.55018389 0.5 0.55018389 0.4741978 0.625 0.47419783
		 0.625 0.5 0.625 0.61662424 0.55018389 0.61662424 0.55018389 0.53112674 0.625 0.53112674
		 0.625 0.73324847 0.55018389 0.73324847 0.55018389 0.75 0.625 0.75 0.625 0.77580214
		 0.55018389 0.77580214 0.625 0.8318516 0.55018389 0.8318516 0.625 0.88790107 0.55018389
		 0.88790107 0.625 0.94395053 0.55018389 0.94395053 0.625 1 0.55018389 1 0.55018389
		 0.016751489 0.55018389 0 0.33333337 1 0 1 0.66666669 0 0.66666669 0.02380687 0.33333337
		 0.02380687 0.33333337 0 1 0 1 0.02380687 0.24999999 0.02380687 0 0.02380687 0 0 0.24999999
		 0 0.49999997 0.02380687 0.49999997 0 0.75 0.02380687 0.75 0 1 0.02380687 1 0 0.375
		 0.24444708 0.40055168 0.24444708 0.31895053 0.25 0.31895053 0.24444708 0.26290107
		 0.25 0.26290107 0.24444708 0.20685162 0.25 0.20685162 0.24444708 0.15080217 0.24444708
		 0.15080217 0.25 0.125 0.24444708 0.125 0.25 0.40055168 0.50555289 0.375 0.50555289
		 0.47536778 0.50555289 0.55018389 0.50555289 0.625 0.50555289 0.8491978 0.24444708
		 0.875 0.24444708 0.875 0.25 0.8491978 0.25 0 0.02380687 0 0 0.66666669 0.02380687
		 0.66666669 0.13344887 0.33333337 0.13344887 0.33333337 0.02380687;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 530 ".vt";
	setAttr ".vt[0:165]"  -6.1991787 19.3042984 -10.90002251 -6.21817303 19.40386963 -10.90002251
		 -6.24949741 19.50027466 -10.90002251 -6.29265738 19.59199524 -10.90002251 -6.34697294 19.67758179 -10.90002251
		 -6.41158676 19.75568771 -10.90002251 -6.48548031 19.82507706 -10.90002251 -6.56748772 19.88466072 -10.90002251
		 -6.65631676 19.93349457 -10.90002251 -6.75056553 19.97080994 -10.90002251 -6.84874821 19.99601936 -10.90002251
		 -6.94931602 20.0087242126 -10.90002251 -7.050683022 20.0087242126 -10.90002251 -7.15125084 19.99601936 -10.90002251
		 -7.24943352 19.97080994 -10.90002251 -7.34368229 19.93349457 -10.90002251 -7.43251133 19.88465881 -10.90002251
		 -7.51451874 19.82507706 -10.90002251 -7.58841228 19.75568771 -10.90002251 -7.6530261 19.67758179 -10.90002251
		 -7.70734119 19.59199524 -10.90002251 -7.75050163 19.50027466 -10.90002251 -7.78182554 19.40386963 -10.90002251
		 -7.80081987 19.3042984 -10.90002251 -7.8071847 19.20313072 -10.90002251 -7.80081987 19.10196304 -10.90002251
		 -7.78182554 19.0023918152 -10.90002251 -7.75050116 18.90598679 -10.90002251 -7.70734119 18.8142662 -10.90002251
		 -7.6530261 18.72867966 -10.90002251 -7.58841228 18.65057373 -10.90002251 -7.51451874 18.58118439 -10.90002251
		 -7.43251085 18.52160263 -10.90002251 -7.34368229 18.47276688 -10.90002251 -7.24943352 18.43545151 -10.90002251
		 -7.15125084 18.41024399 -10.90002251 -7.050683022 18.39753914 -10.90002251 -6.94931602 18.39753914 -10.90002251
		 -6.84874821 18.41024399 -10.90002251 -6.75056553 18.43545151 -10.90002251 -6.65631676 18.47276878 -10.90002251
		 -6.56748819 18.52160263 -10.90002251 -6.48548031 18.58118439 -10.90002251 -6.41158676 18.65057373 -10.90002251
		 -6.34697342 18.72867966 -10.90002251 -6.29265833 18.8142662 -10.90002251 -6.24949789 18.90598679 -10.90002251
		 -6.21817398 19.0023918152 -10.90002251 -6.19917965 19.10196304 -10.90002251 -6.19281483 19.20313072 -10.90002251
		 -6.33228731 19.28748322 -10.90002251 -6.3481245 19.37050438 -10.90002251 -6.37424231 19.45088577 -10.90002251
		 -6.41022825 19.52736092 -10.90002251 -6.45551586 19.59872055 -10.90002251 -6.50938988 19.66384315 -10.90002251
		 -6.57100105 19.72170067 -10.90002251 -6.63937807 19.77137947 -10.90002251 -6.71344185 19.81209564 -10.90002251
		 -6.79202509 19.84321022 -10.90002251 -6.87388849 19.8642292 -10.90002251 -6.95774031 19.87482262 -10.90002251
		 -7.042258739 19.87482071 -10.90002251 -7.12611055 19.8642292 -10.90002251 -7.20797396 19.84321022 -10.90002251
		 -7.28655672 19.81209564 -10.90002251 -7.36062098 19.77137947 -10.90002251 -7.42899799 19.72170067 -10.90002251
		 -7.49060917 19.66384315 -10.90002251 -7.54448318 19.59872055 -10.90002251 -7.58977032 19.52735901 -10.90002251
		 -7.62575674 19.45088577 -10.90002251 -7.65187407 19.37050438 -10.90002251 -7.66771126 19.28748131 -10.90002251
		 -7.67301846 19.20313072 -10.90002251 -7.66771126 19.11877823 -10.90002251 -7.65187407 19.035757065 -10.90002251
		 -7.62575626 18.95537567 -10.90002251 -7.58977032 18.87890053 -10.90002251 -7.54448318 18.80754089 -10.90002251
		 -7.49060917 18.74241829 -10.90002251 -7.42899752 18.68456078 -10.90002251 -7.36062098 18.63488197 -10.90002251
		 -7.28655672 18.5941658 -10.90002251 -7.20797348 18.56305122 -10.90002251 -7.12611055 18.54203224 -10.90002251
		 -7.042258739 18.53144073 -10.90002251 -6.95774031 18.53144073 -10.90002251 -6.87388849 18.54203224 -10.90002251
		 -6.79202509 18.56305122 -10.90002251 -6.71344185 18.5941658 -10.90002251 -6.63937807 18.63488197 -10.90002251
		 -6.57100105 18.68456078 -10.90002251 -6.50938988 18.74241829 -10.90002251 -6.45551586 18.80754089 -10.90002251
		 -6.41022873 18.87890053 -10.90002251 -6.37424278 18.95537567 -10.90002251 -6.34812498 19.035757065 -10.90002251
		 -6.33228779 19.11877823 -10.90002251 -6.32698107 19.20313072 -10.90002251 -6.33228731 19.28748322 -11
		 -6.3481245 19.37050438 -11 -6.37424231 19.45088577 -11 -6.41022825 19.52736092 -11
		 -6.45551586 19.59872055 -11 -6.50938988 19.66384315 -11 -6.57100105 19.72170067 -11
		 -6.63937807 19.77137947 -11 -6.71344185 19.81209564 -11 -6.79202509 19.84321022 -11
		 -6.87388849 19.8642292 -11 -6.95774031 19.87482262 -11 -7.042258739 19.87482071 -11
		 -7.12611055 19.8642292 -11 -7.20797396 19.84321022 -11 -7.28655672 19.81209564 -11
		 -7.36062098 19.77137947 -11 -7.42899799 19.72170067 -11 -7.49060917 19.66384315 -11
		 -7.54448318 19.59872055 -11 -7.58977032 19.52735901 -11 -7.62575674 19.45088577 -11
		 -7.65187407 19.37050438 -11 -7.66771126 19.28748131 -11 -7.67301846 19.20313072 -11
		 -7.66771126 19.11877823 -11 -7.65187407 19.035757065 -11 -7.62575626 18.95537567 -11
		 -7.58977032 18.87890053 -11 -7.54448318 18.80754089 -11 -7.49060917 18.74241829 -11
		 -7.42899752 18.68456078 -11 -7.36062098 18.63488197 -11 -7.28655672 18.5941658 -11
		 -7.20797348 18.56305122 -11 -7.12611055 18.54203224 -11 -7.042258739 18.53144073 -11
		 -6.95774031 18.53144073 -11 -6.87388849 18.54203224 -11 -6.79202509 18.56305122 -11
		 -6.71344185 18.5941658 -11 -6.63937807 18.63488197 -11 -6.57100105 18.68456078 -11
		 -6.50938988 18.74241829 -11 -6.45551586 18.80754089 -11 -6.41022873 18.87890053 -11
		 -6.37424278 18.95537567 -11 -6.34812498 19.035757065 -11 -6.33228779 19.11877823 -11
		 -6.32698107 19.20313072 -11 -6.1991787 19.3042984 -11 -6.21817303 19.40386963 -11
		 -6.24949741 19.50027466 -11 -6.29265738 19.59199524 -11 -6.34697294 19.67758179 -11
		 -6.41158676 19.75568771 -11 -6.48548031 19.82507706 -11 -6.56748772 19.88466072 -11
		 -6.65631676 19.93349457 -11 -6.75056553 19.97080994 -11 -6.84874821 19.99601936 -11
		 -6.94931602 20.0087242126 -11 -7.050683022 20.0087242126 -11 -7.15125084 19.99601936 -11
		 -7.24943352 19.97080994 -11 -7.34368229 19.93349457 -11;
	setAttr ".vt[166:331]" -7.43251133 19.88465881 -11 -7.51451874 19.82507706 -11
		 -7.58841228 19.75568771 -11 -7.6530261 19.67758179 -11 -7.70734119 19.59199524 -11
		 -7.75050163 19.50027466 -11 -7.78182554 19.40386963 -11 -7.80081987 19.3042984 -11
		 -7.8071847 19.20313072 -11 -7.80081987 19.10196304 -11 -7.78182554 19.0023918152 -11
		 -7.75050116 18.90598679 -11 -7.70734119 18.8142662 -11 -7.6530261 18.72867966 -11
		 -7.58841228 18.65057373 -11 -7.51451874 18.58118439 -11 -7.43251085 18.52160263 -11
		 -7.34368229 18.47276688 -11 -7.24943352 18.43545151 -11 -7.15125084 18.41024399 -11
		 -7.050683022 18.39753914 -11 -6.94931602 18.39753914 -11 -6.84874821 18.41024399 -11
		 -6.75056553 18.43545151 -11 -6.65631676 18.47276878 -11 -6.56748819 18.52160263 -11
		 -6.48548031 18.58118439 -11 -6.41158676 18.65057373 -11 -6.34697342 18.72867966 -11
		 -6.29265833 18.8142662 -11 -6.24949789 18.90598679 -11 -6.21817398 19.0023918152 -11
		 -6.19917965 19.10196304 -11 -6.19281483 19.20313072 -11 8.80082035 19.3042984 -10.90002251
		 8.78182602 19.40386963 -10.90002251 8.75050163 19.50027466 -10.90002251 8.70734215 19.59199524 -10.90002251
		 8.65302658 19.67758179 -10.90002251 8.58841324 19.75568771 -10.90002251 8.51451969 19.82507706 -10.90002251
		 8.43251133 19.88466072 -10.90002251 8.34368324 19.93349457 -10.90002251 8.24943352 19.97080994 -10.90002251
		 8.15125179 19.99601936 -10.90002251 8.050683975 20.0087242126 -10.90002251 7.9493165 20.0087242126 -10.90002251
		 7.84874868 19.99601936 -10.90002251 7.75056601 19.97080994 -10.90002251 7.65631723 19.93349457 -10.90002251
		 7.56748867 19.88465881 -10.90002251 7.48548079 19.82507706 -10.90002251 7.41158724 19.75568771 -10.90002251
		 7.34697342 19.67758179 -10.90002251 7.29265785 19.59199524 -10.90002251 7.24949789 19.50027466 -10.90002251
		 7.21817398 19.40386963 -10.90002251 7.19917965 19.3042984 -10.90002251 7.19281483 19.20313072 -10.90002251
		 7.19917965 19.10196304 -10.90002251 7.21817398 19.0023918152 -10.90002251 7.24949837 18.90598679 -10.90002251
		 7.29265833 18.8142662 -10.90002251 7.34697342 18.72867966 -10.90002251 7.41158772 18.65057373 -10.90002251
		 7.48548079 18.58118439 -10.90002251 7.56748867 18.52160263 -10.90002251 7.65631723 18.47276688 -10.90002251
		 7.75056601 18.43545151 -10.90002251 7.84874868 18.41024399 -10.90002251 7.9493165 18.39753914 -10.90002251
		 8.050683975 18.39753914 -10.90002251 8.15125179 18.41024399 -10.90002251 8.24943352 18.43545151 -10.90002251
		 8.34368229 18.47276878 -10.90002251 8.43251133 18.52160263 -10.90002251 8.51451874 18.58118439 -10.90002251
		 8.58841228 18.65057373 -10.90002251 8.65302658 18.72867966 -10.90002251 8.70734119 18.8142662 -10.90002251
		 8.75050163 18.90598679 -10.90002251 8.78182602 19.0023918152 -10.90002251 8.80082035 19.10196304 -10.90002251
		 8.80718422 19.20313072 -10.90002251 8.66771221 19.28748322 -10.90002251 8.6518755 19.37050438 -10.90002251
		 8.62575722 19.45088577 -10.90002251 8.58977127 19.52736092 -10.90002251 8.54448414 19.59872055 -10.90002251
		 8.49061012 19.66384315 -10.90002251 8.42899895 19.72170067 -10.90002251 8.36062145 19.77137947 -10.90002251
		 8.2865572 19.81209564 -10.90002251 8.20797443 19.84321022 -10.90002251 8.12611103 19.8642292 -10.90002251
		 8.042259216 19.87482262 -10.90002251 7.95774078 19.87482071 -10.90002251 7.87388897 19.8642292 -10.90002251
		 7.79202557 19.84321022 -10.90002251 7.7134428 19.81209564 -10.90002251 7.63937855 19.77137947 -10.90002251
		 7.57100153 19.72170067 -10.90002251 7.50939035 19.66384315 -10.90002251 7.45551634 19.59872055 -10.90002251
		 7.41022921 19.52735901 -10.90002251 7.37424278 19.45088577 -10.90002251 7.34812546 19.37050438 -10.90002251
		 7.33228827 19.28748131 -10.90002251 7.32698107 19.20313072 -10.90002251 7.33228827 19.11877823 -10.90002251
		 7.34812546 19.035757065 -10.90002251 7.37424326 18.95537567 -10.90002251 7.41022921 18.87890053 -10.90002251
		 7.45551634 18.80754089 -10.90002251 7.50939035 18.74241829 -10.90002251 7.57100201 18.68456078 -10.90002251
		 7.63937855 18.63488197 -10.90002251 7.7134428 18.5941658 -10.90002251 7.79202604 18.56305122 -10.90002251
		 7.87388897 18.54203224 -10.90002251 7.95774078 18.53144073 -10.90002251 8.042259216 18.53144073 -10.90002251
		 8.12611103 18.54203224 -10.90002251 8.20797443 18.56305122 -10.90002251 8.2865572 18.5941658 -10.90002251
		 8.36062145 18.63488197 -10.90002251 8.42899799 18.68456078 -10.90002251 8.49060917 18.74241829 -10.90002251
		 8.54448318 18.80754089 -10.90002251 8.58977032 18.87890053 -10.90002251 8.62575722 18.95537567 -10.90002251
		 8.65187454 19.035757065 -10.90002251 8.66771126 19.11877823 -10.90002251 8.67301846 19.20313072 -10.90002251
		 8.66771221 19.28748322 -11 8.6518755 19.37050438 -11 8.62575722 19.45088577 -11 8.58977127 19.52736092 -11
		 8.54448414 19.59872055 -11 8.49061012 19.66384315 -11 8.42899895 19.72170067 -11
		 8.36062145 19.77137947 -11 8.2865572 19.81209564 -11 8.20797443 19.84321022 -11 8.12611103 19.8642292 -11
		 8.042259216 19.87482262 -11 7.95774078 19.87482071 -11 7.87388897 19.8642292 -11
		 7.79202557 19.84321022 -11 7.7134428 19.81209564 -11 7.63937855 19.77137947 -11 7.57100153 19.72170067 -11
		 7.50939035 19.66384315 -11 7.45551634 19.59872055 -11 7.41022921 19.52735901 -11
		 7.37424278 19.45088577 -11 7.34812546 19.37050438 -11 7.33228827 19.28748131 -11
		 7.32698107 19.20313072 -11 7.33228827 19.11877823 -11 7.34812546 19.035757065 -11
		 7.37424326 18.95537567 -11 7.41022921 18.87890053 -11 7.45551634 18.80754089 -11
		 7.50939035 18.74241829 -11 7.57100201 18.68456078 -11;
	setAttr ".vt[332:497]" 7.63937855 18.63488197 -11 7.7134428 18.5941658 -11
		 7.79202604 18.56305122 -11 7.87388897 18.54203224 -11 7.95774078 18.53144073 -11
		 8.042259216 18.53144073 -11 8.12611103 18.54203224 -11 8.20797443 18.56305122 -11
		 8.2865572 18.5941658 -11 8.36062145 18.63488197 -11 8.42899799 18.68456078 -11 8.49060917 18.74241829 -11
		 8.54448318 18.80754089 -11 8.58977032 18.87890053 -11 8.62575722 18.95537567 -11
		 8.65187454 19.035757065 -11 8.66771126 19.11877823 -11 8.67301846 19.20313072 -11
		 8.80082035 19.3042984 -11 8.78182602 19.40386963 -11 8.75050163 19.50027466 -11 8.70734215 19.59199524 -11
		 8.65302658 19.67758179 -11 8.58841324 19.75568771 -11 8.51451969 19.82507706 -11
		 8.43251133 19.88466072 -11 8.34368324 19.93349457 -11 8.24943352 19.97080994 -11
		 8.15125179 19.99601936 -11 8.050683975 20.0087242126 -11 7.9493165 20.0087242126 -11
		 7.84874868 19.99601936 -11 7.75056601 19.97080994 -11 7.65631723 19.93349457 -11
		 7.56748867 19.88465881 -11 7.48548079 19.82507706 -11 7.41158724 19.75568771 -11
		 7.34697342 19.67758179 -11 7.29265785 19.59199524 -11 7.24949789 19.50027466 -11
		 7.21817398 19.40386963 -11 7.19917965 19.3042984 -11 7.19281483 19.20313072 -11 7.19917965 19.10196304 -11
		 7.21817398 19.0023918152 -11 7.24949837 18.90598679 -11 7.29265833 18.8142662 -11
		 7.34697342 18.72867966 -11 7.41158772 18.65057373 -11 7.48548079 18.58118439 -11
		 7.56748867 18.52160263 -11 7.65631723 18.47276688 -11 7.75056601 18.43545151 -11
		 7.84874868 18.41024399 -11 7.9493165 18.39753914 -11 8.050683975 18.39753914 -11
		 8.15125179 18.41024399 -11 8.24943352 18.43545151 -11 8.34368229 18.47276878 -11
		 8.43251133 18.52160263 -11 8.51451874 18.58118439 -11 8.58841228 18.65057373 -11
		 8.65302658 18.72867966 -11 8.70734119 18.8142662 -11 8.75050163 18.90598679 -11 8.78182602 19.0023918152 -11
		 8.80082035 19.10196304 -11 8.80718422 19.20313072 -11 -12 0 12 12 0 12 -12 24 12
		 -12 24 -12 12 24 -12 -12 0 -12 12 0 -12 -11 24 -12 -11 0 -12 -11 0 12 -11 24 12 -12 24 -11
		 -12 0 -11 -11 0 -11 12 0 -11 12 24 -11 -11 24 -11 -11 1.000000119209 12 -12 1.000000238419 12
		 -12 0.99999976 -11 -12 0.99999976 -12 -11 0.99999976 -12 12 0.99999976 -12 12 1.000000119209 -11
		 12 1.000000119209 12 -11 1 -11 12 0 6.25 -11 0 6.25 -12 0 6.25 -12 1.000000238419 6.25
		 -12 24 6.25 -11 24 6.25 -11 1.000000119209 6.25 12 1.000000119209 6.25 12 0 0.49999952
		 -11 0 0.49999952 -12 0 0.49999952 -12 1.000000119209 0.49999952 -12 24 0.49999952
		 -11 24 0.49999952 -11 1 0.49999952 12 1.000000119209 0.49999952 12 0 -5.25 -11 0 -5.25
		 -12 0 -5.25 -12 0.99999988 -5.25 -12 24 -5.25 -11 24 -5.25 -11 1 -5.25 12 1.000000119209 -5.25
		 -11 12.5 0.49999952 -11 12.5 -5.25 -11 12.5 -11 12 12.5 -11 12 12.5 -12 -11 12.5 -12
		 -12 12.5 -12 -12 12.5 -11 -12 12.5 -5.25 -12 12.5 0.49999952 -12 12.5 6.25 -12 12.5 12
		 -11 12.5 12 -11 12.5 6.25 4.86411572 12.5 -11 4.86411572 24 -11 4.86411572 24 -12
		 4.86411572 12.5 -12 4.86411572 0.99999976 -12 4.86411572 0 -12 4.86411572 0 -11 4.86411572 0 -5.25
		 4.86411572 0 0.49999952 4.86411572 0 6.25 4.86411572 0 12 4.86411572 1.000000119209 12
		 4.86411572 1 -11 -1.0095481873 12.5 -11 -1.0095481873 24 -11 -1.0095481873 24 -12
		 -1.0095481873 12.5 -12 -1.0095481873 0.99999976 -12 -1.0095481873 0 -12 -1.0095481873 0 -11
		 -1.0095481873 0 -5.25 -1.0095481873 0 0.49999952 -1.0095481873 0 6.25 -1.0095481873 0 12
		 -1.0095481873 1.000000119209 12 -1.0095481873 1 -11 4.86411572 23.45244026 -11 -1.0095481873 23.45244026 -11
		 -11 23.45244026 -11 -11 23.45244026 -5.25 -11 23.45244026 0.49999952 -11 23.45244026 6.25
		 -11 23.45244026 12 -12 23.45244026 12;
	setAttr ".vt[498:529]" -12 23.45244026 6.25 -12 23.45244026 0.49999952 -12 23.45244026 -5.25
		 -12 23.45244026 -11 -12 23.45244026 -12 -11 23.45244026 -12 -1.0095481873 23.45244026 -12
		 4.86411572 23.45244026 -12 12 23.45244026 -12 12 23.45244026 -11 4.86411572 20.93067551 -11
		 -1.0095481873 20.93067551 -11 -11 20.93067551 -11 -11 20.93067551 -5.25 -11 20.93067551 0.49999952
		 -11 20.93067551 6.25 -11 20.93067551 12 -12 20.93067551 12 -12 20.93067551 6.25 -12 20.93067551 0.49999952
		 -12 20.93067551 -5.25 -12 20.93067551 -11 -12 20.93067551 -12 -11 20.93067551 -12
		 -1.0095481873 20.93067551 -12 4.86411572 20.93067551 -12 12 20.93067551 -12 12 20.93067551 -11
		 -1.0095481873 20.93067551 -11.95702171 -1.0095481873 23.45244026 -11.95702171 4.86411572 20.93067551 -11.95702171
		 4.86411572 23.45244026 -11.95702171;
	setAttr -s 954 ".ed";
	setAttr ".ed[0:165]"  0 1 0 1 2 0 2 3 0 3 4 0 4 5 0 5 6 0 6 7 0 7 8 0 8 9 0
		 9 10 0 10 11 0 11 12 0 12 13 0 13 14 0 14 15 0 15 16 0 16 17 0 17 18 0 18 19 0 19 20 0
		 20 21 0 21 22 0 22 23 0 23 24 0 24 25 0 25 26 0 26 27 0 27 28 0 28 29 0 29 30 0 30 31 0
		 31 32 0 32 33 0 33 34 0 34 35 0 35 36 0 36 37 0 37 38 0 38 39 0 39 40 0 40 41 0 41 42 0
		 42 43 0 43 44 0 44 45 0 45 46 0 46 47 0 47 48 0 48 49 0 49 0 0 50 51 0 51 52 0 52 53 0
		 53 54 0 54 55 0 55 56 0 56 57 0 57 58 0 58 59 0 59 60 0 60 61 0 61 62 0 62 63 0 63 64 0
		 64 65 0 65 66 0 66 67 0 67 68 0 68 69 0 69 70 0 70 71 0 71 72 0 72 73 0 73 74 0 74 75 0
		 75 76 0 76 77 0 77 78 0 78 79 0 79 80 0 80 81 0 81 82 0 82 83 0 83 84 0 84 85 0 85 86 0
		 86 87 0 87 88 0 88 89 0 89 90 0 90 91 0 91 92 0 92 93 0 93 94 0 94 95 0 95 96 0 96 97 0
		 97 98 0 98 99 0 99 50 0 0 50 1 1 51 1 2 52 1 3 53 1 4 54 1 5 55 1 6 56 1 7 57 1 8 58 1
		 9 59 1 10 60 1 11 61 1 12 62 1 13 63 1 14 64 1 15 65 1 16 66 1 17 67 1 18 68 1 19 69 1
		 20 70 1 21 71 1 22 72 1 23 73 1 24 74 1 25 75 1 26 76 1 27 77 1 28 78 1 29 79 1 30 80 1
		 31 81 1 32 82 1 33 83 1 34 84 1 35 85 1 36 86 1 37 87 1 38 88 1 39 89 1 40 90 1 41 91 1
		 42 92 1 43 93 1 44 94 1 45 95 1 46 96 1 47 97 1 48 98 1 49 99 1 50 100 0 51 101 0
		 100 101 0 52 102 0 101 102 0 53 103 0 102 103 0 54 104 0 103 104 0 55 105 0 104 105 0
		 56 106 0 105 106 0 57 107 0 106 107 0 58 108 0;
	setAttr ".ed[166:331]" 107 108 0 59 109 0 108 109 0 60 110 0 109 110 0 61 111 0
		 110 111 0 62 112 0 111 112 0 63 113 0 112 113 0 64 114 0 113 114 0 65 115 0 114 115 0
		 66 116 0 115 116 0 67 117 0 116 117 0 68 118 0 117 118 0 69 119 0 118 119 0 70 120 0
		 119 120 0 71 121 0 120 121 0 72 122 0 121 122 0 73 123 0 122 123 0 74 124 0 123 124 0
		 75 125 0 124 125 0 76 126 0 125 126 0 77 127 0 126 127 0 78 128 0 127 128 0 79 129 0
		 128 129 0 80 130 0 129 130 0 81 131 0 130 131 0 82 132 0 131 132 0 83 133 0 132 133 0
		 84 134 0 133 134 0 85 135 0 134 135 0 86 136 0 135 136 0 87 137 0 136 137 0 88 138 0
		 137 138 0 89 139 0 138 139 0 90 140 0 139 140 0 91 141 0 140 141 0 92 142 0 141 142 0
		 93 143 0 142 143 0 94 144 0 143 144 0 95 145 0 144 145 0 96 146 0 145 146 0 97 147 0
		 146 147 0 98 148 0 147 148 0 99 149 0 148 149 0 149 100 0 0 150 0 1 151 0 150 151 0
		 2 152 0 151 152 0 3 153 0 152 153 0 4 154 0 153 154 0 5 155 0 154 155 0 6 156 0 155 156 0
		 7 157 0 156 157 0 8 158 0 157 158 0 9 159 0 158 159 0 10 160 0 159 160 0 11 161 0
		 160 161 0 12 162 0 161 162 0 13 163 0 162 163 0 14 164 0 163 164 0 15 165 0 164 165 0
		 16 166 0 165 166 0 17 167 0 166 167 0 18 168 0 167 168 0 19 169 0 168 169 0 20 170 0
		 169 170 0 21 171 0 170 171 0 22 172 0 171 172 0 23 173 0 172 173 0 24 174 0 173 174 0
		 25 175 0 174 175 0 26 176 0 175 176 0 27 177 0 176 177 0 28 178 0 177 178 0 29 179 0
		 178 179 0 30 180 0 179 180 0 31 181 0 180 181 0 32 182 0 181 182 0 33 183 0 182 183 0
		 34 184 0 183 184 0 35 185 0 184 185 0 36 186 0 185 186 0 37 187 0 186 187 0 38 188 0
		 187 188 0 39 189 0 188 189 0 40 190 0 189 190 0 41 191 0;
	setAttr ".ed[332:497]" 190 191 0 42 192 0 191 192 0 43 193 0 192 193 0 44 194 0
		 193 194 0 45 195 0 194 195 0 46 196 0 195 196 0 47 197 0 196 197 0 48 198 0 197 198 0
		 49 199 0 198 199 0 199 150 0 200 201 0 201 202 0 202 203 0 203 204 0 204 205 0 205 206 0
		 206 207 0 207 208 0 208 209 0 209 210 0 210 211 0 211 212 0 212 213 0 213 214 0 214 215 0
		 215 216 0 216 217 0 217 218 0 218 219 0 219 220 0 220 221 0 221 222 0 222 223 0 223 224 0
		 224 225 0 225 226 0 226 227 0 227 228 0 228 229 0 229 230 0 230 231 0 231 232 0 232 233 0
		 233 234 0 234 235 0 235 236 0 236 237 0 237 238 0 238 239 0 239 240 0 240 241 0 241 242 0
		 242 243 0 243 244 0 244 245 0 245 246 0 246 247 0 247 248 0 248 249 0 249 200 0 250 251 0
		 251 252 0 252 253 0 253 254 0 254 255 0 255 256 0 256 257 0 257 258 0 258 259 0 259 260 0
		 260 261 0 261 262 0 262 263 0 263 264 0 264 265 0 265 266 0 266 267 0 267 268 0 268 269 0
		 269 270 0 270 271 0 271 272 0 272 273 0 273 274 0 274 275 0 275 276 0 276 277 0 277 278 0
		 278 279 0 279 280 0 280 281 0 281 282 0 282 283 0 283 284 0 284 285 0 285 286 0 286 287 0
		 287 288 0 288 289 0 289 290 0 290 291 0 291 292 0 292 293 0 293 294 0 294 295 0 295 296 0
		 296 297 0 297 298 0 298 299 0 299 250 0 200 250 1 201 251 1 202 252 1 203 253 1 204 254 1
		 205 255 1 206 256 1 207 257 1 208 258 1 209 259 1 210 260 1 211 261 1 212 262 1 213 263 1
		 214 264 1 215 265 1 216 266 1 217 267 1 218 268 1 219 269 1 220 270 1 221 271 1 222 272 1
		 223 273 1 224 274 1 225 275 1 226 276 1 227 277 1 228 278 1 229 279 1 230 280 1 231 281 1
		 232 282 1 233 283 1 234 284 1 235 285 1 236 286 1 237 287 1 238 288 1 239 289 1 240 290 1
		 241 291 1 242 292 1 243 293 1 244 294 1 245 295 1 246 296 1 247 297 1;
	setAttr ".ed[498:663]" 248 298 1 249 299 1 250 300 0 251 301 0 300 301 0 252 302 0
		 301 302 0 253 303 0 302 303 0 254 304 0 303 304 0 255 305 0 304 305 0 256 306 0 305 306 0
		 257 307 0 306 307 0 258 308 0 307 308 0 259 309 0 308 309 0 260 310 0 309 310 0 261 311 0
		 310 311 0 262 312 0 311 312 0 263 313 0 312 313 0 264 314 0 313 314 0 265 315 0 314 315 0
		 266 316 0 315 316 0 267 317 0 316 317 0 268 318 0 317 318 0 269 319 0 318 319 0 270 320 0
		 319 320 0 271 321 0 320 321 0 272 322 0 321 322 0 273 323 0 322 323 0 274 324 0 323 324 0
		 275 325 0 324 325 0 276 326 0 325 326 0 277 327 0 326 327 0 278 328 0 327 328 0 279 329 0
		 328 329 0 280 330 0 329 330 0 281 331 0 330 331 0 282 332 0 331 332 0 283 333 0 332 333 0
		 284 334 0 333 334 0 285 335 0 334 335 0 286 336 0 335 336 0 287 337 0 336 337 0 288 338 0
		 337 338 0 289 339 0 338 339 0 290 340 0 339 340 0 291 341 0 340 341 0 292 342 0 341 342 0
		 293 343 0 342 343 0 294 344 0 343 344 0 295 345 0 344 345 0 296 346 0 345 346 0 297 347 0
		 346 347 0 298 348 0 347 348 0 299 349 0 348 349 0 349 300 0 200 350 0 201 351 0 350 351 0
		 202 352 0 351 352 0 203 353 0 352 353 0 204 354 0 353 354 0 205 355 0 354 355 0 206 356 0
		 355 356 0 207 357 0 356 357 0 208 358 0 357 358 0 209 359 0 358 359 0 210 360 0 359 360 0
		 211 361 0 360 361 0 212 362 0 361 362 0 213 363 0 362 363 0 214 364 0 363 364 0 215 365 0
		 364 365 0 216 366 0 365 366 0 217 367 0 366 367 0 218 368 0 367 368 0 219 369 0 368 369 0
		 220 370 0 369 370 0 221 371 0 370 371 0 222 372 0 371 372 0 223 373 0 372 373 0 224 374 0
		 373 374 0 225 375 0 374 375 0 226 376 0 375 376 0 227 377 0 376 377 0 228 378 0 377 378 0
		 229 379 0 378 379 0 230 380 0 379 380 0 231 381 0 380 381 0 232 382 0;
	setAttr ".ed[664:829]" 381 382 0 233 383 0 382 383 0 234 384 0 383 384 0 235 385 0
		 384 385 0 236 386 0 385 386 0 237 387 0 386 387 0 238 388 0 387 388 0 239 389 0 388 389 0
		 240 390 0 389 390 0 241 391 0 390 391 0 242 392 0 391 392 0 243 393 0 392 393 0 244 394 0
		 393 394 0 245 395 0 394 395 0 246 396 0 395 396 0 247 397 0 396 397 0 248 398 0 397 398 0
		 249 399 0 398 399 0 399 350 0 400 409 0 402 410 0 403 407 0 405 408 0 400 418 0 401 424 0
		 403 502 0 404 506 0 405 412 0 406 414 0 407 479 0 408 482 0 407 503 0 409 487 0 408 413 0
		 409 417 0 411 403 0 412 444 0 411 501 0 413 443 0 412 413 0 414 442 0 413 483 0 415 404 0
		 414 423 0 416 407 0 415 465 0 416 411 0 417 418 0 419 412 0 420 405 0 419 420 0 421 408 0
		 420 421 0 422 406 0 421 481 0 422 423 0 423 449 0 424 475 0 417 432 0 423 476 0 410 431 0
		 402 430 0 418 429 0 417 462 0 418 461 0 423 453 0 416 492 0 426 401 0 427 409 0 426 473 0
		 428 400 0 427 428 0 429 437 0 428 429 0 430 438 0 429 460 0 431 439 0 430 431 0 431 495 0
		 433 424 0 433 426 0 434 426 0 435 427 0 434 472 0 436 428 0 435 436 0 437 445 0 436 437 0
		 438 446 0 437 459 0 439 447 0 438 439 0 440 448 0 439 494 0 441 433 0 441 434 0 442 434 0
		 443 435 0 442 471 0 444 436 0 443 444 0 445 419 0 444 445 0 446 411 0 445 458 0 447 416 0
		 446 447 0 448 425 0 447 493 0 449 441 0 449 442 0 450 440 0 451 448 0 450 451 0 452 425 0
		 451 452 0 453 525 0 452 477 0 454 422 0 453 454 0 455 421 0 454 467 0 456 420 0 455 456 0
		 457 419 0 456 457 0 458 518 0 457 458 0 459 517 0 458 459 0 460 516 0 459 460 0 461 515 0
		 460 461 0 462 514 0 461 462 0 463 432 0 462 463 0 463 450 0 432 429 0 440 437 0 450 459 0
		 463 460 0 464 453 0 465 478 0 464 508 1 466 404 0 465 466 1 467 480 0;
	setAttr ".ed[830:953]" 466 505 1 468 422 0 467 468 1 469 406 0 468 469 1 470 414 0
		 469 470 1 471 484 0 470 471 1 472 485 0 471 472 1 473 486 0 472 473 1 474 401 0 473 474 1
		 475 488 0 474 475 1 476 489 0 476 464 1 477 464 0 478 416 0 477 509 1 479 466 0 478 479 1
		 480 455 0 479 504 1 481 468 0 480 481 1 482 469 0 481 482 1 483 470 0 482 483 1 484 443 0
		 483 484 1 485 435 0 484 485 1 486 427 0 485 486 1 487 474 0 486 487 1 488 417 0 487 488 1
		 489 425 0 489 477 1 490 465 1 491 478 1 490 491 0 492 510 0 491 492 1 493 511 0 492 493 1
		 494 512 0 493 494 1 495 513 0 494 495 1 496 410 0 495 496 1 497 402 0 496 497 1 498 430 0
		 497 498 1 499 438 0 498 499 1 500 446 0 499 500 1 501 519 0 500 501 1 502 520 0 501 502 1
		 503 521 0 502 503 1 504 522 1 503 504 1 505 523 1 504 505 1 506 524 0 505 506 1 507 415 0
		 506 507 1 507 490 1 508 490 0 509 491 0 508 509 0 510 452 0 509 510 1 511 451 0 510 511 1
		 512 450 0 511 512 1 513 463 0 512 513 1 514 496 0 513 514 1 515 497 0 514 515 1 516 498 0
		 515 516 1 517 499 0 516 517 1 518 500 0 517 518 1 519 457 0 518 519 1 520 456 0 519 520 1
		 521 455 0 520 521 1 522 480 1 521 522 1 523 467 1 522 523 1 524 454 0 523 524 1 525 507 0
		 524 525 1 525 508 1 509 526 0 491 527 0 526 527 0 508 528 0 528 526 0 490 529 0 528 529 0
		 529 527 0;
	setAttr -s 1348 ".n";
	setAttr ".n[0:165]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[166:331]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[332:497]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[498:663]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[664:829]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[830:995]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20;
	setAttr ".n[996:1161]" -type "float3"  1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 -9.5367409e-07 0 1 -9.5367409e-07 0 1 -9.5367409e-07
		 0 1 -9.5367409e-07 0 1 0 1 0 0 1 0 0 1 0 0 1 0 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 -1 0
		 0 -1 0 0 -1 0 0 -1 0 1 0 0 1 0 0 1 0 0 1 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 0 0 -1 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 0 0 1 0 0 1 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 -1 0 0 -1 0 0
		 0 -1 0 0 -1 0 0 -1 0 0 -1 0 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20 1e+20 1 0
		 0 1 0 0 1 0 0 1 0 0 0 1 0 0 1 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 1 0 0 1 0 0
		 1 0 0 1 0 0 0 1 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1
		 0 0 -1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1 0 0 1 0 0 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 0 -1 0 0 -1
		 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 0
		 1 0 0 1 0 0 1 0 0 1 0 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1 0 0 1 0 0
		 1 0 0 1 0 0 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 0 -1
		 0 0 -1 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20
		 1e+20 0 1 0 0 1 0 0 1 0 0 1 0 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1 0
		 0 1 0 0 1 0 0 1 0 0 1e+20 1e+20 1e+20 0 -0.99999994 0 0 -0.99999994 0 1e+20 1e+20
		 1e+20 0 -1 0 0 -1 0 0 -1 0 0 -1 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 -0.99999994
		 0 0;
	setAttr ".n[1162:1327]" -type "float3"  -0.99999994 0 0 1e+20 1e+20 1e+20 0 1
		 0 0 1 0 0 1 0 0 1 0 0.99999994 0 0 0.99999994 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1 0 0 1 0 0 1 0 0 1 0 0 0.99999994 0 0 0.99999994 0 0 0.99999994 0 0 0.99999994 0
		 0 1 0 0 1 0 0 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 0 0 1 1 0 0 1
		 0 0 1 0 0 1 0 0 1e+20 1e+20 1e+20 0 0 -1 0 0 -1 1e+20 1e+20 1e+20 0 0 -1 0 0 -1 0
		 0 -1 0 0 -1 -1 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 -0.99999994 0
		 0 -0.99999994 0 0 -0.99999994 0 0 -0.99999994 0 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 0 0
		 1 0 0 1 0 0 1 0 0 1 1 0 0 1 0 0 1 0 0 1 0 0 5.1830078e-09 0 1 5.1830078e-09 0 1 5.1830078e-09
		 0 1 5.1830078e-09 0 1 0 -1 0 0 -1 0 0 -1 0 0 -1 0 0 0 -1 0 0 -1 0 0 -1 0 0 -1 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 0 1 0 0 1 0 0 0 -1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0
		 0 -1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 0 0 -1 0 0 -1 0 -1 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 0 -1 0 0 -0.99999994 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 0 -0.99999994 0 0 -1 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 -1 0 0 -1 0 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 0 -1 0 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 0
		 0 1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0.99999994 0 0 0.99999994
		 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20
		 1e+20 1 0 0 1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 1 0 0 1 -1 0 0 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 -1 0 0
		 -0.99999994 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 -0.99999994 0 0 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 -1 0 0 -1 0 0 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20;
	setAttr ".n[1328:1347]" -type "float3"  -1 0 0 -1 0 0 1e+20 1e+20 1e+20 1e+20
		 1e+20 1e+20 0 0 -1 0 0 -1 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1 1e+20 1e+20
		 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 1e+20 0 0 -1 1e+20 1e+20 1e+20
		 1e+20 1e+20 1e+20 1 0 0 1 0 0 1e+20 1e+20 1e+20 0 0 1;
	setAttr -s 423 -ch 1692 ".fc[0:422]" -type "polyFaces" 
		f 4 0 101 -51 -101
		mu 0 4 0 1 2 3
		f 4 1 102 -52 -102
		mu 0 4 1 4 5 2
		f 4 2 103 -53 -103
		mu 0 4 4 6 7 5
		f 4 3 104 -54 -104
		mu 0 4 6 8 9 7
		f 4 4 105 -55 -105
		mu 0 4 8 10 11 9
		f 4 5 106 -56 -106
		mu 0 4 10 12 13 11
		f 4 6 107 -57 -107
		mu 0 4 12 14 15 13
		f 4 7 108 -58 -108
		mu 0 4 14 16 17 15
		f 4 8 109 -59 -109
		mu 0 4 16 18 19 17
		f 4 9 110 -60 -110
		mu 0 4 18 20 21 19
		f 4 10 111 -61 -111
		mu 0 4 20 22 23 21
		f 4 11 112 -62 -112
		mu 0 4 22 24 25 23
		f 4 12 113 -63 -113
		mu 0 4 24 26 27 25
		f 4 13 114 -64 -114
		mu 0 4 26 28 29 27
		f 4 14 115 -65 -115
		mu 0 4 28 30 31 29
		f 4 15 116 -66 -116
		mu 0 4 30 32 33 31
		f 4 16 117 -67 -117
		mu 0 4 32 34 35 33
		f 4 17 118 -68 -118
		mu 0 4 34 36 37 35
		f 4 18 119 -69 -119
		mu 0 4 36 38 39 37
		f 4 19 120 -70 -120
		mu 0 4 38 40 41 39
		f 4 20 121 -71 -121
		mu 0 4 40 42 43 41
		f 4 21 122 -72 -122
		mu 0 4 42 44 45 43
		f 4 22 123 -73 -123
		mu 0 4 44 46 47 45
		f 4 23 124 -74 -124
		mu 0 4 46 48 49 47
		f 4 24 125 -75 -125
		mu 0 4 48 50 51 49
		f 4 25 126 -76 -126
		mu 0 4 50 52 53 51
		f 4 26 127 -77 -127
		mu 0 4 52 54 55 53
		f 4 27 128 -78 -128
		mu 0 4 54 56 57 55
		f 4 28 129 -79 -129
		mu 0 4 56 58 59 57
		f 4 29 130 -80 -130
		mu 0 4 58 60 61 59
		f 4 30 131 -81 -131
		mu 0 4 60 62 63 61
		f 4 31 132 -82 -132
		mu 0 4 62 64 65 63
		f 4 32 133 -83 -133
		mu 0 4 64 66 67 65
		f 4 33 134 -84 -134
		mu 0 4 66 68 69 67
		f 4 34 135 -85 -135
		mu 0 4 68 70 71 69
		f 4 35 136 -86 -136
		mu 0 4 70 72 73 71
		f 4 36 137 -87 -137
		mu 0 4 72 74 75 73
		f 4 37 138 -88 -138
		mu 0 4 74 76 77 75
		f 4 38 139 -89 -139
		mu 0 4 76 78 79 77
		f 4 39 140 -90 -140
		mu 0 4 78 80 81 79
		f 4 40 141 -91 -141
		mu 0 4 80 82 83 81
		f 4 41 142 -92 -142
		mu 0 4 82 84 85 83
		f 4 42 143 -93 -143
		mu 0 4 84 86 87 85
		f 4 43 144 -94 -144
		mu 0 4 86 88 89 87
		f 4 44 145 -95 -145
		mu 0 4 88 90 91 89
		f 4 45 146 -96 -146
		mu 0 4 90 92 93 91
		f 4 46 147 -97 -147
		mu 0 4 92 94 95 93
		f 4 47 148 -98 -148
		mu 0 4 94 96 97 95
		f 4 48 149 -99 -149
		mu 0 4 96 98 99 97
		f 4 49 100 -100 -150
		mu 0 4 98 0 3 99
		f 4 50 151 -153 -151
		mu 0 4 3 2 100 101
		f 4 51 153 -155 -152
		mu 0 4 2 5 102 100
		f 4 52 155 -157 -154
		mu 0 4 5 7 103 102
		f 4 53 157 -159 -156
		mu 0 4 7 9 104 103
		f 4 54 159 -161 -158
		mu 0 4 9 11 105 104
		f 4 55 161 -163 -160
		mu 0 4 11 13 106 105
		f 4 56 163 -165 -162
		mu 0 4 13 15 107 106
		f 4 57 165 -167 -164
		mu 0 4 15 17 108 107
		f 4 58 167 -169 -166
		mu 0 4 17 19 109 108
		f 4 59 169 -171 -168
		mu 0 4 19 21 110 109
		f 4 60 171 -173 -170
		mu 0 4 21 23 111 110
		f 4 61 173 -175 -172
		mu 0 4 23 25 112 111
		f 4 62 175 -177 -174
		mu 0 4 25 27 113 112
		f 4 63 177 -179 -176
		mu 0 4 27 29 114 113
		f 4 64 179 -181 -178
		mu 0 4 29 31 115 114
		f 4 65 181 -183 -180
		mu 0 4 31 33 116 115
		f 4 66 183 -185 -182
		mu 0 4 33 35 117 116
		f 4 67 185 -187 -184
		mu 0 4 35 37 118 117
		f 4 68 187 -189 -186
		mu 0 4 37 39 119 118
		f 4 69 189 -191 -188
		mu 0 4 39 41 120 119
		f 4 70 191 -193 -190
		mu 0 4 41 43 121 120
		f 4 71 193 -195 -192
		mu 0 4 43 45 122 121
		f 4 72 195 -197 -194
		mu 0 4 45 47 123 122
		f 4 73 197 -199 -196
		mu 0 4 47 49 124 123
		f 4 74 199 -201 -198
		mu 0 4 49 51 125 124
		f 4 75 201 -203 -200
		mu 0 4 51 53 126 125
		f 4 76 203 -205 -202
		mu 0 4 53 55 127 126
		f 4 77 205 -207 -204
		mu 0 4 55 57 128 127
		f 4 78 207 -209 -206
		mu 0 4 57 59 129 128
		f 4 79 209 -211 -208
		mu 0 4 59 61 130 129
		f 4 80 211 -213 -210
		mu 0 4 61 63 131 130
		f 4 81 213 -215 -212
		mu 0 4 63 65 132 131
		f 4 82 215 -217 -214
		mu 0 4 65 67 133 132
		f 4 83 217 -219 -216
		mu 0 4 67 69 134 133
		f 4 84 219 -221 -218
		mu 0 4 69 71 135 134
		f 4 85 221 -223 -220
		mu 0 4 71 73 136 135
		f 4 86 223 -225 -222
		mu 0 4 73 75 137 136
		f 4 87 225 -227 -224
		mu 0 4 75 77 138 137
		f 4 88 227 -229 -226
		mu 0 4 77 79 139 138
		f 4 89 229 -231 -228
		mu 0 4 79 81 140 139
		f 4 90 231 -233 -230
		mu 0 4 81 83 141 140
		f 4 91 233 -235 -232
		mu 0 4 83 85 142 141
		f 4 92 235 -237 -234
		mu 0 4 85 87 143 142
		f 4 93 237 -239 -236
		mu 0 4 87 89 144 143
		f 4 94 239 -241 -238
		mu 0 4 89 91 145 144
		f 4 95 241 -243 -240
		mu 0 4 91 93 146 145
		f 4 96 243 -245 -242
		mu 0 4 93 95 147 146
		f 4 97 245 -247 -244
		mu 0 4 95 97 148 147
		f 4 98 247 -249 -246
		mu 0 4 97 99 149 148
		f 4 99 150 -250 -248
		mu 0 4 99 3 101 149
		f 4 -1 250 252 -252
		mu 0 4 150 151 152 153
		f 4 -2 251 254 -254
		mu 0 4 154 155 156 157
		f 4 -3 253 256 -256
		mu 0 4 158 159 160 161
		f 4 -4 255 258 -258
		mu 0 4 162 163 164 165
		f 4 -5 257 260 -260
		mu 0 4 166 167 168 169
		f 4 -6 259 262 -262
		mu 0 4 170 171 172 173
		f 4 -7 261 264 -264
		mu 0 4 174 175 176 177
		f 4 -8 263 266 -266
		mu 0 4 178 179 180 181
		f 4 -9 265 268 -268
		mu 0 4 182 183 184 185
		f 4 -10 267 270 -270
		mu 0 4 186 187 188 189
		f 4 -11 269 272 -272
		mu 0 4 190 191 192 193
		f 4 -12 271 274 -274
		mu 0 4 194 195 196 197
		f 4 -13 273 276 -276
		mu 0 4 198 199 200 201
		f 4 -14 275 278 -278
		mu 0 4 202 203 204 205
		f 4 -15 277 280 -280
		mu 0 4 206 207 208 209
		f 4 -16 279 282 -282
		mu 0 4 210 211 212 213
		f 4 -17 281 284 -284
		mu 0 4 214 215 216 217
		f 4 -18 283 286 -286
		mu 0 4 218 219 220 221
		f 4 -19 285 288 -288
		mu 0 4 222 223 224 225
		f 4 -20 287 290 -290
		mu 0 4 226 227 228 229
		f 4 -21 289 292 -292
		mu 0 4 230 231 232 233
		f 4 -22 291 294 -294
		mu 0 4 234 235 236 237
		f 4 -23 293 296 -296
		mu 0 4 238 239 240 241
		f 4 -24 295 298 -298
		mu 0 4 242 243 244 245
		f 4 -25 297 300 -300
		mu 0 4 246 247 248 249
		f 4 -26 299 302 -302
		mu 0 4 250 251 252 253
		f 4 -27 301 304 -304
		mu 0 4 254 255 256 257
		f 4 -28 303 306 -306
		mu 0 4 258 259 260 261
		f 4 -29 305 308 -308
		mu 0 4 262 263 264 265
		f 4 -30 307 310 -310
		mu 0 4 266 267 268 269
		f 4 -31 309 312 -312
		mu 0 4 270 271 272 273
		f 4 -32 311 314 -314
		mu 0 4 274 275 276 277
		f 4 -33 313 316 -316
		mu 0 4 278 279 280 281
		f 4 -34 315 318 -318
		mu 0 4 282 283 284 285
		f 4 -35 317 320 -320
		mu 0 4 286 287 288 289
		f 4 -36 319 322 -322
		mu 0 4 290 291 292 293
		f 4 -37 321 324 -324
		mu 0 4 294 295 296 297
		f 4 -38 323 326 -326
		mu 0 4 298 299 300 301
		f 4 -39 325 328 -328
		mu 0 4 302 303 304 305
		f 4 -40 327 330 -330
		mu 0 4 306 307 308 309
		f 4 -41 329 332 -332
		mu 0 4 310 311 312 313
		f 4 -42 331 334 -334
		mu 0 4 314 315 316 317
		f 4 -43 333 336 -336
		mu 0 4 318 319 320 321
		f 4 -44 335 338 -338
		mu 0 4 322 323 324 325
		f 4 -45 337 340 -340
		mu 0 4 326 327 328 329
		f 4 -46 339 342 -342
		mu 0 4 330 331 332 333
		f 4 -47 341 344 -344
		mu 0 4 334 335 336 337
		f 4 -48 343 346 -346
		mu 0 4 338 339 340 341
		f 4 -49 345 348 -348
		mu 0 4 342 343 344 345
		f 4 -50 347 349 -251
		mu 0 4 346 347 348 349
		f 4 350 451 -401 -451
		mu 0 4 350 351 352 353
		f 4 351 452 -402 -452
		mu 0 4 351 354 355 352
		f 4 352 453 -403 -453
		mu 0 4 354 356 357 355
		f 4 353 454 -404 -454
		mu 0 4 356 358 359 357
		f 4 354 455 -405 -455
		mu 0 4 358 360 361 359
		f 4 355 456 -406 -456
		mu 0 4 360 362 363 361
		f 4 356 457 -407 -457
		mu 0 4 362 364 365 363
		f 4 357 458 -408 -458
		mu 0 4 364 366 367 365
		f 4 358 459 -409 -459
		mu 0 4 366 368 369 367
		f 4 359 460 -410 -460
		mu 0 4 368 370 371 369
		f 4 360 461 -411 -461
		mu 0 4 370 372 373 371
		f 4 361 462 -412 -462
		mu 0 4 372 374 375 373
		f 4 362 463 -413 -463
		mu 0 4 374 376 377 375
		f 4 363 464 -414 -464
		mu 0 4 376 378 379 377
		f 4 364 465 -415 -465
		mu 0 4 378 380 381 379
		f 4 365 466 -416 -466
		mu 0 4 380 382 383 381
		f 4 366 467 -417 -467
		mu 0 4 382 384 385 383
		f 4 367 468 -418 -468
		mu 0 4 384 386 387 385
		f 4 368 469 -419 -469
		mu 0 4 386 388 389 387
		f 4 369 470 -420 -470
		mu 0 4 388 390 391 389
		f 4 370 471 -421 -471
		mu 0 4 390 392 393 391
		f 4 371 472 -422 -472
		mu 0 4 392 394 395 393
		f 4 372 473 -423 -473
		mu 0 4 394 396 397 395
		f 4 373 474 -424 -474
		mu 0 4 396 398 399 397
		f 4 374 475 -425 -475
		mu 0 4 398 400 401 399
		f 4 375 476 -426 -476
		mu 0 4 400 402 403 401
		f 4 376 477 -427 -477
		mu 0 4 402 404 405 403
		f 4 377 478 -428 -478
		mu 0 4 404 406 407 405
		f 4 378 479 -429 -479
		mu 0 4 406 408 409 407
		f 4 379 480 -430 -480
		mu 0 4 408 410 411 409
		f 4 380 481 -431 -481
		mu 0 4 410 412 413 411
		f 4 381 482 -432 -482
		mu 0 4 412 414 415 413
		f 4 382 483 -433 -483
		mu 0 4 414 416 417 415
		f 4 383 484 -434 -484
		mu 0 4 416 418 419 417
		f 4 384 485 -435 -485
		mu 0 4 418 420 421 419
		f 4 385 486 -436 -486
		mu 0 4 420 422 423 421
		f 4 386 487 -437 -487
		mu 0 4 422 424 425 423
		f 4 387 488 -438 -488
		mu 0 4 424 426 427 425
		f 4 388 489 -439 -489
		mu 0 4 426 428 429 427
		f 4 389 490 -440 -490
		mu 0 4 428 430 431 429
		f 4 390 491 -441 -491
		mu 0 4 430 432 433 431
		f 4 391 492 -442 -492
		mu 0 4 432 434 435 433
		f 4 392 493 -443 -493
		mu 0 4 434 436 437 435
		f 4 393 494 -444 -494
		mu 0 4 436 438 439 437
		f 4 394 495 -445 -495
		mu 0 4 438 440 441 439
		f 4 395 496 -446 -496
		mu 0 4 440 442 443 441
		f 4 396 497 -447 -497
		mu 0 4 442 444 445 443
		f 4 397 498 -448 -498
		mu 0 4 444 446 447 445
		f 4 398 499 -449 -499
		mu 0 4 446 448 449 447
		f 4 399 450 -450 -500
		mu 0 4 448 350 353 449
		f 4 400 501 -503 -501
		mu 0 4 353 352 450 451
		f 4 401 503 -505 -502
		mu 0 4 352 355 452 450
		f 4 402 505 -507 -504
		mu 0 4 355 357 453 452
		f 4 403 507 -509 -506
		mu 0 4 357 359 454 453
		f 4 404 509 -511 -508
		mu 0 4 359 361 455 454
		f 4 405 511 -513 -510
		mu 0 4 361 363 456 455
		f 4 406 513 -515 -512
		mu 0 4 363 365 457 456
		f 4 407 515 -517 -514
		mu 0 4 365 367 458 457
		f 4 408 517 -519 -516
		mu 0 4 367 369 459 458
		f 4 409 519 -521 -518
		mu 0 4 369 371 460 459
		f 4 410 521 -523 -520
		mu 0 4 371 373 461 460
		f 4 411 523 -525 -522
		mu 0 4 373 375 462 461
		f 4 412 525 -527 -524
		mu 0 4 375 377 463 462
		f 4 413 527 -529 -526
		mu 0 4 377 379 464 463
		f 4 414 529 -531 -528
		mu 0 4 379 381 465 464
		f 4 415 531 -533 -530
		mu 0 4 381 383 466 465
		f 4 416 533 -535 -532
		mu 0 4 383 385 467 466
		f 4 417 535 -537 -534
		mu 0 4 385 387 468 467
		f 4 418 537 -539 -536
		mu 0 4 387 389 469 468
		f 4 419 539 -541 -538
		mu 0 4 389 391 470 469
		f 4 420 541 -543 -540
		mu 0 4 391 393 471 470
		f 4 421 543 -545 -542
		mu 0 4 393 395 472 471
		f 4 422 545 -547 -544
		mu 0 4 395 397 473 472
		f 4 423 547 -549 -546
		mu 0 4 397 399 474 473
		f 4 424 549 -551 -548
		mu 0 4 399 401 475 474
		f 4 425 551 -553 -550
		mu 0 4 401 403 476 475
		f 4 426 553 -555 -552
		mu 0 4 403 405 477 476
		f 4 427 555 -557 -554
		mu 0 4 405 407 478 477
		f 4 428 557 -559 -556
		mu 0 4 407 409 479 478
		f 4 429 559 -561 -558
		mu 0 4 409 411 480 479
		f 4 430 561 -563 -560
		mu 0 4 411 413 481 480
		f 4 431 563 -565 -562
		mu 0 4 413 415 482 481
		f 4 432 565 -567 -564
		mu 0 4 415 417 483 482
		f 4 433 567 -569 -566
		mu 0 4 417 419 484 483
		f 4 434 569 -571 -568
		mu 0 4 419 421 485 484
		f 4 435 571 -573 -570
		mu 0 4 421 423 486 485
		f 4 436 573 -575 -572
		mu 0 4 423 425 487 486
		f 4 437 575 -577 -574
		mu 0 4 425 427 488 487
		f 4 438 577 -579 -576
		mu 0 4 427 429 489 488
		f 4 439 579 -581 -578
		mu 0 4 429 431 490 489
		f 4 440 581 -583 -580
		mu 0 4 431 433 491 490
		f 4 441 583 -585 -582
		mu 0 4 433 435 492 491
		f 4 442 585 -587 -584
		mu 0 4 435 437 493 492
		f 4 443 587 -589 -586
		mu 0 4 437 439 494 493
		f 4 444 589 -591 -588
		mu 0 4 439 441 495 494
		f 4 445 591 -593 -590
		mu 0 4 441 443 496 495
		f 4 446 593 -595 -592
		mu 0 4 443 445 497 496
		f 4 447 595 -597 -594
		mu 0 4 445 447 498 497
		f 4 448 597 -599 -596
		mu 0 4 447 449 499 498
		f 4 449 500 -600 -598
		mu 0 4 449 353 451 499
		f 4 -351 600 602 -602
		mu 0 4 500 501 502 503
		f 4 -352 601 604 -604
		mu 0 4 504 505 506 507
		f 4 -353 603 606 -606
		mu 0 4 508 509 510 511
		f 4 -354 605 608 -608
		mu 0 4 512 513 514 515
		f 4 -355 607 610 -610
		mu 0 4 516 517 518 519
		f 4 -356 609 612 -612
		mu 0 4 520 521 522 523
		f 4 -357 611 614 -614
		mu 0 4 524 525 526 527
		f 4 -358 613 616 -616
		mu 0 4 528 529 530 531
		f 4 -359 615 618 -618
		mu 0 4 532 533 534 535
		f 4 -360 617 620 -620
		mu 0 4 536 537 538 539
		f 4 -361 619 622 -622
		mu 0 4 540 541 542 543
		f 4 -362 621 624 -624
		mu 0 4 544 545 546 547
		f 4 -363 623 626 -626
		mu 0 4 548 549 550 551
		f 4 -364 625 628 -628
		mu 0 4 552 553 554 555
		f 4 -365 627 630 -630
		mu 0 4 556 557 558 559
		f 4 -366 629 632 -632
		mu 0 4 560 561 562 563
		f 4 -367 631 634 -634
		mu 0 4 564 565 566 567
		f 4 -368 633 636 -636
		mu 0 4 568 569 570 571
		f 4 -369 635 638 -638
		mu 0 4 572 573 574 575
		f 4 -370 637 640 -640
		mu 0 4 576 577 578 579
		f 4 -371 639 642 -642
		mu 0 4 580 581 582 583
		f 4 -372 641 644 -644
		mu 0 4 584 585 586 587
		f 4 -373 643 646 -646
		mu 0 4 588 589 590 591
		f 4 -374 645 648 -648
		mu 0 4 592 593 594 595
		f 4 -375 647 650 -650
		mu 0 4 596 597 598 599
		f 4 -376 649 652 -652
		mu 0 4 600 601 602 603
		f 4 -377 651 654 -654
		mu 0 4 604 605 606 607
		f 4 -378 653 656 -656
		mu 0 4 608 609 610 611
		f 4 -379 655 658 -658
		mu 0 4 612 613 614 615
		f 4 -380 657 660 -660
		mu 0 4 616 617 618 619
		f 4 -381 659 662 -662
		mu 0 4 620 621 622 623
		f 4 -382 661 664 -664
		mu 0 4 624 625 626 627
		f 4 -383 663 666 -666
		mu 0 4 628 629 630 631
		f 4 -384 665 668 -668
		mu 0 4 632 633 634 635
		f 4 -385 667 670 -670
		mu 0 4 636 637 638 639
		f 4 -386 669 672 -672
		mu 0 4 640 641 642 643
		f 4 -387 671 674 -674
		mu 0 4 644 645 646 647
		f 4 -388 673 676 -676
		mu 0 4 648 649 650 651
		f 4 -389 675 678 -678
		mu 0 4 652 653 654 655
		f 4 -390 677 680 -680
		mu 0 4 656 657 658 659
		f 4 -391 679 682 -682
		mu 0 4 660 661 662 663
		f 4 -392 681 684 -684
		mu 0 4 664 665 666 667
		f 4 -393 683 686 -686
		mu 0 4 668 669 670 671
		f 4 -394 685 688 -688
		mu 0 4 672 673 674 675
		f 4 -395 687 690 -690
		mu 0 4 676 677 678 679
		f 4 -396 689 692 -692
		mu 0 4 680 681 682 683
		f 4 -397 691 694 -694
		mu 0 4 684 685 686 687
		f 4 -398 693 696 -696
		mu 0 4 688 689 690 691
		f 4 -399 695 698 -698
		mu 0 4 692 693 694 695
		f 4 -400 697 699 -601
		mu 0 4 696 697 698 699
		f 4 700 715 728 -705
		mu 0 4 700 701 702 703
		f 4 -785 787 786 727
		mu 0 4 704 705 706 707
		f 4 733 732 -704 -731
		mu 0 4 708 709 710 711
		f 4 781 -718 720 719
		mu 0 4 712 713 714 715
		f 4 791 -722 724 737
		mu 0 4 716 717 718 719
		f 4 783 782 729 717
		mu 0 4 720 721 722 723
		f 4 735 859 -712 -733
		mu 0 4 709 724 725 710
		f 4 862 -720 722 863
		mu 0 4 726 712 715 727
		f 4 870 -716 713 871
		mu 0 4 728 702 701 729
		f 4 708 -730 731 730
		mu 0 4 730 723 722 731
		f 4 703 714 -721 -709
		mu 0 4 711 710 715 714
		f 4 -723 -715 711 861
		mu 0 4 727 715 710 725
		f 4 -725 -710 -735 736
		mu 0 4 719 718 732 733
		f 4 -726 -851 853 -711
		mu 0 4 734 707 735 736
		f 4 -728 725 -703 -717
		mu 0 4 704 707 734 737
		f 4 816 815 924 -814
		mu 0 4 738 739 740 741
		f 4 808 807 932 931
		mu 0 4 742 743 744 745
		f 4 806 -932 934 933
		mu 0 4 746 742 745 747
		f 4 804 -934 936 935
		mu 0 4 748 749 750 751
		f 4 854 -936 938 937
		mu 0 4 752 748 751 753
		f 4 800 -942 944 -798
		mu 0 4 754 755 756 757
		f 4 796 -914 916 915
		mu 0 4 758 759 760 761
		f 4 913 798 851 914
		mu 0 4 762 763 764 765
		f 4 -714 -750 -867 869
		mu 0 4 766 767 768 769
		f 4 -701 -752 -753 749
		mu 0 4 767 770 771 768
		f 4 704 743 -755 751
		mu 0 4 700 703 772 773
		f 4 -812 814 813 926
		mu 0 4 774 775 738 741
		f 4 -759 -743 701 741
		mu 0 4 776 777 778 779
		f 4 818 -920 922 -816
		mu 0 4 780 781 782 783
		f 4 -706 -749 -762 760
		mu 0 4 784 785 786 787
		f 4 866 -764 -865 867
		mu 0 4 769 768 788 789
		f 4 752 -766 -767 763
		mu 0 4 768 771 790 788
		f 4 754 753 -769 765
		mu 0 4 773 772 791 792
		f 4 -810 812 811 928
		mu 0 4 793 794 775 774
		f 4 -773 -756 758 757
		mu 0 4 795 796 777 776
		f 4 819 -918 920 919
		mu 0 4 781 797 798 782
		f 4 761 -763 -777 775
		mu 0 4 787 786 799 800
		f 4 864 -779 -863 865
		mu 0 4 789 788 712 726
		f 4 766 -781 -782 778
		mu 0 4 788 790 713 712
		f 4 768 767 -784 780
		mu 0 4 792 791 721 720
		f 4 -808 810 809 930
		mu 0 4 744 743 794 793
		f 4 -788 -770 772 771
		mu 0 4 706 705 796 795
		f 4 794 -916 918 917
		mu 0 4 797 758 761 798
		f 4 776 -778 -792 790
		mu 0 4 800 799 717 716
		f 4 773 -794 -795 792
		mu 0 4 801 802 758 797
		f 4 788 -796 -797 793
		mu 0 4 802 803 759 758
		f 4 873 -799 795 -873
		mu 0 4 804 764 763 805
		f 4 -737 -800 -801 -747
		mu 0 4 719 733 755 754
		f 4 -736 -802 -855 857
		mu 0 4 724 709 748 752
		f 4 -734 -804 -805 801
		mu 0 4 709 708 749 748
		f 4 -732 -806 -807 803
		mu 0 4 731 722 742 746
		f 4 -783 785 -809 805
		mu 0 4 722 721 743 742
		f 4 -811 -786 -768 770
		mu 0 4 794 743 721 791
		f 4 -815 -757 -744 745
		mu 0 4 738 775 772 703
		f 4 -729 744 -817 -746
		mu 0 4 703 702 739 738
		f 4 739 -818 -819 -745
		mu 0 4 806 807 781 780
		f 4 -793 822 -771 -822
		mu 0 4 801 797 808 809
		f 4 -820 823 -813 -823
		mu 0 4 797 781 810 808
		f 4 817 820 756 -824
		mu 0 4 781 807 811 810
		f 4 945 -827 824 797
		mu 0 4 812 813 814 815
		f 4 -829 -727 723 -828
		mu 0 4 816 817 818 819
		f 4 802 -940 942 941
		mu 0 4 820 821 822 823
		f 4 -832 -833 -803 799
		mu 0 4 824 825 821 820
		f 4 -835 831 734 -834
		mu 0 4 826 825 824 827
		f 4 -836 -837 833 709
		mu 0 4 828 829 826 827
		f 4 779 -839 835 721
		mu 0 4 830 831 829 828
		f 4 764 -841 -780 777
		mu 0 4 832 833 831 830
		f 4 750 -843 -765 762
		mu 0 4 834 835 833 832
		f 4 -844 -845 -751 748
		mu 0 4 836 837 835 834
		f 4 738 -847 843 705
		mu 0 4 784 838 839 785
		f 4 -825 -849 -741 746
		mu 0 4 815 814 840 841
		f 4 -852 849 826 912
		mu 0 4 765 764 814 813
		f 4 -854 -826 828 -853
		mu 0 4 736 735 817 816
		f 4 829 -938 940 939
		mu 0 4 821 752 753 822
		f 4 -857 -858 -830 832
		mu 0 4 825 724 752 821
		f 4 -860 856 834 -859
		mu 0 4 725 724 825 826
		f 4 -861 -862 858 836
		mu 0 4 829 727 725 826
		f 4 837 -864 860 838
		mu 0 4 831 726 727 829
		f 4 839 -866 -838 840
		mu 0 4 833 789 726 831
		f 4 841 -868 -840 842
		mu 0 4 835 769 789 833
		f 4 -869 -870 -842 844
		mu 0 4 837 766 769 835
		f 4 845 -872 868 846
		mu 0 4 838 728 729 839
		f 4 848 -850 -874 -848
		mu 0 4 840 814 764 804
		f 4 -876 -877 874 825
		mu 0 4 842 843 844 845
		f 4 747 -879 875 850
		mu 0 4 846 847 843 842
		f 4 -881 -748 -787 789
		mu 0 4 848 849 850 851
		f 4 -883 -790 -772 774
		mu 0 4 852 848 851 853
		f 4 -885 -775 -758 759
		mu 0 4 854 852 853 855
		f 4 -887 -760 -742 -886
		mu 0 4 856 854 855 857
		f 4 -889 885 -702 -888
		mu 0 4 858 859 779 778
		f 4 -890 -891 887 742
		mu 0 4 860 861 858 778
		f 4 -892 -893 889 755
		mu 0 4 862 863 861 860
		f 4 -894 -895 891 769
		mu 0 4 864 865 863 862
		f 4 -897 893 784 718
		mu 0 4 866 865 864 867
		f 4 -899 -719 716 706
		mu 0 4 868 866 867 869
		f 4 -901 -707 702 712
		mu 0 4 870 871 737 734
		f 4 -903 -713 710 855
		mu 0 4 872 870 734 736
		f 4 -905 -856 852 830
		mu 0 4 873 872 736 816
		f 4 -907 -831 827 707
		mu 0 4 874 873 816 819
		f 4 -909 -708 -724 -908
		mu 0 4 875 876 877 878
		f 4 -875 -910 907 726
		mu 0 4 845 844 879 880
		f 4 -949 -951 952 953
		mu 0 4 881 882 883 884
		f 4 877 -915 911 878
		mu 0 4 847 762 765 843
		f 4 -917 -878 880 879
		mu 0 4 761 760 849 848
		f 4 -919 -880 882 881
		mu 0 4 798 761 848 852
		f 4 -921 -882 884 883
		mu 0 4 782 798 852 854
		f 4 -923 -884 886 -922
		mu 0 4 783 782 854 856
		f 4 -925 921 888 -924
		mu 0 4 741 740 859 858
		f 4 -926 -927 923 890
		mu 0 4 861 774 741 858
		f 4 -928 -929 925 892
		mu 0 4 863 793 774 861
		f 4 -930 -931 927 894
		mu 0 4 865 744 793 863
		f 4 -933 929 896 895
		mu 0 4 745 744 865 866
		f 4 -935 -896 898 897
		mu 0 4 747 745 866 868
		f 4 -937 -898 900 899
		mu 0 4 751 750 871 870
		f 4 -939 -900 902 901
		mu 0 4 753 751 870 872
		f 4 -941 -902 904 903
		mu 0 4 822 753 872 873
		f 4 -943 -904 906 905
		mu 0 4 823 822 873 874
		f 4 -945 -906 908 -944
		mu 0 4 757 756 876 875
		f 4 909 -911 -946 943
		mu 0 4 879 844 813 812
		f 4 -912 946 948 -948
		mu 0 4 843 765 882 881
		f 4 -913 949 950 -947
		mu 0 4 765 813 883 882
		f 4 910 951 -953 -950
		mu 0 4 813 844 884 883
		f 4 876 947 -954 -952
		mu 0 4 844 843 881 884;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "room_vent";
	rename -uid "01C02E51-46DB-2FDC-3E58-4A9C39F22075";
	setAttr ".rp" -type "double3" 1.9272837518546744 22.191557982595377 -11.396492085864597 ;
	setAttr ".sp" -type "double3" 1.9272837518546744 22.191557982595377 -11.396492085864597 ;
createNode mesh -n "room_ventShape" -p "room_vent";
	rename -uid "1DD5D503-4D59-CE71-A56A-8CA7992CEC85";
	setAttr -k off ".v";
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:152]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 336 ".uvst[0].uvsp";
	setAttr ".uvst[0].uvsp[0:249]" -type "float2" 0.375 0 0.625 0 0.375 0.25
		 0.625 0.25 0.375 0.5 0.625 0.5 0.375 0.75 0.625 0.75 0.375 1 0.625 1 0.375 0.41666666
		 0.375 0.83333337 0.625 0.83333337 0.625 0.41666666 0.375 0.33333331 0.375 0.91666669
		 0.625 0.91666669 0.625 0.33333331 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331
		 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625
		 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625
		 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331
		 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625
		 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375
		 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625
		 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625
		 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625
		 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75
		 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375
		 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25
		 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375
		 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375
		 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331
		 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625
		 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625
		 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331
		 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625
		 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375
		 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625
		 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625
		 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625
		 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75
		 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375
		 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25
		 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375
		 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375
		 0.41666666 0.625 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331
		 0.375 0.33333331 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625
		 0.91666669 0.625 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625
		 0.41666666 0.375 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331
		 0.375 0.5 0.625 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625
		 1 0.375 1 0.625 0.83333337 0.375 0.83333337 0.375 0.41666666 0.625 0.41666666 0.375
		 0 0.625 0 0.625 0.25 0.375 0.25 0.625 0.33333331 0.375 0.33333331 0.375 0.5 0.625
		 0.5 0.625 0.75 0.375 0.75 0.375 0.91666669 0.625 0.91666669 0.625 1 0.375 1 0.625
		 0.83333337 0.375 0.83333337;
	setAttr ".uvst[0].uvsp[250:335]" 0.375 0.41666666 0.625 0.41666666 0.33333331
		 0.33333331 0.66666663 0.33333331 0.66666663 0.66666663 0.33333331 0.66666663 0.040813733
		 0.040816989 0 0 0.33333331 0 0.33333331 0.040816981 0.04081374 0.33333331 0 0.33333331
		 0.66666663 0 0.66666663 0.040816981 0.040813733 0.66666663 0 0.66666663 0.95918596
		 0.040816981 1 0 1 0.33333331 0.95918703 0.33333331 1 0.66666663 0.95918596 0.66666663
		 0.04081374 0.95918709 0 1 0.33333328 0.95918703 0.33333331 1 0.66666657 0.95918703
		 0.66666663 1 0.95918596 0.95918709 1 1 0.70748067 0.70748359 0.66666663 0.66666663
		 0.66666663 0.33333331 0.70748067 0.2925204 0.2925193 0.70748359 0.33333331 0.66666663
		 0.33333331 0.33333331 0.2925193 0.2925204 0 0.39995205 1 0.39995205 1 1 0 1 0 0.39995205
		 1 0.39995205 1 1 0 1 0 0.39995205 1 0.39995205 1 1 0 1 0 0.39995205 1 0.39995205
		 1 1 0 1 0 0.39995205 1 0.39995205 1 1 0 1 0 0.39995205 1 0.39995205 1 1 0 1 0 0.39995199
		 1 0.39995205 1 1 0 1 0 0.39995199 1 0.39995205 1 1 0 1 0 0.39995205 1 0.39995205
		 1 1 0 1 0 0.39995205 1 0.39995205 1 1 0 1 0 0.39995205 1 0.39995199 1 1 0 1 0 0.39995205
		 1 0.39995199 1 1 0 1;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 272 ".vt";
	setAttr ".vt[0:165]"  -0.93824822 21.89823151 -10.96958923 4.79281569 21.89823151 -10.96958923
		 -0.93824822 21.90540504 -10.9624157 4.79281569 21.90540504 -10.9624157 -0.93824822 22.058361053 -11.1153717
		 4.79281569 22.058361053 -11.1153717 -0.93824822 22.051187515 -11.12254524 4.79281569 22.051187515 -11.12254524
		 -0.93824822 22.018821716 -11.052940369 -0.93824822 21.98875618 -11.083005905 4.79281569 21.98875618 -11.083005905
		 4.79281569 22.018821716 -11.052940369 -0.93824822 21.96783638 -11.0019550323 -0.93824822 21.93777084 -11.032020569
		 4.79281569 21.93777084 -11.032020569 4.79281569 21.96783638 -11.0019550323 -0.93824822 21.60623169 -10.96958923
		 4.79281569 21.60623169 -10.96958923 -0.93824822 21.61340332 -10.9624157 4.79281569 21.61340332 -10.9624157
		 -0.93824822 21.76636124 -11.1153717 4.79281569 21.76636124 -11.1153717 -0.93824822 21.75918579 -11.12254524
		 4.79281569 21.75918579 -11.12254524 -0.93824822 21.7268219 -11.052940369 -0.93824822 21.69675446 -11.083005905
		 4.79281569 21.69675446 -11.083005905 4.79281569 21.7268219 -11.052940369 -0.93824822 21.67583466 -11.0019550323
		 -0.93824822 21.64577103 -11.032020569 4.79281569 21.64577103 -11.032020569 4.79281569 21.67583466 -11.0019550323
		 -0.93824822 22.48223114 -10.96958923 4.79281569 22.48223114 -10.96958923 -0.93824822 22.48940468 -10.9624157
		 4.79281569 22.48940468 -10.9624157 -0.93824822 22.64236069 -11.1153717 4.79281569 22.64236069 -11.1153717
		 -0.93824822 22.63518715 -11.12254524 4.79281569 22.63518715 -11.12254524 -0.93824822 22.60282135 -11.052940369
		 -0.93824822 22.57275581 -11.083005905 4.79281569 22.57275581 -11.083005905 4.79281569 22.60282135 -11.052940369
		 -0.93824822 22.55183601 -11.0019550323 -0.93824822 22.52177048 -11.032020569 4.79281569 22.52177048 -11.032020569
		 4.79281569 22.55183601 -11.0019550323 -0.93824822 22.77423096 -10.96958923 4.79281569 22.77423096 -10.96958923
		 -0.93824822 22.7814045 -10.9624157 4.79281569 22.7814045 -10.9624157 -0.93824822 22.9343605 -11.1153717
		 4.79281569 22.9343605 -11.1153717 -0.93824822 22.92718697 -11.12254524 4.79281569 22.92718697 -11.12254524
		 -0.93824822 22.89482117 -11.052940369 -0.93824822 22.86475563 -11.083005905 4.79281569 22.86475563 -11.083005905
		 4.79281569 22.89482117 -11.052940369 -0.93824822 22.84383583 -11.0019550323 -0.93824822 22.81377029 -11.032020569
		 4.79281569 22.81377029 -11.032020569 4.79281569 22.84383583 -11.0019550323 -0.93824822 21.16823006 -10.96958923
		 4.79281569 21.16823006 -10.96958923 -0.93824822 21.17540359 -10.9624157 4.79281569 21.17540359 -10.9624157
		 -0.93824822 21.3283596 -11.1153717 4.79281569 21.3283596 -11.1153717 -0.93824822 21.32118607 -11.12254524
		 4.79281569 21.32118607 -11.12254524 -0.93824822 21.28882027 -11.052940369 -0.93824822 21.25875473 -11.083005905
		 4.79281569 21.25875473 -11.083005905 4.79281569 21.28882027 -11.052940369 -0.93824822 21.23783493 -11.0019550323
		 -0.93824822 21.20776939 -11.032020569 4.79281569 21.20776939 -11.032020569 4.79281569 21.23783493 -11.0019550323
		 -0.93824822 22.33623123 -10.96958923 4.79281569 22.33623123 -10.96958923 -0.93824822 22.34340477 -10.9624157
		 4.79281569 22.34340477 -10.9624157 -0.93824822 22.49636078 -11.1153717 4.79281569 22.49636078 -11.1153717
		 -0.93824822 22.48918724 -11.12254524 4.79281569 22.48918724 -11.12254524 -0.93824822 22.45682144 -11.052940369
		 -0.93824822 22.42675591 -11.083005905 4.79281569 22.42675591 -11.083005905 4.79281569 22.45682144 -11.052940369
		 -0.93824822 22.40583611 -11.0019550323 -0.93824822 22.37577057 -11.032020569 4.79281569 22.37577057 -11.032020569
		 4.79281569 22.40583611 -11.0019550323 -0.93824822 21.7522316 -10.96958923 4.79281569 21.7522316 -10.96958923
		 -0.93824822 21.75940514 -10.9624157 4.79281569 21.75940514 -10.9624157 -0.93824822 21.91236115 -11.1153717
		 4.79281569 21.91236115 -11.1153717 -0.93824822 21.90518761 -11.12254524 4.79281569 21.90518761 -11.12254524
		 -0.93824822 21.87282181 -11.052940369 -0.93824822 21.84275627 -11.083005905 4.79281569 21.84275627 -11.083005905
		 4.79281569 21.87282181 -11.052940369 -0.93824822 21.82183647 -11.0019550323 -0.93824822 21.79177094 -11.032020569
		 4.79281569 21.79177094 -11.032020569 4.79281569 21.82183647 -11.0019550323 -0.93824822 22.92023087 -10.96958923
		 4.79281569 22.92023087 -10.96958923 -0.93824822 22.9274044 -10.9624157 4.79281569 22.9274044 -10.9624157
		 -0.93824822 23.080360413 -11.1153717 4.79281569 23.080360413 -11.1153717 -0.93824822 23.073186874 -11.12254524
		 4.79281569 23.073186874 -11.12254524 -0.93824822 23.040821075 -11.052940369 -0.93824822 23.010755539 -11.083005905
		 4.79281569 23.010755539 -11.083005905 4.79281569 23.040821075 -11.052940369 -0.93824822 22.98983574 -11.0019550323
		 -0.93824822 22.9597702 -11.032020569 4.79281569 22.9597702 -11.032020569 4.79281569 22.98983574 -11.0019550323
		 -0.93824822 21.31422997 -10.96958923 4.79281569 21.31422997 -10.96958923 -0.93824822 21.3214035 -10.9624157
		 4.79281569 21.3214035 -10.9624157 -0.93824822 21.47435951 -11.1153717 4.79281569 21.47435951 -11.1153717
		 -0.93824822 21.46718597 -11.12254524 4.79281569 21.46718597 -11.12254524 -0.93824822 21.43482018 -11.052940369
		 -0.93824822 21.40475464 -11.083005905 4.79281569 21.40475464 -11.083005905 4.79281569 21.43482018 -11.052940369
		 -0.93824822 21.38383484 -11.0019550323 -0.93824822 21.3537693 -11.032020569 4.79281569 21.3537693 -11.032020569
		 4.79281569 21.38383484 -11.0019550323 -0.93824822 22.044231415 -10.96958923 4.79281569 22.044231415 -10.96958923
		 -0.93824822 22.051404953 -10.9624157 4.79281569 22.051404953 -10.9624157 -0.93824822 22.20436096 -11.1153717
		 4.79281569 22.20436096 -11.1153717 -0.93824822 22.19718742 -11.12254524 4.79281569 22.19718742 -11.12254524
		 -0.93824822 22.16482162 -11.052940369 -0.93824822 22.13475609 -11.083005905 4.79281569 22.13475609 -11.083005905
		 4.79281569 22.16482162 -11.052940369 -0.93824822 22.11383629 -11.0019550323 -0.93824822 22.083770752 -11.032020569
		 4.79281569 22.083770752 -11.032020569 4.79281569 22.11383629 -11.0019550323 -0.93824822 22.19023132 -10.96958923
		 4.79281569 22.19023132 -10.96958923 -0.93824822 22.19740486 -10.9624157 4.79281569 22.19740486 -10.9624157
		 -0.93824822 22.35036087 -11.1153717 4.79281569 22.35036087 -11.1153717;
	setAttr ".vt[166:271]" -0.93824822 22.34318733 -11.12254524 4.79281569 22.34318733 -11.12254524
		 -0.93824822 22.31082153 -11.052940369 -0.93824822 22.280756 -11.083005905 4.79281569 22.280756 -11.083005905
		 4.79281569 22.31082153 -11.052940369 -0.93824822 22.2598362 -11.0019550323 -0.93824822 22.22977066 -11.032020569
		 4.79281569 22.22977066 -11.032020569 4.79281569 22.2598362 -11.0019550323 -0.93824822 22.62823105 -10.96958923
		 4.79281569 22.62823105 -10.96958923 -0.93824822 22.63540459 -10.9624157 4.79281569 22.63540459 -10.9624157
		 -0.93824822 22.7883606 -11.1153717 4.79281569 22.7883606 -11.1153717 -0.93824822 22.78118706 -11.12254524
		 4.79281569 22.78118706 -11.12254524 -0.93824822 22.74882126 -11.052940369 -0.93824822 22.71875572 -11.083005905
		 4.79281569 22.71875572 -11.083005905 4.79281569 22.74882126 -11.052940369 -0.93824822 22.69783592 -11.0019550323
		 -0.93824822 22.66777039 -11.032020569 4.79281569 22.66777039 -11.032020569 4.79281569 22.69783592 -11.0019550323
		 -0.93824822 21.46023178 -10.96958923 4.79281569 21.46023178 -10.96958923 -0.93824822 21.46740341 -10.9624157
		 4.79281569 21.46740341 -10.9624157 -0.93824822 21.62036133 -11.1153717 4.79281569 21.62036133 -11.1153717
		 -0.93824822 21.61318588 -11.12254524 4.79281569 21.61318588 -11.12254524 -0.93824822 21.58082199 -11.052940369
		 -0.93824822 21.55075455 -11.083005905 4.79281569 21.55075455 -11.083005905 4.79281569 21.58082199 -11.052940369
		 -0.93824822 21.52983475 -11.0019550323 -0.93824822 21.49977112 -11.032020569 4.79281569 21.49977112 -11.032020569
		 4.79281569 21.52983475 -11.0019550323 -0.93824822 23.066230774 -10.96958923 4.79281569 23.066230774 -10.96958923
		 -0.93824822 23.073404312 -10.9624157 4.79281569 23.073404312 -10.9624157 -0.93824822 23.22636032 -11.1153717
		 4.79281569 23.22636032 -11.1153717 -0.93824822 23.21918678 -11.12254524 4.79281569 23.21918678 -11.12254524
		 -0.93824822 23.18682098 -11.052940369 -0.93824822 23.15675545 -11.083005905 4.79281569 23.15675545 -11.083005905
		 4.79281569 23.18682098 -11.052940369 -0.93824822 23.13583565 -11.0019550323 -0.93824822 23.10577011 -11.032020569
		 4.79281569 23.10577011 -11.032020569 4.79281569 23.13583565 -11.0019550323 -1.0095481873 20.93067551 -11
		 -0.80954814 20.93067551 -11 -1.0095481873 21.13067627 -11 4.86411572 20.93067551 -11
		 4.86411572 21.13067627 -11 -1.0095481873 23.45244026 -11 -0.80954814 23.45244026 -11
		 4.66411591 23.45244026 -11 4.86411572 23.45244026 -11 4.66411591 20.93067551 -11
		 4.86411572 23.2524395 -11 -1.0095481873 23.2524395 -11 4.66411591 21.13067627 -11.85421085
		 -0.80954814 21.13067627 -11.85421085 4.66411591 23.2524395 -11.85421085 -0.80954814 23.2524395 -11.85421085
		 -0.98505998 20.95516586 -10.93877316 -1.0095481873 20.93067551 -10.9632597 -0.80954814 20.95516586 -10.93877316
		 -0.80954814 20.93067551 -10.9632597 -0.98505998 21.13067627 -10.93877316 -1.0095481873 21.13067627 -10.9632597
		 4.83962727 20.95516586 -10.93877316 4.86411572 20.93067551 -10.9632597 4.83962727 21.13067627 -10.93877316
		 4.86411572 21.13067627 -10.9632597 -0.98505998 23.42795181 -10.93877316 -1.0095481873 23.45244026 -10.9632597
		 -0.80954814 23.42795181 -10.93877316 -0.80954814 23.45244026 -10.9632597 4.83962727 23.42795181 -10.93877316
		 4.86411572 23.45244026 -10.9632597 4.66411591 23.42795181 -10.93877316 4.66411591 23.45244026 -10.9632597
		 4.66411591 20.95516586 -10.93877316 4.66411591 20.93067551 -10.9632597 4.83962727 23.2524395 -10.93877316
		 4.86411572 23.2524395 -10.9632597 4.68860435 23.27692986 -10.93877316 4.66411591 23.2524395 -10.9632597
		 4.68860435 21.10618782 -10.93877316 4.66411591 21.13067627 -10.9632597 -0.83403659 23.27692986 -10.93877316
		 -0.80954814 23.2524395 -10.9632597 -0.83403659 21.10618782 -10.93877316 -0.80954814 21.13067627 -10.9632597
		 -0.98505998 23.2524395 -10.93877316 -1.0095481873 23.2524395 -10.9632597;
	setAttr -s 424 ".ed";
	setAttr ".ed[0:165]"  0 1 0 2 3 0 4 5 0 6 7 0 0 2 0 1 3 0 2 12 0 3 15 0 4 6 0
		 5 7 0 6 9 0 7 10 0 8 4 0 9 13 0 10 14 0 9 10 1 11 5 0 11 8 1 12 8 0 13 0 0 14 1 0
		 13 14 1 15 11 0 15 12 1 16 17 0 18 19 0 20 21 0 22 23 0 16 18 0 17 19 0 18 28 0 19 31 0
		 20 22 0 21 23 0 22 25 0 23 26 0 24 20 0 25 29 0 26 30 0 25 26 1 27 21 0 27 24 1 28 24 0
		 29 16 0 30 17 0 29 30 1 31 27 0 31 28 1 32 33 0 34 35 0 36 37 0 38 39 0 32 34 0 33 35 0
		 34 44 0 35 47 0 36 38 0 37 39 0 38 41 0 39 42 0 40 36 0 41 45 0 42 46 0 41 42 1 43 37 0
		 43 40 1 44 40 0 45 32 0 46 33 0 45 46 1 47 43 0 47 44 1 48 49 0 50 51 0 52 53 0 54 55 0
		 48 50 0 49 51 0 50 60 0 51 63 0 52 54 0 53 55 0 54 57 0 55 58 0 56 52 0 57 61 0 58 62 0
		 57 58 1 59 53 0 59 56 1 60 56 0 61 48 0 62 49 0 61 62 1 63 59 0 63 60 1 64 65 0 66 67 0
		 68 69 0 70 71 0 64 66 0 65 67 0 66 76 0 67 79 0 68 70 0 69 71 0 70 73 0 71 74 0 72 68 0
		 73 77 0 74 78 0 73 74 1 75 69 0 75 72 1 76 72 0 77 64 0 78 65 0 77 78 1 79 75 0 79 76 1
		 80 81 0 82 83 0 84 85 0 86 87 0 80 82 0 81 83 0 82 92 0 83 95 0 84 86 0 85 87 0 86 89 0
		 87 90 0 88 84 0 89 93 0 90 94 0 89 90 1 91 85 0 91 88 1 92 88 0 93 80 0 94 81 0 93 94 1
		 95 91 0 95 92 1 96 97 0 98 99 0 100 101 0 102 103 0 96 98 0 97 99 0 98 108 0 99 111 0
		 100 102 0 101 103 0 102 105 0 103 106 0 104 100 0 105 109 0 106 110 0 105 106 1 107 101 0
		 107 104 1 108 104 0 109 96 0 110 97 0 109 110 1;
	setAttr ".ed[166:331]" 111 107 0 111 108 1 112 113 0 114 115 0 116 117 0 118 119 0
		 112 114 0 113 115 0 114 124 0 115 127 0 116 118 0 117 119 0 118 121 0 119 122 0 120 116 0
		 121 125 0 122 126 0 121 122 1 123 117 0 123 120 1 124 120 0 125 112 0 126 113 0 125 126 1
		 127 123 0 127 124 1 128 129 0 130 131 0 132 133 0 134 135 0 128 130 0 129 131 0 130 140 0
		 131 143 0 132 134 0 133 135 0 134 137 0 135 138 0 136 132 0 137 141 0 138 142 0 137 138 1
		 139 133 0 139 136 1 140 136 0 141 128 0 142 129 0 141 142 1 143 139 0 143 140 1 144 145 0
		 146 147 0 148 149 0 150 151 0 144 146 0 145 147 0 146 156 0 147 159 0 148 150 0 149 151 0
		 150 153 0 151 154 0 152 148 0 153 157 0 154 158 0 153 154 1 155 149 0 155 152 1 156 152 0
		 157 144 0 158 145 0 157 158 1 159 155 0 159 156 1 160 161 0 162 163 0 164 165 0 166 167 0
		 160 162 0 161 163 0 162 172 0 163 175 0 164 166 0 165 167 0 166 169 0 167 170 0 168 164 0
		 169 173 0 170 174 0 169 170 1 171 165 0 171 168 1 172 168 0 173 160 0 174 161 0 173 174 1
		 175 171 0 175 172 1 176 177 0 178 179 0 180 181 0 182 183 0 176 178 0 177 179 0 178 188 0
		 179 191 0 180 182 0 181 183 0 182 185 0 183 186 0 184 180 0 185 189 0 186 190 0 185 186 1
		 187 181 0 187 184 1 188 184 0 189 176 0 190 177 0 189 190 1 191 187 0 191 188 1 192 193 0
		 194 195 0 196 197 0 198 199 0 192 194 0 193 195 0 194 204 0 195 207 0 196 198 0 197 199 0
		 198 201 0 199 202 0 200 196 0 201 205 0 202 206 0 201 202 1 203 197 0 203 200 1 204 200 0
		 205 192 0 206 193 0 205 206 1 207 203 0 207 204 1 208 209 0 210 211 0 212 213 0 214 215 0
		 208 210 0 209 211 0 210 220 0 211 223 0 212 214 0 213 215 0 214 217 0 215 218 0 216 212 0
		 217 221 0 218 222 0 217 218 1 219 213 0 219 216 1 220 216 0 221 208 0;
	setAttr ".ed[332:423]" 222 209 0 221 222 1 223 219 0 223 220 1 224 225 0 224 226 0
		 227 228 0 229 230 0 231 232 0 233 227 0 230 231 0 225 233 0 234 232 0 235 229 0 228 234 0
		 226 235 0 236 237 0 238 236 0 238 239 0 239 237 0 240 241 0 241 243 0 243 242 1 242 240 0
		 240 244 0 244 245 1 245 241 0 243 259 0 259 258 1 258 242 0 244 270 0 270 271 1 271 245 0
		 246 247 0 247 249 0 249 248 1 248 246 0 246 258 0 259 247 0 249 261 0 261 260 1 260 248 0
		 250 251 0 251 271 0 270 250 0 250 252 0 252 253 1 253 251 0 252 256 0 256 257 1 257 253 0
		 254 255 0 255 257 0 256 254 0 254 260 0 261 255 0 262 263 0 263 265 0 265 264 0 264 262 0
		 262 266 0 266 267 0 267 263 0 265 269 0 269 268 0 268 264 0 266 268 0 269 267 0 248 264 1
		 264 258 1 268 242 1 268 244 1 262 260 1 256 262 1 252 266 1 270 266 1 241 224 0 225 243 1
		 245 226 1 247 227 0 228 249 1 253 230 1 229 251 0 255 232 0 231 257 1 259 233 1 261 234 1
		 235 271 1 265 236 0 237 269 0 263 238 0 267 239 0;
	setAttr -s 153 -ch 612 ".fc[0:152]" -type "polyFaces" 
		f 4 0 5 -2 -5
		mu 0 4 0 1 3 2
		f 4 1 7 23 -7
		mu 0 4 2 3 17 14
		f 4 2 9 -4 -9
		mu 0 4 4 5 7 6
		f 4 21 20 -1 -20
		mu 0 4 15 16 9 8
		f 4 3 11 -16 -11
		mu 0 4 6 7 12 11
		f 4 -18 16 -3 -13
		mu 0 4 10 13 5 4
		f 4 15 14 -22 -14
		mu 0 4 11 12 16 15
		f 4 -24 22 17 -19
		mu 0 4 14 17 13 10
		f 4 24 29 -26 -29
		mu 0 4 18 19 20 21
		f 4 25 31 47 -31
		mu 0 4 21 20 22 23
		f 4 26 33 -28 -33
		mu 0 4 24 25 26 27
		f 4 45 44 -25 -44
		mu 0 4 28 29 30 31
		f 4 27 35 -40 -35
		mu 0 4 27 26 32 33
		f 4 -42 40 -27 -37
		mu 0 4 34 35 25 24
		f 4 39 38 -46 -38
		mu 0 4 33 32 29 28
		f 4 -48 46 41 -43
		mu 0 4 23 22 35 34
		f 4 48 53 -50 -53
		mu 0 4 36 37 38 39
		f 4 49 55 71 -55
		mu 0 4 39 38 40 41
		f 4 50 57 -52 -57
		mu 0 4 42 43 44 45
		f 4 69 68 -49 -68
		mu 0 4 46 47 48 49
		f 4 51 59 -64 -59
		mu 0 4 45 44 50 51
		f 4 -66 64 -51 -61
		mu 0 4 52 53 43 42
		f 4 63 62 -70 -62
		mu 0 4 51 50 47 46
		f 4 -72 70 65 -67
		mu 0 4 41 40 53 52
		f 4 72 77 -74 -77
		mu 0 4 54 55 56 57
		f 4 73 79 95 -79
		mu 0 4 57 56 58 59
		f 4 74 81 -76 -81
		mu 0 4 60 61 62 63
		f 4 93 92 -73 -92
		mu 0 4 64 65 66 67
		f 4 75 83 -88 -83
		mu 0 4 63 62 68 69
		f 4 -90 88 -75 -85
		mu 0 4 70 71 61 60
		f 4 87 86 -94 -86
		mu 0 4 69 68 65 64
		f 4 -96 94 89 -91
		mu 0 4 59 58 71 70
		f 4 96 101 -98 -101
		mu 0 4 72 73 74 75
		f 4 97 103 119 -103
		mu 0 4 75 74 76 77
		f 4 98 105 -100 -105
		mu 0 4 78 79 80 81
		f 4 117 116 -97 -116
		mu 0 4 82 83 84 85
		f 4 99 107 -112 -107
		mu 0 4 81 80 86 87
		f 4 -114 112 -99 -109
		mu 0 4 88 89 79 78
		f 4 111 110 -118 -110
		mu 0 4 87 86 83 82
		f 4 -120 118 113 -115
		mu 0 4 77 76 89 88
		f 4 120 125 -122 -125
		mu 0 4 90 91 92 93
		f 4 121 127 143 -127
		mu 0 4 93 92 94 95
		f 4 122 129 -124 -129
		mu 0 4 96 97 98 99
		f 4 141 140 -121 -140
		mu 0 4 100 101 102 103
		f 4 123 131 -136 -131
		mu 0 4 99 98 104 105
		f 4 -138 136 -123 -133
		mu 0 4 106 107 97 96
		f 4 135 134 -142 -134
		mu 0 4 105 104 101 100
		f 4 -144 142 137 -139
		mu 0 4 95 94 107 106
		f 4 144 149 -146 -149
		mu 0 4 108 109 110 111
		f 4 145 151 167 -151
		mu 0 4 111 110 112 113
		f 4 146 153 -148 -153
		mu 0 4 114 115 116 117
		f 4 165 164 -145 -164
		mu 0 4 118 119 120 121
		f 4 147 155 -160 -155
		mu 0 4 117 116 122 123
		f 4 -162 160 -147 -157
		mu 0 4 124 125 115 114
		f 4 159 158 -166 -158
		mu 0 4 123 122 119 118
		f 4 -168 166 161 -163
		mu 0 4 113 112 125 124
		f 4 168 173 -170 -173
		mu 0 4 126 127 128 129
		f 4 169 175 191 -175
		mu 0 4 129 128 130 131
		f 4 170 177 -172 -177
		mu 0 4 132 133 134 135
		f 4 189 188 -169 -188
		mu 0 4 136 137 138 139
		f 4 171 179 -184 -179
		mu 0 4 135 134 140 141
		f 4 -186 184 -171 -181
		mu 0 4 142 143 133 132
		f 4 183 182 -190 -182
		mu 0 4 141 140 137 136
		f 4 -192 190 185 -187
		mu 0 4 131 130 143 142
		f 4 192 197 -194 -197
		mu 0 4 144 145 146 147
		f 4 193 199 215 -199
		mu 0 4 147 146 148 149
		f 4 194 201 -196 -201
		mu 0 4 150 151 152 153
		f 4 213 212 -193 -212
		mu 0 4 154 155 156 157
		f 4 195 203 -208 -203
		mu 0 4 153 152 158 159
		f 4 -210 208 -195 -205
		mu 0 4 160 161 151 150
		f 4 207 206 -214 -206
		mu 0 4 159 158 155 154
		f 4 -216 214 209 -211
		mu 0 4 149 148 161 160
		f 4 216 221 -218 -221
		mu 0 4 162 163 164 165
		f 4 217 223 239 -223
		mu 0 4 165 164 166 167
		f 4 218 225 -220 -225
		mu 0 4 168 169 170 171
		f 4 237 236 -217 -236
		mu 0 4 172 173 174 175
		f 4 219 227 -232 -227
		mu 0 4 171 170 176 177
		f 4 -234 232 -219 -229
		mu 0 4 178 179 169 168
		f 4 231 230 -238 -230
		mu 0 4 177 176 173 172
		f 4 -240 238 233 -235
		mu 0 4 167 166 179 178
		f 4 240 245 -242 -245
		mu 0 4 180 181 182 183
		f 4 241 247 263 -247
		mu 0 4 183 182 184 185
		f 4 242 249 -244 -249
		mu 0 4 186 187 188 189
		f 4 261 260 -241 -260
		mu 0 4 190 191 192 193
		f 4 243 251 -256 -251
		mu 0 4 189 188 194 195
		f 4 -258 256 -243 -253
		mu 0 4 196 197 187 186
		f 4 255 254 -262 -254
		mu 0 4 195 194 191 190
		f 4 -264 262 257 -259
		mu 0 4 185 184 197 196
		f 4 264 269 -266 -269
		mu 0 4 198 199 200 201
		f 4 265 271 287 -271
		mu 0 4 201 200 202 203
		f 4 266 273 -268 -273
		mu 0 4 204 205 206 207
		f 4 285 284 -265 -284
		mu 0 4 208 209 210 211
		f 4 267 275 -280 -275
		mu 0 4 207 206 212 213
		f 4 -282 280 -267 -277
		mu 0 4 214 215 205 204
		f 4 279 278 -286 -278
		mu 0 4 213 212 209 208
		f 4 -288 286 281 -283
		mu 0 4 203 202 215 214
		f 4 288 293 -290 -293
		mu 0 4 216 217 218 219
		f 4 289 295 311 -295
		mu 0 4 219 218 220 221
		f 4 290 297 -292 -297
		mu 0 4 222 223 224 225
		f 4 309 308 -289 -308
		mu 0 4 226 227 228 229
		f 4 291 299 -304 -299
		mu 0 4 225 224 230 231
		f 4 -306 304 -291 -301
		mu 0 4 232 233 223 222
		f 4 303 302 -310 -302
		mu 0 4 231 230 227 226
		f 4 -312 310 305 -307
		mu 0 4 221 220 233 232
		f 4 312 317 -314 -317
		mu 0 4 234 235 236 237
		f 4 313 319 335 -319
		mu 0 4 237 236 238 239
		f 4 314 321 -316 -321
		mu 0 4 240 241 242 243
		f 4 333 332 -313 -332
		mu 0 4 244 245 246 247
		f 4 315 323 -328 -323
		mu 0 4 243 242 248 249
		f 4 -330 328 -315 -325
		mu 0 4 250 251 241 240
		f 4 327 326 -334 -326
		mu 0 4 249 248 245 244
		f 4 -336 334 329 -331
		mu 0 4 239 238 251 250
		f 4 -349 -350 350 351
		mu 0 4 252 253 254 255
		f 4 352 353 354 355
		mu 0 4 256 257 258 259
		f 4 -353 356 357 358
		mu 0 4 257 256 260 261
		f 4 -355 359 360 361
		mu 0 4 259 258 262 263
		f 4 -358 362 363 364
		mu 0 4 261 260 264 265
		f 4 365 366 367 368
		mu 0 4 266 267 268 269
		f 4 -366 369 -361 370
		mu 0 4 267 266 263 262
		f 4 -368 371 372 373
		mu 0 4 269 268 270 271
		f 4 374 375 -364 376
		mu 0 4 272 273 265 264
		f 4 -375 377 378 379
		mu 0 4 273 272 274 275
		f 4 -379 380 381 382
		mu 0 4 275 274 276 277
		f 4 383 384 -382 385
		mu 0 4 278 279 277 276
		f 4 -384 386 -373 387
		mu 0 4 279 278 271 270
		f 4 388 389 390 391
		mu 0 4 280 281 282 283
		f 4 -389 392 393 394
		mu 0 4 281 280 284 285
		f 4 -391 395 396 397
		mu 0 4 283 282 286 287
		f 4 -394 398 -397 399
		mu 0 4 285 284 287 286
		f 4 -370 -369 400 401
		mu 0 4 263 266 269 283
		f 4 -362 -402 -398 402
		mu 0 4 259 263 283 287
		f 4 -356 -403 403 -357
		mu 0 4 256 259 287 260
		f 4 404 -387 -386 405
		mu 0 4 280 271 278 276
		f 4 -393 -406 -381 406
		mu 0 4 284 280 276 274
		f 4 407 -407 -378 -377
		mu 0 4 264 284 274 272
		f 4 -401 -374 -405 -392
		mu 0 4 283 269 271 280
		f 4 -404 -399 -408 -363
		mu 0 4 260 287 284 264
		f 4 -354 408 336 409
		mu 0 4 288 289 290 291
		f 4 -359 410 -338 -409
		mu 0 4 292 293 294 295
		f 4 -367 411 338 412
		mu 0 4 296 297 298 299
		f 4 -380 413 -340 414
		mu 0 4 300 301 302 303
		f 4 -385 415 -341 416
		mu 0 4 304 305 306 307
		f 4 -371 417 341 -412
		mu 0 4 308 309 310 311
		f 4 -383 -417 -343 -414
		mu 0 4 312 313 314 315
		f 4 -360 -410 343 -418
		mu 0 4 316 317 318 319
		f 4 -388 418 344 -416
		mu 0 4 320 321 322 323
		f 4 -376 -415 -346 419
		mu 0 4 324 325 326 327
		f 4 -372 -413 346 -419
		mu 0 4 328 329 330 331
		f 4 -365 -420 -348 -411
		mu 0 4 332 333 334 335
		f 4 -396 420 348 421
		mu 0 4 286 282 253 252
		f 4 -390 422 349 -421
		mu 0 4 282 281 254 253
		f 4 -395 423 -351 -423
		mu 0 4 281 285 255 254
		f 4 -400 -422 -352 -424
		mu 0 4 285 286 252 255;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "floor";
	rename -uid "10B11AAB-4D94-05E1-DCA5-6DAA7111A481";
	setAttr ".t" -type "double3" -15.476354122161865 1.0000003998908453 2.7736458778381348 ;
	setAttr ".s" -type "double3" 13.325196196809312 6.9527081075907669 16.738639756723533 ;
	setAttr ".rp" -type "double3" 3.4763541221618652 0 0.60135385082593429 ;
	setAttr ".sp" -type "double3" 0.50000000983307236 0 0.086492031812667847 ;
	setAttr ".spt" -type "double3" 2.9763541123287931 0 0.51486181901326644 ;
createNode mesh -n "floorShape" -p "floor";
	rename -uid "7007D083-44C8-708F-6129-7B9E13046F37";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 5 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "back";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "e[3]";
	setAttr ".gtag[1].gtagnm" -type "string" "front";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 1 "e[0]";
	setAttr ".gtag[2].gtagnm" -type "string" "left";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 1 "e[1]";
	setAttr ".gtag[3].gtagnm" -type "string" "right";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "e[2]";
	setAttr ".gtag[4].gtagnm" -type "string" "rim";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "e[0:3]";
	setAttr ".pv" -type "double2" 0.30781857669353485 0.19100083597004414 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 19 ".uvst[0].uvsp[0:18]" -type "float2" 0.48200637 0.059950739
		 0.17596877 0.78988183 0.48200649 0.78988177 0.48200643 0.40472785 0.17596875 0.40472791
		 0.48200643 0.20236395 0.51720029 0.20236395 0.51720035 0.40472782 1 0.20236388 0.99999988
		 0.40472776 0.51720035 6.6125871e-08 0.99999988 0 1 0.51799327 0.51720035 0.51799333
		 0 0.96585023 3.3062936e-08 0.5806964 0.17596874 0.32205093 0.2963863 0.202364 0.43966848
		 0.059950743;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 19 ".vt[0:18]"  0.5 0 0.49999949 -0.1525836 0 -0.73907244
		 0.5 0 -0.73907244 0.5 0 -0.085266262 -0.1525836 0 -0.085266262 0.5 0 0.25825033 0.57504618 0 0.25825033
		 0.57504618 0 -0.085266262 1.60455036 0 0.25825033 1.60455036 0 -0.085266262 0.57504618 0 0.60176688
		 1.60455036 0 0.60176688 0.57504618 0 -0.27753657 1.60455036 0 -0.27753657 -0.52781284 0 -0.38397601
		 -0.52781284 0 -1.037782073 -0.1525836 0 0.055079494 0.10419045 0 0.25825033 0.40972027 0 0.49999949;
	setAttr -s 26 ".ed[0:25]"  0 5 0 1 2 0 3 2 0 4 1 0 3 4 1 5 3 0 5 17 1
		 5 6 0 3 7 0 6 7 0 6 8 0 7 9 0 8 9 0 6 10 0 8 11 0 10 11 0 7 12 0 9 13 0 12 13 0 4 14 0
		 1 15 0 14 15 0 16 4 0 18 0 0 16 17 1 17 18 1;
	setAttr -s 8 -ch 33 ".fc[0:7]" -type "polyFaces" 
		f 4 25 23 0 6
		mu 0 4 17 18 0 5
		f 4 -5 2 -2 -4
		mu 0 4 4 3 2 1
		f 5 24 -7 5 4 -23
		mu 0 5 16 17 5 3 4
		f 4 -6 7 9 -9
		mu 0 4 3 5 6 7
		f 4 -10 10 12 -12
		mu 0 4 7 6 8 9
		f 4 -11 13 15 -15
		mu 0 4 8 6 10 11
		f 4 11 17 -19 -17
		mu 0 4 7 9 12 13
		f 4 3 20 -22 -20
		mu 0 4 4 1 14 15;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 8 
		1 0 
		3 0 
		4 0 
		5 0 
		6 0 
		7 0 
		8 0 
		9 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
	setAttr ".dr" 1;
	setAttr ".rman_preventPolyCracks" yes;
createNode transform -n "drain";
	rename -uid "A9C81486-4C9D-F445-C27E-AEAB3E456998";
	setAttr ".rp" -type "double3" -3.6408252716064453 1.0000003576278687 4.1408281326293945 ;
	setAttr ".sp" -type "double3" -3.6408252716064453 1.0000003576278687 4.1408281326293945 ;
createNode mesh -n "drainShape" -p "drain";
	rename -uid "6E5E1887-406A-5264-F16E-91A7BCF5EA0D";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 8 ".uvst[0].uvsp[0:7]" -type "float2" 9.894371e-06 0.067941427
		 0 0 0.99999011 -0.00014576316 1 0.067795634 1.000000119209 0.067809589 8.9406967e-06
		 0.067941852 0 0 0.999991 -0.0001322031;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 8 ".vt[0:7]"  2.71834946 1.000000357628 -2.71834373 3.71834469 1.000000357628 -2.71834373
		 2.71834946 1.000000357628 12 3.71834469 1.000000357628 12 -10.99999523 1.000000357628 -2.71834373
		 -10.99999523 1.000000357628 -3.71834373 3.71834469 1.000000357628 -3.71834373 3.71834469 1.000000357628 -2.71834373;
	setAttr -s 8 ".ed[0:7]"  0 1 0 0 2 0 1 3 0 2 3 0 4 5 0 5 6 0 7 6 0
		 4 7 0;
	setAttr -s 2 -ch 8 ".fc[0:1]" -type "polyFaces" 
		f 4 -1 1 3 -3
		mu 0 4 0 1 2 3
		f 4 -6 -5 7 6
		mu 0 4 4 5 6 7;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "light_1";
	rename -uid "A13B510D-40FB-27D3-AD89-6481C7EB5B9E";
	setAttr ".t" -type "double3" -6.9999997594402181 19.203130489509515 -11.667950341422319 ;
	setAttr ".r" -type "double3" 90.000000000000028 0 0 ;
	setAttr ".s" -type "double3" 0.80718468363826879 0.80718468363826879 0.80718468363826879 ;
createNode mesh -n "light_Shape1" -p "light_1";
	rename -uid "FA598C67-4D12-002E-899A-63B7560C9B16";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 51 ".uvst[0].uvsp[0:50]" -type "float2" 0.57750899 0.85354167
		 0.57567054 0.86317891 0.5 0.83749998 0.57263881 0.87250972 0.56846148 0.881387 0.56320447
		 0.88967073 0.55695069 0.89723027 0.54979879 0.90394634 0.54186147 0.90971315 0.53326404
		 0.91443962 0.52414197 0.9180513 0.5146392 0.92049122 0.50490552 0.92172086 0.49509451
		 0.92172086 0.48536086 0.92049122 0.47585806 0.9180513 0.46673602 0.91443968 0.45813853
		 0.90971315 0.45020124 0.9039464 0.44304931 0.89723027 0.43679553 0.88967073 0.43153852
		 0.88138705 0.42736119 0.87250978 0.4243294 0.86317897 0.42249101 0.85354173 0.42187497
		 0.84375 0.42249101 0.83395839 0.4243294 0.82432115 0.42736116 0.81499028 0.43153849
		 0.806113 0.43679547 0.79782927 0.44304925 0.79026973 0.45020118 0.7835536 0.45813847
		 0.77778685 0.46673593 0.77306038 0.475858 0.76944864 0.48536077 0.76700878 0.49509445
		 0.76577914 0.50490546 0.76577914 0.51463914 0.76700872 0.52414191 0.76944864 0.53326398
		 0.77306032 0.54186147 0.77778679 0.54979873 0.7835536 0.55695069 0.79026967 0.56320447
		 0.79782915 0.56846148 0.80611289 0.57263881 0.81499016 0.5756706 0.82432103 0.57750905
		 0.83395827 0.578125 0.84375;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 51 ".vt[0:50]"  0 0.87613964 0 0.82721132 0.87613964 -0.10450104
		 0.80759102 0.87613964 -0.20735411 0.77523434 0.87613964 -0.30693704 0.73065209 0.87613964 -0.4016794
		 0.67454672 0.87613964 -0.49008694 0.60780358 0.87613964 -0.5707655 0.53147507 0.87613964 -0.64244294
		 0.44676468 0.87613964 -0.70398843 0.35500869 0.87613964 -0.75443161 0.25765401 0.87613964 -0.79297745
		 0.15623587 0.87613964 -0.81901705 0.052353844 0.87613964 -0.83214056 -0.052353799 0.87613964 -0.83214021
		 -0.15623578 0.87613964 -0.81901699 -0.2576538 0.87613964 -0.79297709 -0.35500848 0.87613964 -0.75443161
		 -0.44676456 0.87613964 -0.70398819 -0.53147483 0.87613964 -0.64244282 -0.60780334 0.87613964 -0.5707655
		 -0.67454666 0.87613964 -0.49008667 -0.73065162 0.87613964 -0.40167904 -0.77523416 0.87613964 -0.30693668
		 -0.80759048 0.87613964 -0.20735386 -0.82721043 0.87613964 -0.10450087 -0.83378541 0.87613964 1.7028651e-07
		 -0.82721043 0.87613964 0.10450119 -0.80759048 0.87613964 0.20735413 -0.77523363 0.87613964 0.30693707
		 -0.73065138 0.87613964 0.40167937 -0.67454636 0.87613964 0.49008691 -0.60780323 0.87613964 0.5707655
		 -0.53147465 0.87613964 0.64244282 -0.44676438 0.87613964 0.70398855 -0.35500827 0.87613964 0.7544319
		 -0.25765356 0.87613964 0.79297733 -0.15623559 0.87613964 0.81901693 -0.052353635 0.87613964 0.83214021
		 0.052353978 0.87613964 0.83213985 0.15623589 0.87613964 0.8190167 0.25765401 0.87613964 0.79297674
		 0.35500863 0.87613964 0.75443125 0.44676441 0.87613964 0.70398808 0.53147483 0.87613964 0.64244258
		 0.60780323 0.87613964 0.57076514 0.67454636 0.87613964 0.49008667 0.73065132 0.87613964 0.40167916
		 0.77523386 0.87613964 0.3069368 0.80759025 0.87613964 0.20735401 0.82721031 0.87613964 0.10450108
		 0.83378506 0.87613964 8.95281e-08;
	setAttr -s 100 ".ed[0:99]"  2 0 1 1 0 1 3 0 1 4 0 1 5 0 1 6 0 1 7 0 1
		 8 0 1 9 0 1 10 0 1 11 0 1 12 0 1 13 0 1 14 0 1 15 0 1 16 0 1 17 0 1 18 0 1 19 0 1
		 20 0 1 21 0 1 22 0 1 23 0 1 24 0 1 25 0 1 26 0 1 27 0 1 28 0 1 29 0 1 30 0 1 31 0 1
		 32 0 1 33 0 1 34 0 1 35 0 1 36 0 1 37 0 1 38 0 1 39 0 1 40 0 1 41 0 1 42 0 1 43 0 1
		 44 0 1 45 0 1 46 0 1 47 0 1 48 0 1 49 0 1 50 0 1 1 2 0 2 3 0 3 4 0 4 5 0 5 6 0 6 7 0
		 7 8 0 8 9 0 9 10 0 10 11 0 11 12 0 12 13 0 13 14 0 14 15 0 15 16 0 16 17 0 17 18 0
		 18 19 0 19 20 0 20 21 0 21 22 0 22 23 0 23 24 0 24 25 0 25 26 0 26 27 0 27 28 0 28 29 0
		 29 30 0 30 31 0 31 32 0 32 33 0 33 34 0 34 35 0 35 36 0 36 37 0 37 38 0 38 39 0 39 40 0
		 40 41 0 41 42 0 42 43 0 43 44 0 44 45 0 45 46 0 46 47 0 47 48 0 48 49 0 49 50 0 50 1 0;
	setAttr -s 50 -ch 150 ".fc[0:49]" -type "polyFaces" 
		f 3 50 0 -2
		mu 0 3 0 1 2
		f 3 51 2 -1
		mu 0 3 1 3 2
		f 3 52 3 -3
		mu 0 3 3 4 2
		f 3 53 4 -4
		mu 0 3 4 5 2
		f 3 54 5 -5
		mu 0 3 5 6 2
		f 3 55 6 -6
		mu 0 3 6 7 2
		f 3 56 7 -7
		mu 0 3 7 8 2
		f 3 57 8 -8
		mu 0 3 8 9 2
		f 3 58 9 -9
		mu 0 3 9 10 2
		f 3 59 10 -10
		mu 0 3 10 11 2
		f 3 60 11 -11
		mu 0 3 11 12 2
		f 3 61 12 -12
		mu 0 3 12 13 2
		f 3 62 13 -13
		mu 0 3 13 14 2
		f 3 63 14 -14
		mu 0 3 14 15 2
		f 3 64 15 -15
		mu 0 3 15 16 2
		f 3 65 16 -16
		mu 0 3 16 17 2
		f 3 66 17 -17
		mu 0 3 17 18 2
		f 3 67 18 -18
		mu 0 3 18 19 2
		f 3 68 19 -19
		mu 0 3 19 20 2
		f 3 69 20 -20
		mu 0 3 20 21 2
		f 3 70 21 -21
		mu 0 3 21 22 2
		f 3 71 22 -22
		mu 0 3 22 23 2
		f 3 72 23 -23
		mu 0 3 23 24 2
		f 3 73 24 -24
		mu 0 3 24 25 2
		f 3 74 25 -25
		mu 0 3 25 26 2
		f 3 75 26 -26
		mu 0 3 26 27 2
		f 3 76 27 -27
		mu 0 3 27 28 2
		f 3 77 28 -28
		mu 0 3 28 29 2
		f 3 78 29 -29
		mu 0 3 29 30 2
		f 3 79 30 -30
		mu 0 3 30 31 2
		f 3 80 31 -31
		mu 0 3 31 32 2
		f 3 81 32 -32
		mu 0 3 32 33 2
		f 3 82 33 -33
		mu 0 3 33 34 2
		f 3 83 34 -34
		mu 0 3 34 35 2
		f 3 84 35 -35
		mu 0 3 35 36 2
		f 3 85 36 -36
		mu 0 3 36 37 2
		f 3 86 37 -37
		mu 0 3 37 38 2
		f 3 87 38 -38
		mu 0 3 38 39 2
		f 3 88 39 -39
		mu 0 3 39 40 2
		f 3 89 40 -40
		mu 0 3 40 41 2
		f 3 90 41 -41
		mu 0 3 41 42 2
		f 3 91 42 -42
		mu 0 3 42 43 2
		f 3 92 43 -43
		mu 0 3 43 44 2
		f 3 93 44 -44
		mu 0 3 44 45 2
		f 3 94 45 -45
		mu 0 3 45 46 2
		f 3 95 46 -46
		mu 0 3 46 47 2
		f 3 96 47 -47
		mu 0 3 47 48 2
		f 3 97 48 -48
		mu 0 3 48 49 2
		f 3 98 49 -49
		mu 0 3 49 50 2
		f 3 99 1 -50
		mu 0 3 50 0 2;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "light_2";
	rename -uid "36CD0A4A-4A86-30AB-9FCE-C88CD291FCEA";
	setAttr ".t" -type "double3" 8.0000002405597801 19.203130489509515 -11.667950341422319 ;
	setAttr ".r" -type "double3" 90.000000000000028 0 0 ;
	setAttr ".s" -type "double3" 0.80718468363826879 0.80718468363826879 0.80718468363826879 ;
createNode mesh -n "light_Shape2" -p "light_2";
	rename -uid "6299F3AD-48D3-293E-17E1-9B9E4B334177";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 51 ".uvst[0].uvsp[0:50]" -type "float2" 0.57750899 0.85354167
		 0.57567054 0.86317891 0.5 0.83749998 0.57263881 0.87250972 0.56846148 0.881387 0.56320447
		 0.88967073 0.55695069 0.89723027 0.54979879 0.90394634 0.54186147 0.90971315 0.53326404
		 0.91443962 0.52414197 0.9180513 0.5146392 0.92049122 0.50490552 0.92172086 0.49509451
		 0.92172086 0.48536086 0.92049122 0.47585806 0.9180513 0.46673602 0.91443968 0.45813853
		 0.90971315 0.45020124 0.9039464 0.44304931 0.89723027 0.43679553 0.88967073 0.43153852
		 0.88138705 0.42736119 0.87250978 0.4243294 0.86317897 0.42249101 0.85354173 0.42187497
		 0.84375 0.42249101 0.83395839 0.4243294 0.82432115 0.42736116 0.81499028 0.43153849
		 0.806113 0.43679547 0.79782927 0.44304925 0.79026973 0.45020118 0.7835536 0.45813847
		 0.77778685 0.46673593 0.77306038 0.475858 0.76944864 0.48536077 0.76700878 0.49509445
		 0.76577914 0.50490546 0.76577914 0.51463914 0.76700872 0.52414191 0.76944864 0.53326398
		 0.77306032 0.54186147 0.77778679 0.54979873 0.7835536 0.55695069 0.79026967 0.56320447
		 0.79782915 0.56846148 0.80611289 0.57263881 0.81499016 0.5756706 0.82432103 0.57750905
		 0.83395827 0.578125 0.84375;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 51 ".vt[0:50]"  0 0.87613964 0 0.82721132 0.87613964 -0.10450104
		 0.80759102 0.87613964 -0.20735411 0.77523434 0.87613964 -0.30693704 0.73065209 0.87613964 -0.4016794
		 0.67454672 0.87613964 -0.49008694 0.60780358 0.87613964 -0.5707655 0.53147507 0.87613964 -0.64244294
		 0.44676468 0.87613964 -0.70398843 0.35500869 0.87613964 -0.75443161 0.25765401 0.87613964 -0.79297745
		 0.15623587 0.87613964 -0.81901705 0.052353844 0.87613964 -0.83214056 -0.052353799 0.87613964 -0.83214021
		 -0.15623578 0.87613964 -0.81901699 -0.2576538 0.87613964 -0.79297709 -0.35500848 0.87613964 -0.75443161
		 -0.44676456 0.87613964 -0.70398819 -0.53147483 0.87613964 -0.64244282 -0.60780334 0.87613964 -0.5707655
		 -0.67454666 0.87613964 -0.49008667 -0.73065162 0.87613964 -0.40167904 -0.77523416 0.87613964 -0.30693668
		 -0.80759048 0.87613964 -0.20735386 -0.82721043 0.87613964 -0.10450087 -0.83378541 0.87613964 1.7028651e-07
		 -0.82721043 0.87613964 0.10450119 -0.80759048 0.87613964 0.20735413 -0.77523363 0.87613964 0.30693707
		 -0.73065138 0.87613964 0.40167937 -0.67454636 0.87613964 0.49008691 -0.60780323 0.87613964 0.5707655
		 -0.53147465 0.87613964 0.64244282 -0.44676438 0.87613964 0.70398855 -0.35500827 0.87613964 0.7544319
		 -0.25765356 0.87613964 0.79297733 -0.15623559 0.87613964 0.81901693 -0.052353635 0.87613964 0.83214021
		 0.052353978 0.87613964 0.83213985 0.15623589 0.87613964 0.8190167 0.25765401 0.87613964 0.79297674
		 0.35500863 0.87613964 0.75443125 0.44676441 0.87613964 0.70398808 0.53147483 0.87613964 0.64244258
		 0.60780323 0.87613964 0.57076514 0.67454636 0.87613964 0.49008667 0.73065132 0.87613964 0.40167916
		 0.77523386 0.87613964 0.3069368 0.80759025 0.87613964 0.20735401 0.82721031 0.87613964 0.10450108
		 0.83378506 0.87613964 8.95281e-08;
	setAttr -s 100 ".ed[0:99]"  2 0 1 1 0 1 3 0 1 4 0 1 5 0 1 6 0 1 7 0 1
		 8 0 1 9 0 1 10 0 1 11 0 1 12 0 1 13 0 1 14 0 1 15 0 1 16 0 1 17 0 1 18 0 1 19 0 1
		 20 0 1 21 0 1 22 0 1 23 0 1 24 0 1 25 0 1 26 0 1 27 0 1 28 0 1 29 0 1 30 0 1 31 0 1
		 32 0 1 33 0 1 34 0 1 35 0 1 36 0 1 37 0 1 38 0 1 39 0 1 40 0 1 41 0 1 42 0 1 43 0 1
		 44 0 1 45 0 1 46 0 1 47 0 1 48 0 1 49 0 1 50 0 1 1 2 0 2 3 0 3 4 0 4 5 0 5 6 0 6 7 0
		 7 8 0 8 9 0 9 10 0 10 11 0 11 12 0 12 13 0 13 14 0 14 15 0 15 16 0 16 17 0 17 18 0
		 18 19 0 19 20 0 20 21 0 21 22 0 22 23 0 23 24 0 24 25 0 25 26 0 26 27 0 27 28 0 28 29 0
		 29 30 0 30 31 0 31 32 0 32 33 0 33 34 0 34 35 0 35 36 0 36 37 0 37 38 0 38 39 0 39 40 0
		 40 41 0 41 42 0 42 43 0 43 44 0 44 45 0 45 46 0 46 47 0 47 48 0 48 49 0 49 50 0 50 1 0;
	setAttr -s 50 -ch 150 ".fc[0:49]" -type "polyFaces" 
		f 3 50 0 -2
		mu 0 3 0 1 2
		f 3 51 2 -1
		mu 0 3 1 3 2
		f 3 52 3 -3
		mu 0 3 3 4 2
		f 3 53 4 -4
		mu 0 3 4 5 2
		f 3 54 5 -5
		mu 0 3 5 6 2
		f 3 55 6 -6
		mu 0 3 6 7 2
		f 3 56 7 -7
		mu 0 3 7 8 2
		f 3 57 8 -8
		mu 0 3 8 9 2
		f 3 58 9 -9
		mu 0 3 9 10 2
		f 3 59 10 -10
		mu 0 3 10 11 2
		f 3 60 11 -11
		mu 0 3 11 12 2
		f 3 61 12 -12
		mu 0 3 12 13 2
		f 3 62 13 -13
		mu 0 3 13 14 2
		f 3 63 14 -14
		mu 0 3 14 15 2
		f 3 64 15 -15
		mu 0 3 15 16 2
		f 3 65 16 -16
		mu 0 3 16 17 2
		f 3 66 17 -17
		mu 0 3 17 18 2
		f 3 67 18 -18
		mu 0 3 18 19 2
		f 3 68 19 -19
		mu 0 3 19 20 2
		f 3 69 20 -20
		mu 0 3 20 21 2
		f 3 70 21 -21
		mu 0 3 21 22 2
		f 3 71 22 -22
		mu 0 3 22 23 2
		f 3 72 23 -23
		mu 0 3 23 24 2
		f 3 73 24 -24
		mu 0 3 24 25 2
		f 3 74 25 -25
		mu 0 3 25 26 2
		f 3 75 26 -26
		mu 0 3 26 27 2
		f 3 76 27 -27
		mu 0 3 27 28 2
		f 3 77 28 -28
		mu 0 3 28 29 2
		f 3 78 29 -29
		mu 0 3 29 30 2
		f 3 79 30 -30
		mu 0 3 30 31 2
		f 3 80 31 -31
		mu 0 3 31 32 2
		f 3 81 32 -32
		mu 0 3 32 33 2
		f 3 82 33 -33
		mu 0 3 33 34 2
		f 3 83 34 -34
		mu 0 3 34 35 2
		f 3 84 35 -35
		mu 0 3 35 36 2
		f 3 85 36 -36
		mu 0 3 36 37 2
		f 3 86 37 -37
		mu 0 3 37 38 2
		f 3 87 38 -38
		mu 0 3 38 39 2
		f 3 88 39 -39
		mu 0 3 39 40 2
		f 3 89 40 -40
		mu 0 3 40 41 2
		f 3 90 41 -41
		mu 0 3 41 42 2
		f 3 91 42 -42
		mu 0 3 42 43 2
		f 3 92 43 -43
		mu 0 3 43 44 2
		f 3 93 44 -44
		mu 0 3 44 45 2
		f 3 94 45 -45
		mu 0 3 45 46 2
		f 3 95 46 -46
		mu 0 3 46 47 2
		f 3 96 47 -47
		mu 0 3 47 48 2
		f 3 97 48 -48
		mu 0 3 48 49 2
		f 3 98 49 -49
		mu 0 3 49 50 2
		f 3 99 1 -50
		mu 0 3 50 0 2;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "light_fog_1";
	rename -uid "22174DD8-4B5E-FC54-74AE-0C8DCC3FFFE0";
	setAttr ".t" -type "double3" -6.9999995231628418 20.203130459598679 -10.793618906942605 ;
	setAttr ".r" -type "double3" 90.000000000000028 0 0 ;
	setAttr ".rp" -type "double3" 0 -0.99999973755278049 0 ;
	setAttr ".sp" -type "double3" 0 -0.99999973755278049 0 ;
createNode mesh -n "light_fog_1Shape" -p "light_fog_1";
	rename -uid "90D62081-4645-32F4-B0CA-EEB577EBF07C";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.49999998509883881 0.84374997019767761 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 21 ".pt";
	setAttr ".pt[20]" -type "float3" 1.2695116 3.917042 -0.41248882 ;
	setAttr ".pt[21]" -type "float3" 1.0799108 3.917042 -0.78460109 ;
	setAttr ".pt[22]" -type "float3" 0.78460121 3.917042 -1.0799108 ;
	setAttr ".pt[23]" -type "float3" 0.41248906 3.917042 -1.2695113 ;
	setAttr ".pt[24]" -type "float3" 1.0227157e-07 3.917042 -1.334842 ;
	setAttr ".pt[25]" -type "float3" -0.41248882 3.917042 -1.2695112 ;
	setAttr ".pt[26]" -type "float3" -0.78460097 3.917042 -1.0799108 ;
	setAttr ".pt[27]" -type "float3" -1.0799106 3.917042 -0.78460073 ;
	setAttr ".pt[28]" -type "float3" -1.2695113 3.917042 -0.41248882 ;
	setAttr ".pt[29]" -type "float3" -1.334842 3.917042 2.0388975e-07 ;
	setAttr ".pt[30]" -type "float3" -1.2695113 3.917042 0.412489 ;
	setAttr ".pt[31]" -type "float3" -1.0799106 3.917042 0.78460109 ;
	setAttr ".pt[32]" -type "float3" -0.78460073 3.917042 1.0799108 ;
	setAttr ".pt[33]" -type "float3" -0.41248882 3.917042 1.2695113 ;
	setAttr ".pt[34]" -type "float3" 6.249023e-08 3.917042 1.3348421 ;
	setAttr ".pt[35]" -type "float3" 0.41248888 3.917042 1.2695113 ;
	setAttr ".pt[36]" -type "float3" 0.78460097 3.917042 1.0799108 ;
	setAttr ".pt[37]" -type "float3" 1.0799106 3.917042 0.78460109 ;
	setAttr ".pt[38]" -type "float3" 1.2695113 3.917042 0.41248888 ;
	setAttr ".pt[39]" -type "float3" 1.334842 3.917042 2.0388975e-07 ;
	setAttr ".pt[41]" -type "float3" 0 3.2592118 0 ;
createNode transform -n "light_fog_2";
	rename -uid "F1A60B8E-4198-BF66-7D34-579B211BF7D1";
	setAttr ".t" -type "double3" 8 20.203130459598679 -10.793618906942605 ;
	setAttr ".r" -type "double3" 90.000000000000028 0 0 ;
	setAttr ".rp" -type "double3" 0 -0.99999973755278049 0 ;
	setAttr ".sp" -type "double3" 0 -0.99999973755278049 0 ;
createNode mesh -n "light_fog_Shape2" -p "light_fog_2";
	rename -uid "DD5DFE1A-4C1C-61B0-FF32-088BD9AC43AB";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.49999998509883881 0.84374997019767761 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 84 ".uvst[0].uvsp[0:83]" -type "float2" 0.64860266 0.10796607
		 0.62640899 0.064408496 0.59184152 0.029841021 0.54828393 0.0076473355 0.5 -7.4505806e-08
		 0.45171607 0.0076473504 0.40815851 0.029841051 0.37359107 0.064408526 0.3513974 0.1079661
		 0.34374997 0.15625 0.3513974 0.2045339 0.37359107 0.24809146 0.40815854 0.28265893
		 0.4517161 0.3048526 0.5 0.3125 0.54828387 0.3048526 0.59184146 0.28265893 0.62640893
		 0.24809146 0.6486026 0.2045339 0.65625 0.15625 0.375 0.3125 0.38749999 0.3125 0.39999998
		 0.3125 0.41249996 0.3125 0.42499995 0.3125 0.43749994 0.3125 0.44999993 0.3125 0.46249992
		 0.3125 0.4749999 0.3125 0.48749989 0.3125 0.49999988 0.3125 0.51249987 0.3125 0.52499986
		 0.3125 0.53749985 0.3125 0.54999983 0.3125 0.56249982 0.3125 0.57499981 0.3125 0.5874998
		 0.3125 0.59999979 0.3125 0.61249977 0.3125 0.62499976 0.3125 0.375 0.68843985 0.38749999
		 0.68843985 0.39999998 0.68843985 0.41249996 0.68843985 0.42499995 0.68843985 0.43749994
		 0.68843985 0.44999993 0.68843985 0.46249992 0.68843985 0.4749999 0.68843985 0.48749989
		 0.68843985 0.49999988 0.68843985 0.51249987 0.68843985 0.52499986 0.68843985 0.53749985
		 0.68843985 0.54999983 0.68843985 0.56249982 0.68843985 0.57499981 0.68843985 0.5874998
		 0.68843985 0.59999979 0.68843985 0.61249977 0.68843985 0.62499976 0.68843985 0.64860266
		 0.79546607 0.62640899 0.75190848 0.59184152 0.71734101 0.54828393 0.69514734 0.5
		 0.68749994 0.45171607 0.69514734 0.40815851 0.71734107 0.37359107 0.75190854 0.3513974
		 0.79546607 0.34374997 0.84375 0.3513974 0.89203393 0.37359107 0.93559146 0.40815854
		 0.97015893 0.4517161 0.9923526 0.5 1 0.54828387 0.9923526 0.59184146 0.97015893 0.62640893
		 0.93559146 0.6486026 0.89203393 0.65625 0.84375 0.5 0.15000001 0.5 0.83749998;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 21 ".pt";
	setAttr ".pt[20]" -type "float3" 1.2695116 3.917042 -0.41248882 ;
	setAttr ".pt[21]" -type "float3" 1.0799108 3.917042 -0.78460109 ;
	setAttr ".pt[22]" -type "float3" 0.78460121 3.917042 -1.0799108 ;
	setAttr ".pt[23]" -type "float3" 0.41248906 3.917042 -1.2695113 ;
	setAttr ".pt[24]" -type "float3" 1.0227157e-07 3.917042 -1.334842 ;
	setAttr ".pt[25]" -type "float3" -0.41248882 3.917042 -1.2695112 ;
	setAttr ".pt[26]" -type "float3" -0.78460097 3.917042 -1.0799108 ;
	setAttr ".pt[27]" -type "float3" -1.0799106 3.917042 -0.78460073 ;
	setAttr ".pt[28]" -type "float3" -1.2695113 3.917042 -0.41248882 ;
	setAttr ".pt[29]" -type "float3" -1.334842 3.917042 2.0388975e-07 ;
	setAttr ".pt[30]" -type "float3" -1.2695113 3.917042 0.412489 ;
	setAttr ".pt[31]" -type "float3" -1.0799106 3.917042 0.78460109 ;
	setAttr ".pt[32]" -type "float3" -0.78460073 3.917042 1.0799108 ;
	setAttr ".pt[33]" -type "float3" -0.41248882 3.917042 1.2695113 ;
	setAttr ".pt[34]" -type "float3" 6.249023e-08 3.917042 1.3348421 ;
	setAttr ".pt[35]" -type "float3" 0.41248888 3.917042 1.2695113 ;
	setAttr ".pt[36]" -type "float3" 0.78460097 3.917042 1.0799108 ;
	setAttr ".pt[37]" -type "float3" 1.0799106 3.917042 0.78460109 ;
	setAttr ".pt[38]" -type "float3" 1.2695113 3.917042 0.41248888 ;
	setAttr ".pt[39]" -type "float3" 1.334842 3.917042 2.0388975e-07 ;
	setAttr ".pt[41]" -type "float3" 0 3.2592118 0 ;
	setAttr -s 42 ".vt[0:41]"  0.95105714 -1 -0.30901718 0.80901754 -1 -0.5877856
		 0.5877856 -1 -0.80901748 0.30901715 -1 -0.95105702 0 -1 -1.000000476837 -0.30901715 -1 -0.95105696
		 -0.58778548 -1 -0.8090173 -0.80901724 -1 -0.58778542 -0.95105678 -1 -0.30901706 -1.000000238419 -1 0
		 -0.95105678 -1 0.30901706 -0.80901718 -1 0.58778536 -0.58778536 -1 0.80901712 -0.30901706 -1 0.95105666
		 -2.9802322e-08 -1 1.000000119209 0.30901697 -1 0.9510566 0.58778524 -1 0.80901706
		 0.809017 -1 0.5877853 0.95105654 -1 0.309017 1 -1 0 0.95105714 1 -0.30901718 0.80901754 1 -0.5877856
		 0.5877856 1 -0.80901748 0.30901715 1 -0.95105702 0 1 -1.000000476837 -0.30901715 1 -0.95105696
		 -0.58778548 1 -0.8090173 -0.80901724 1 -0.58778542 -0.95105678 1 -0.30901706 -1.000000238419 1 0
		 -0.95105678 1 0.30901706 -0.80901718 1 0.58778536 -0.58778536 1 0.80901712 -0.30901706 1 0.95105666
		 -2.9802322e-08 1 1.000000119209 0.30901697 1 0.9510566 0.58778524 1 0.80901706 0.809017 1 0.5877853
		 0.95105654 1 0.309017 1 1 0 0 -1 0 0 1 0;
	setAttr -s 100 ".ed[0:99]"  0 1 0 1 2 0 2 3 0 3 4 0 4 5 0 5 6 0 6 7 0
		 7 8 0 8 9 0 9 10 0 10 11 0 11 12 0 12 13 0 13 14 0 14 15 0 15 16 0 16 17 0 17 18 0
		 18 19 0 19 0 0 20 21 0 21 22 0 22 23 0 23 24 0 24 25 0 25 26 0 26 27 0 27 28 0 28 29 0
		 29 30 0 30 31 0 31 32 0 32 33 0 33 34 0 34 35 0 35 36 0 36 37 0 37 38 0 38 39 0 39 20 0
		 0 20 1 1 21 1 2 22 1 3 23 1 4 24 1 5 25 1 6 26 1 7 27 1 8 28 1 9 29 1 10 30 1 11 31 1
		 12 32 1 13 33 1 14 34 1 15 35 1 16 36 1 17 37 1 18 38 1 19 39 1 40 0 1 40 1 1 40 2 1
		 40 3 1 40 4 1 40 5 1 40 6 1 40 7 1 40 8 1 40 9 1 40 10 1 40 11 1 40 12 1 40 13 1
		 40 14 1 40 15 1 40 16 1 40 17 1 40 18 1 40 19 1 20 41 1 21 41 1 22 41 1 23 41 1 24 41 1
		 25 41 1 26 41 1 27 41 1 28 41 1 29 41 1 30 41 1 31 41 1 32 41 1 33 41 1 34 41 1 35 41 1
		 36 41 1 37 41 1 38 41 1 39 41 1;
	setAttr -s 60 -ch 200 ".fc[0:59]" -type "polyFaces" 
		f 4 0 41 -21 -41
		mu 0 4 20 21 42 41
		f 4 1 42 -22 -42
		mu 0 4 21 22 43 42
		f 4 2 43 -23 -43
		mu 0 4 22 23 44 43
		f 4 3 44 -24 -44
		mu 0 4 23 24 45 44
		f 4 4 45 -25 -45
		mu 0 4 24 25 46 45
		f 4 5 46 -26 -46
		mu 0 4 25 26 47 46
		f 4 6 47 -27 -47
		mu 0 4 26 27 48 47
		f 4 7 48 -28 -48
		mu 0 4 27 28 49 48
		f 4 8 49 -29 -49
		mu 0 4 28 29 50 49
		f 4 9 50 -30 -50
		mu 0 4 29 30 51 50
		f 4 10 51 -31 -51
		mu 0 4 30 31 52 51
		f 4 11 52 -32 -52
		mu 0 4 31 32 53 52
		f 4 12 53 -33 -53
		mu 0 4 32 33 54 53
		f 4 13 54 -34 -54
		mu 0 4 33 34 55 54
		f 4 14 55 -35 -55
		mu 0 4 34 35 56 55
		f 4 15 56 -36 -56
		mu 0 4 35 36 57 56
		f 4 16 57 -37 -57
		mu 0 4 36 37 58 57
		f 4 17 58 -38 -58
		mu 0 4 37 38 59 58
		f 4 18 59 -39 -59
		mu 0 4 38 39 60 59
		f 4 19 40 -40 -60
		mu 0 4 39 40 61 60
		f 3 -1 -61 61
		mu 0 3 1 0 82
		f 3 -2 -62 62
		mu 0 3 2 1 82
		f 3 -3 -63 63
		mu 0 3 3 2 82
		f 3 -4 -64 64
		mu 0 3 4 3 82
		f 3 -5 -65 65
		mu 0 3 5 4 82
		f 3 -6 -66 66
		mu 0 3 6 5 82
		f 3 -7 -67 67
		mu 0 3 7 6 82
		f 3 -8 -68 68
		mu 0 3 8 7 82
		f 3 -9 -69 69
		mu 0 3 9 8 82
		f 3 -10 -70 70
		mu 0 3 10 9 82
		f 3 -11 -71 71
		mu 0 3 11 10 82
		f 3 -12 -72 72
		mu 0 3 12 11 82
		f 3 -13 -73 73
		mu 0 3 13 12 82
		f 3 -14 -74 74
		mu 0 3 14 13 82
		f 3 -15 -75 75
		mu 0 3 15 14 82
		f 3 -16 -76 76
		mu 0 3 16 15 82
		f 3 -17 -77 77
		mu 0 3 17 16 82
		f 3 -18 -78 78
		mu 0 3 18 17 82
		f 3 -19 -79 79
		mu 0 3 19 18 82
		f 3 -20 -80 60
		mu 0 3 0 19 82
		f 3 20 81 -81
		mu 0 3 80 79 83
		f 3 21 82 -82
		mu 0 3 79 78 83
		f 3 22 83 -83
		mu 0 3 78 77 83
		f 3 23 84 -84
		mu 0 3 77 76 83
		f 3 24 85 -85
		mu 0 3 76 75 83
		f 3 25 86 -86
		mu 0 3 75 74 83
		f 3 26 87 -87
		mu 0 3 74 73 83
		f 3 27 88 -88
		mu 0 3 73 72 83
		f 3 28 89 -89
		mu 0 3 72 71 83
		f 3 29 90 -90
		mu 0 3 71 70 83
		f 3 30 91 -91
		mu 0 3 70 69 83
		f 3 31 92 -92
		mu 0 3 69 68 83
		f 3 32 93 -93
		mu 0 3 68 67 83
		f 3 33 94 -94
		mu 0 3 67 66 83
		f 3 34 95 -95
		mu 0 3 66 65 83
		f 3 35 96 -96
		mu 0 3 65 64 83
		f 3 36 97 -97
		mu 0 3 64 63 83
		f 3 37 98 -98
		mu 0 3 63 62 83
		f 3 38 99 -99
		mu 0 3 62 81 83
		f 3 39 80 -100
		mu 0 3 81 80 83;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "door";
	rename -uid "7F7983EA-4A6F-86D3-2809-78BC2622E5E5";
	setAttr ".t" -type "double3" -8.739521953782333 12.499999791222303 3.0040197372436523 ;
	setAttr ".r" -type "double3" 0 0 -90.000000000000028 ;
	setAttr ".s" -type "double3" 5.0080405668457955 5.0080405668457955 5.0080405668457955 ;
	setAttr ".rp" -type "double3" -2.4040188789367667 0.1383821667855144 -2.4040203094482426 ;
	setAttr ".rpt" -type "double3" 0.038380622863772196 -0.238383293151891 0 ;
	setAttr ".sp" -type "double3" -0.48003183018361306 0.027631997971747955 -0.48003211582656213 ;
	setAttr ".spt" -type "double3" -1.9239870487531356 0.1107501688137673 -1.9239881936216805 ;
createNode mesh -n "doorShape" -p "door";
	rename -uid "C83D692F-444E-241D-BB32-35B67FEC110B";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.49999913573265076 0.0038913488388061523 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 4 ".pt";
	setAttr ".pt[1]" -type "float3" 2.9802322e-08 -1.0587912e-22 0 ;
	setAttr ".pt[3]" -type "float3" 2.9802322e-08 -1.0587912e-22 0 ;
	setAttr ".pt[5]" -type "float3" 2.9802322e-08 0 0 ;
	setAttr ".pt[6]" -type "float3" 2.9802322e-08 0 0 ;
createNode transform -n "door_beams";
	rename -uid "DDDDDC4F-46B0-CE8F-7306-D89169905F94";
	setAttr ".rp" -type "double3" -11.175654348300586 6.0674752198273438 3.3911299335203786 ;
	setAttr ".sp" -type "double3" -11.175654348300586 6.0674752198273438 3.3911299335203786 ;
createNode mesh -n "door_beamsShape" -p "door_beams";
	rename -uid "D05E260E-45E4-9DCE-294C-B1849F1A0C31";
	setAttr -k off ".v";
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:119]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 10 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "bottom";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "f[80:99]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottomRing";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 1 "e[100:119]";
	setAttr ".gtag[2].gtagnm" -type "string" "cylBottomCap";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 2 "vtx[42:61]" "vtx[82]";
	setAttr ".gtag[3].gtagnm" -type "string" "cylBottomRing";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "vtx[42:61]";
	setAttr ".gtag[4].gtagnm" -type "string" "cylSides";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "vtx[42:81]";
	setAttr ".gtag[5].gtagnm" -type "string" "cylTopCap";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 2 "vtx[62:81]" "vtx[83]";
	setAttr ".gtag[6].gtagnm" -type "string" "cylTopRing";
	setAttr ".gtag[6].gtagcmp" -type "componentList" 1 "vtx[62:81]";
	setAttr ".gtag[7].gtagnm" -type "string" "sides";
	setAttr ".gtag[7].gtagcmp" -type "componentList" 1 "f[60:79]";
	setAttr ".gtag[8].gtagnm" -type "string" "top";
	setAttr ".gtag[8].gtagcmp" -type "componentList" 1 "f[100:119]";
	setAttr ".gtag[9].gtagnm" -type "string" "topRing";
	setAttr ".gtag[9].gtagcmp" -type "componentList" 1 "e[120:139]";
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 168 ".uvst[0].uvsp[0:167]" -type "float2" 0.64860266 0.10796607
		 0.62640899 0.064408496 0.59184152 0.029841021 0.54828393 0.0076473355 0.5 -7.4505806e-08
		 0.45171607 0.0076473504 0.40815851 0.029841051 0.37359107 0.064408526 0.3513974 0.1079661
		 0.34374997 0.15625 0.3513974 0.2045339 0.37359107 0.24809146 0.40815854 0.28265893
		 0.4517161 0.3048526 0.5 0.3125 0.54828387 0.3048526 0.59184146 0.28265893 0.62640893
		 0.24809146 0.6486026 0.2045339 0.65625 0.15625 0.375 0.3125 0.38749999 0.3125 0.39999998
		 0.3125 0.41249996 0.3125 0.42499995 0.3125 0.43749994 0.3125 0.44999993 0.3125 0.46249992
		 0.3125 0.4749999 0.3125 0.48749989 0.3125 0.49999988 0.3125 0.51249987 0.3125 0.52499986
		 0.3125 0.53749985 0.3125 0.54999983 0.3125 0.56249982 0.3125 0.57499981 0.3125 0.5874998
		 0.3125 0.59999979 0.3125 0.61249977 0.3125 0.62499976 0.3125 0.375 0.68843985 0.38749999
		 0.68843985 0.39999998 0.68843985 0.41249996 0.68843985 0.42499995 0.68843985 0.43749994
		 0.68843985 0.44999993 0.68843985 0.46249992 0.68843985 0.4749999 0.68843985 0.48749989
		 0.68843985 0.49999988 0.68843985 0.51249987 0.68843985 0.52499986 0.68843985 0.53749985
		 0.68843985 0.54999983 0.68843985 0.56249982 0.68843985 0.57499981 0.68843985 0.5874998
		 0.68843985 0.59999979 0.68843985 0.61249977 0.68843985 0.62499976 0.68843985 0.64860266
		 0.79546607 0.62640899 0.75190848 0.59184152 0.71734101 0.54828393 0.69514734 0.5
		 0.68749994 0.45171607 0.69514734 0.40815851 0.71734107 0.37359107 0.75190854 0.3513974
		 0.79546607 0.34374997 0.84375 0.3513974 0.89203393 0.37359107 0.93559146 0.40815854
		 0.97015893 0.4517161 0.9923526 0.5 1 0.54828387 0.9923526 0.59184146 0.97015893 0.62640893
		 0.93559146 0.6486026 0.89203393 0.65625 0.84375 0.5 0.15000001 0.5 0.83749998 0.375
		 0.3125 0.38749999 0.3125 0.38749999 0.68843985 0.375 0.68843985 0.39999998 0.3125
		 0.39999998 0.68843985 0.41249996 0.3125 0.41249996 0.68843985 0.42499995 0.3125 0.42499995
		 0.68843985 0.43749994 0.3125 0.43749994 0.68843985 0.44999993 0.3125 0.44999993 0.68843985
		 0.46249992 0.3125 0.46249992 0.68843985 0.4749999 0.3125 0.4749999 0.68843985 0.48749989
		 0.3125 0.48749989 0.68843985 0.49999988 0.3125 0.49999988 0.68843985 0.51249987 0.3125
		 0.51249987 0.68843985 0.52499986 0.3125 0.52499986 0.68843985 0.53749985 0.3125 0.53749985
		 0.68843985 0.54999983 0.3125 0.54999983 0.68843985 0.56249982 0.3125 0.56249982 0.68843985
		 0.57499981 0.3125 0.57499981 0.68843985 0.5874998 0.3125 0.5874998 0.68843985 0.59999979
		 0.3125 0.59999979 0.68843985 0.61249977 0.3125 0.61249977 0.68843985 0.62499976 0.3125
		 0.62499976 0.68843985 0.62640899 0.064408496 0.64860266 0.10796607 0.5 0.15000001
		 0.59184152 0.029841021 0.54828393 0.0076473355 0.5 -7.4505806e-08 0.45171607 0.0076473504
		 0.40815851 0.029841051 0.37359107 0.064408526 0.3513974 0.1079661 0.34374997 0.15625
		 0.3513974 0.2045339 0.37359107 0.24809146 0.40815854 0.28265893 0.4517161 0.3048526
		 0.5 0.3125 0.54828387 0.3048526 0.59184146 0.28265893 0.62640893 0.24809146 0.6486026
		 0.2045339 0.65625 0.15625 0.6486026 0.89203393 0.62640893 0.93559146 0.5 0.83749998
		 0.59184146 0.97015893 0.54828387 0.9923526 0.5 1 0.4517161 0.9923526 0.40815854 0.97015893
		 0.37359107 0.93559146 0.3513974 0.89203393 0.34374997 0.84375 0.3513974 0.79546607
		 0.37359107 0.75190854 0.40815851 0.71734107 0.45171607 0.69514734 0.5 0.68749994
		 0.54828393 0.69514734 0.59184152 0.71734101 0.62640899 0.75190848 0.64860266 0.79546607
		 0.65625 0.84375;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 84 ".vt[0:83]"  -10.91674137 6.16346645 1.1997323 -10.91674137 6.14913034 1.17159593
		 -10.91674137 6.12680101 1.14926672 -10.91674137 6.098664761 1.13493061 -10.91674137 6.067475319 1.1299907
		 -10.91674137 6.036285877 1.13493061 -10.91674137 6.0081496239 1.14926672 -10.91674137 5.98582029 1.17159593
		 -10.91674137 5.97148418 1.1997323 -10.91674137 5.96654415 1.23092175 -10.91674137 5.97148418 1.26211119
		 -10.91674137 5.98582029 1.29024756 -10.91674137 6.0081496239 1.31257665 -10.91674137 6.036285877 1.32691288
		 -10.91674137 6.067475319 1.33185279 -10.91674137 6.098664761 1.32691288 -10.91674137 6.12680101 1.31257665
		 -10.91674137 6.14913034 1.29024756 -10.91674137 6.16346645 1.26211119 -10.91674137 6.16840649 1.23092175
		 -11.4345665 6.16346645 1.1997323 -11.4345665 6.14913034 1.17159593 -11.4345665 6.12680101 1.14926672
		 -11.4345665 6.098664761 1.13493061 -11.4345665 6.067475319 1.1299907 -11.4345665 6.036285877 1.13493061
		 -11.4345665 6.0081496239 1.14926672 -11.4345665 5.98582029 1.17159593 -11.4345665 5.97148418 1.1997323
		 -11.4345665 5.96654415 1.23092175 -11.4345665 5.97148418 1.26211119 -11.4345665 5.98582029 1.29024756
		 -11.4345665 6.0081496239 1.31257665 -11.4345665 6.036285877 1.32691288 -11.4345665 6.067475319 1.33185279
		 -11.4345665 6.098664761 1.32691288 -11.4345665 6.12680101 1.31257665 -11.4345665 6.14913034 1.29024756
		 -11.4345665 6.16346645 1.26211119 -11.4345665 6.16840649 1.23092175 -10.91674137 6.067475319 1.23092175
		 -11.4345665 6.067475319 1.23092175 -10.91674137 6.16346645 5.52014875 -10.91674137 6.14913034 5.4920125
		 -10.91674137 6.12680101 5.46968317 -10.91674137 6.098664761 5.45534706 -10.91674137 6.067475319 5.45040703
		 -10.91674137 6.036285877 5.45534706 -10.91674137 6.0081496239 5.46968317 -10.91674137 5.98582029 5.4920125
		 -10.91674137 5.97148418 5.52014875 -10.91674137 5.96654415 5.5513382 -10.91674137 5.97148418 5.58252764
		 -10.91674137 5.98582029 5.61066389 -10.91674137 6.0081496239 5.63299322 -10.91674137 6.036285877 5.64732933
		 -10.91674137 6.067475319 5.65226936 -10.91674137 6.098664761 5.64732933 -10.91674137 6.12680101 5.63299322
		 -10.91674137 6.14913034 5.61066389 -10.91674137 6.16346645 5.58252764 -10.91674137 6.16840649 5.5513382
		 -11.4345665 6.16346645 5.52014875 -11.4345665 6.14913034 5.4920125 -11.4345665 6.12680101 5.46968317
		 -11.4345665 6.098664761 5.45534706 -11.4345665 6.067475319 5.45040703 -11.4345665 6.036285877 5.45534706
		 -11.4345665 6.0081496239 5.46968317 -11.4345665 5.98582029 5.4920125 -11.4345665 5.97148418 5.52014875
		 -11.4345665 5.96654415 5.5513382 -11.4345665 5.97148418 5.58252764 -11.4345665 5.98582029 5.61066389
		 -11.4345665 6.0081496239 5.63299322 -11.4345665 6.036285877 5.64732933 -11.4345665 6.067475319 5.65226936
		 -11.4345665 6.098664761 5.64732933 -11.4345665 6.12680101 5.63299322 -11.4345665 6.14913034 5.61066389
		 -11.4345665 6.16346645 5.58252764 -11.4345665 6.16840649 5.5513382 -10.91674137 6.067475319 5.5513382
		 -11.4345665 6.067475319 5.5513382;
	setAttr -s 200 ".ed";
	setAttr ".ed[0:165]"  0 1 0 1 2 0 2 3 0 3 4 0 4 5 0 5 6 0 6 7 0 7 8 0 8 9 0
		 9 10 0 10 11 0 11 12 0 12 13 0 13 14 0 14 15 0 15 16 0 16 17 0 17 18 0 18 19 0 19 0 0
		 20 21 0 21 22 0 22 23 0 23 24 0 24 25 0 25 26 0 26 27 0 27 28 0 28 29 0 29 30 0 30 31 0
		 31 32 0 32 33 0 33 34 0 34 35 0 35 36 0 36 37 0 37 38 0 38 39 0 39 20 0 0 20 1 1 21 1
		 2 22 1 3 23 1 4 24 1 5 25 1 6 26 1 7 27 1 8 28 1 9 29 1 10 30 1 11 31 1 12 32 1 13 33 1
		 14 34 1 15 35 1 16 36 1 17 37 1 18 38 1 19 39 1 40 0 1 40 1 1 40 2 1 40 3 1 40 4 1
		 40 5 1 40 6 1 40 7 1 40 8 1 40 9 1 40 10 1 40 11 1 40 12 1 40 13 1 40 14 1 40 15 1
		 40 16 1 40 17 1 40 18 1 40 19 1 20 41 1 21 41 1 22 41 1 23 41 1 24 41 1 25 41 1 26 41 1
		 27 41 1 28 41 1 29 41 1 30 41 1 31 41 1 32 41 1 33 41 1 34 41 1 35 41 1 36 41 1 37 41 1
		 38 41 1 39 41 1 42 43 0 43 44 0 44 45 0 45 46 0 46 47 0 47 48 0 48 49 0 49 50 0 50 51 0
		 51 52 0 52 53 0 53 54 0 54 55 0 55 56 0 56 57 0 57 58 0 58 59 0 59 60 0 60 61 0 61 42 0
		 62 63 0 63 64 0 64 65 0 65 66 0 66 67 0 67 68 0 68 69 0 69 70 0 70 71 0 71 72 0 72 73 0
		 73 74 0 74 75 0 75 76 0 76 77 0 77 78 0 78 79 0 79 80 0 80 81 0 81 62 0 42 62 1 43 63 1
		 44 64 1 45 65 1 46 66 1 47 67 1 48 68 1 49 69 1 50 70 1 51 71 1 52 72 1 53 73 1 54 74 1
		 55 75 1 56 76 1 57 77 1 58 78 1 59 79 1 60 80 1 61 81 1 82 42 1 82 43 1 82 44 1 82 45 1
		 82 46 1 82 47 1;
	setAttr ".ed[166:199]" 82 48 1 82 49 1 82 50 1 82 51 1 82 52 1 82 53 1 82 54 1
		 82 55 1 82 56 1 82 57 1 82 58 1 82 59 1 82 60 1 82 61 1 62 83 1 63 83 1 64 83 1 65 83 1
		 66 83 1 67 83 1 68 83 1 69 83 1 70 83 1 71 83 1 72 83 1 73 83 1 74 83 1 75 83 1 76 83 1
		 77 83 1 78 83 1 79 83 1 80 83 1 81 83 1;
	setAttr -s 120 -ch 400 ".fc[0:119]" -type "polyFaces" 
		f 4 0 41 -21 -41
		mu 0 4 20 21 42 41
		f 4 1 42 -22 -42
		mu 0 4 21 22 43 42
		f 4 2 43 -23 -43
		mu 0 4 22 23 44 43
		f 4 3 44 -24 -44
		mu 0 4 23 24 45 44
		f 4 4 45 -25 -45
		mu 0 4 24 25 46 45
		f 4 5 46 -26 -46
		mu 0 4 25 26 47 46
		f 4 6 47 -27 -47
		mu 0 4 26 27 48 47
		f 4 7 48 -28 -48
		mu 0 4 27 28 49 48
		f 4 8 49 -29 -49
		mu 0 4 28 29 50 49
		f 4 9 50 -30 -50
		mu 0 4 29 30 51 50
		f 4 10 51 -31 -51
		mu 0 4 30 31 52 51
		f 4 11 52 -32 -52
		mu 0 4 31 32 53 52
		f 4 12 53 -33 -53
		mu 0 4 32 33 54 53
		f 4 13 54 -34 -54
		mu 0 4 33 34 55 54
		f 4 14 55 -35 -55
		mu 0 4 34 35 56 55
		f 4 15 56 -36 -56
		mu 0 4 35 36 57 56
		f 4 16 57 -37 -57
		mu 0 4 36 37 58 57
		f 4 17 58 -38 -58
		mu 0 4 37 38 59 58
		f 4 18 59 -39 -59
		mu 0 4 38 39 60 59
		f 4 19 40 -40 -60
		mu 0 4 39 40 61 60
		f 3 -1 -61 61
		mu 0 3 1 0 82
		f 3 -2 -62 62
		mu 0 3 2 1 82
		f 3 -3 -63 63
		mu 0 3 3 2 82
		f 3 -4 -64 64
		mu 0 3 4 3 82
		f 3 -5 -65 65
		mu 0 3 5 4 82
		f 3 -6 -66 66
		mu 0 3 6 5 82
		f 3 -7 -67 67
		mu 0 3 7 6 82
		f 3 -8 -68 68
		mu 0 3 8 7 82
		f 3 -9 -69 69
		mu 0 3 9 8 82
		f 3 -10 -70 70
		mu 0 3 10 9 82
		f 3 -11 -71 71
		mu 0 3 11 10 82
		f 3 -12 -72 72
		mu 0 3 12 11 82
		f 3 -13 -73 73
		mu 0 3 13 12 82
		f 3 -14 -74 74
		mu 0 3 14 13 82
		f 3 -15 -75 75
		mu 0 3 15 14 82
		f 3 -16 -76 76
		mu 0 3 16 15 82
		f 3 -17 -77 77
		mu 0 3 17 16 82
		f 3 -18 -78 78
		mu 0 3 18 17 82
		f 3 -19 -79 79
		mu 0 3 19 18 82
		f 3 -20 -80 60
		mu 0 3 0 19 82
		f 3 20 81 -81
		mu 0 3 80 79 83
		f 3 21 82 -82
		mu 0 3 79 78 83
		f 3 22 83 -83
		mu 0 3 78 77 83
		f 3 23 84 -84
		mu 0 3 77 76 83
		f 3 24 85 -85
		mu 0 3 76 75 83
		f 3 25 86 -86
		mu 0 3 75 74 83
		f 3 26 87 -87
		mu 0 3 74 73 83
		f 3 27 88 -88
		mu 0 3 73 72 83
		f 3 28 89 -89
		mu 0 3 72 71 83
		f 3 29 90 -90
		mu 0 3 71 70 83
		f 3 30 91 -91
		mu 0 3 70 69 83
		f 3 31 92 -92
		mu 0 3 69 68 83
		f 3 32 93 -93
		mu 0 3 68 67 83
		f 3 33 94 -94
		mu 0 3 67 66 83
		f 3 34 95 -95
		mu 0 3 66 65 83
		f 3 35 96 -96
		mu 0 3 65 64 83
		f 3 36 97 -97
		mu 0 3 64 63 83
		f 3 37 98 -98
		mu 0 3 63 62 83
		f 3 38 99 -99
		mu 0 3 62 81 83
		f 3 39 80 -100
		mu 0 3 81 80 83
		f 4 100 141 -121 -141
		mu 0 4 84 85 86 87
		f 4 101 142 -122 -142
		mu 0 4 85 88 89 86
		f 4 102 143 -123 -143
		mu 0 4 88 90 91 89
		f 4 103 144 -124 -144
		mu 0 4 90 92 93 91
		f 4 104 145 -125 -145
		mu 0 4 92 94 95 93
		f 4 105 146 -126 -146
		mu 0 4 94 96 97 95
		f 4 106 147 -127 -147
		mu 0 4 96 98 99 97
		f 4 107 148 -128 -148
		mu 0 4 98 100 101 99
		f 4 108 149 -129 -149
		mu 0 4 100 102 103 101
		f 4 109 150 -130 -150
		mu 0 4 102 104 105 103
		f 4 110 151 -131 -151
		mu 0 4 104 106 107 105
		f 4 111 152 -132 -152
		mu 0 4 106 108 109 107
		f 4 112 153 -133 -153
		mu 0 4 108 110 111 109
		f 4 113 154 -134 -154
		mu 0 4 110 112 113 111
		f 4 114 155 -135 -155
		mu 0 4 112 114 115 113
		f 4 115 156 -136 -156
		mu 0 4 114 116 117 115
		f 4 116 157 -137 -157
		mu 0 4 116 118 119 117
		f 4 117 158 -138 -158
		mu 0 4 118 120 121 119
		f 4 118 159 -139 -159
		mu 0 4 120 122 123 121
		f 4 119 140 -140 -160
		mu 0 4 122 124 125 123
		f 3 -101 -161 161
		mu 0 3 126 127 128
		f 3 -102 -162 162
		mu 0 3 129 126 128
		f 3 -103 -163 163
		mu 0 3 130 129 128
		f 3 -104 -164 164
		mu 0 3 131 130 128
		f 3 -105 -165 165
		mu 0 3 132 131 128
		f 3 -106 -166 166
		mu 0 3 133 132 128
		f 3 -107 -167 167
		mu 0 3 134 133 128
		f 3 -108 -168 168
		mu 0 3 135 134 128
		f 3 -109 -169 169
		mu 0 3 136 135 128
		f 3 -110 -170 170
		mu 0 3 137 136 128
		f 3 -111 -171 171
		mu 0 3 138 137 128
		f 3 -112 -172 172
		mu 0 3 139 138 128
		f 3 -113 -173 173
		mu 0 3 140 139 128
		f 3 -114 -174 174
		mu 0 3 141 140 128
		f 3 -115 -175 175
		mu 0 3 142 141 128
		f 3 -116 -176 176
		mu 0 3 143 142 128
		f 3 -117 -177 177
		mu 0 3 144 143 128
		f 3 -118 -178 178
		mu 0 3 145 144 128
		f 3 -119 -179 179
		mu 0 3 146 145 128
		f 3 -120 -180 160
		mu 0 3 127 146 128
		f 3 120 181 -181
		mu 0 3 147 148 149
		f 3 121 182 -182
		mu 0 3 148 150 149
		f 3 122 183 -183
		mu 0 3 150 151 149
		f 3 123 184 -184
		mu 0 3 151 152 149
		f 3 124 185 -185
		mu 0 3 152 153 149
		f 3 125 186 -186
		mu 0 3 153 154 149
		f 3 126 187 -187
		mu 0 3 154 155 149
		f 3 127 188 -188
		mu 0 3 155 156 149
		f 3 128 189 -189
		mu 0 3 156 157 149
		f 3 129 190 -190
		mu 0 3 157 158 149
		f 3 130 191 -191
		mu 0 3 158 159 149
		f 3 131 192 -192
		mu 0 3 159 160 149
		f 3 132 193 -193
		mu 0 3 160 161 149
		f 3 133 194 -194
		mu 0 3 161 162 149
		f 3 134 195 -195
		mu 0 3 162 163 149
		f 3 135 196 -196
		mu 0 3 163 164 149
		f 3 136 197 -197
		mu 0 3 164 165 149
		f 3 137 198 -198
		mu 0 3 165 166 149
		f 3 138 199 -199
		mu 0 3 166 167 149
		f 3 139 180 -200
		mu 0 3 167 147 149;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "door_handle";
	rename -uid "77565B68-492B-7734-EB13-B4A6048A8A12";
	setAttr ".rp" -type "double3" -11.174351692199711 6.0682508719300596 3.3749993666335723 ;
	setAttr ".sp" -type "double3" -11.174351692199711 6.0682508719300596 3.3749993666335723 ;
createNode mesh -n "door_handleShape" -p "door_handle";
	rename -uid "4E8906B4-44F6-FC05-272E-41A8D16CB306";
	setAttr -k off ".v";
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:19]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 6 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "back";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "f[4]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottom";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 2 "f[1]" "f[8:9]";
	setAttr ".gtag[2].gtagnm" -type "string" "front";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 1 "f[5]";
	setAttr ".gtag[3].gtagnm" -type "string" "left";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "f[3]";
	setAttr ".gtag[4].gtagnm" -type "string" "right";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "f[2]";
	setAttr ".gtag[5].gtagnm" -type "string" "top";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 2 "f[0]" "f[6:7]";
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 68 ".uvst[0].uvsp[0:67]" -type "float2" 0.99999195 0.22154111
		 1.2785196e-05 0.22159901 1.1086464e-05 0.19186908 0.99999011 0.1918112 6.8545341e-07
		 0.012402326 0.99997979 0.01234439 0.99998152 0.042074382 2.3841858e-06 0.042132258
		 3.1888485e-06 0.054476827 0.99998236 0.054418892 0.99998951 0.17946666 1.0341406e-05
		 0.17952469 0.9999792 0 2.0742416e-05 0.35899132 1.347065e-05 0.2339434 0.99999267
		 0.23388565 0.38069457 0.4629339 0.41379344 0.42984325 0.25635129 0.42984927 0.28944662
		 0.46294349 0.28946075 0.93705177 0.52651197 0.42985868 0.55960196 0.4629584 0.14363262
		 0.42985272 0.11053923 0.4629488 0.11055335 0.93705714 0.41371965 0.97014129 0.38062978
		 0.9370423 0.25636727 0.97014737 0.52643818 0.97015679 0.55953699 0.93706673 0.14364874
		 0.97015071 1 0.3589333 0 5.787611e-05 0.99999195 0.22154111 1.2785196e-05 0.22159901
		 1.1086464e-05 0.19186908 0.99999011 0.1918112 6.8545341e-07 0.012402326 0.99997979
		 0.01234439 0.99998152 0.042074382 2.3841858e-06 0.042132258 3.1888485e-06 0.054476827
		 0.99998236 0.054418892 0.99998951 0.17946666 1.0341406e-05 0.17952469 1 0.3589333
		 2.0742416e-05 0.35899132 1.347065e-05 0.2339434 0.99999267 0.23388565 0.55953699
		 0.93706673 0.52643818 0.97015679 0.41371965 0.97014129 0.38062978 0.9370423 0.38069457
		 0.4629339 0.41379344 0.42984325 0.52651197 0.42985868 0.55960196 0.4629584 0.11053923
		 0.4629488 0.14363262 0.42985272 0.25635129 0.42984927 0.28944662 0.46294349 0.28946075
		 0.93705177 0.25636727 0.97014737 0.14364874 0.97015071 0.11055335 0.93705714 0 5.787611e-05
		 0.9999792 0;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 32 ".vt[0:31]"  -11.043339729 6.41526604 6.026666164 -10.99489403 6.46371222 6.026666164
		 -11.043339729 6.41526604 0.72333241 -10.99489403 6.46371222 0.72333241 -10.8298893 6.46371222 6.026666164
		 -10.7814436 6.41526604 6.026666164 -10.7814436 6.41526604 0.72333241 -10.8298893 6.46371222 0.72333241
		 -10.99489403 5.6727891 6.026666164 -11.043339729 5.72123623 6.026666164 -11.043339729 5.72123623 0.72333241
		 -10.99489403 5.6727891 0.72333241 -10.7814436 5.72123623 6.026666164 -10.8298893 5.6727891 6.026666164
		 -10.8298893 5.6727891 0.72333241 -10.7814436 5.72123623 0.72333241 -11.30536366 6.41526604 0.72333258
		 -11.35380936 6.46371222 0.72333258 -11.30536366 6.41526604 6.026666164 -11.35380936 6.46371222 6.026666164
		 -11.51881409 6.46371222 0.72333258 -11.56725979 6.41526604 0.72333258 -11.56725979 6.41526604 6.026666164
		 -11.51881409 6.46371222 6.026666164 -11.35380936 5.6727891 0.72333258 -11.30536366 5.72123623 0.72333258
		 -11.30536366 5.72123623 6.026666164 -11.35380936 5.6727891 6.026666164 -11.56725979 5.72123623 0.72333258
		 -11.51881409 5.6727891 0.72333258 -11.51881409 5.6727891 6.026666164 -11.56725979 5.72123623 6.026666164;
	setAttr -s 48 ".ed[0:47]"  1 4 0 1 0 0 2 10 0 3 7 0 3 2 0 5 4 0 6 15 0
		 7 6 0 8 13 0 9 0 0 8 9 0 11 14 0 11 10 0 12 5 0 13 12 0 15 14 0 0 2 0 3 1 0 4 7 0
		 6 5 0 8 11 0 10 9 0 12 15 0 14 13 0 17 20 0 17 16 0 18 26 0 19 23 0 19 18 0 21 20 0
		 22 31 0 23 22 0 24 29 0 25 16 0 24 25 0 27 30 0 27 26 0 28 21 0 29 28 0 31 30 0 16 18 0
		 19 17 0 20 23 0 22 21 0 24 27 0 26 25 0 28 31 0 30 29 0;
	setAttr -s 20 -ch 96 ".fc[0:19]" -type "polyFaces" 
		f 4 17 0 18 -4
		mu 0 4 0 1 2 3
		f 4 20 11 23 -9
		mu 0 4 4 5 6 7
		f 4 22 -7 19 -14
		mu 0 4 8 9 10 11
		f 4 21 9 16 2
		mu 0 4 32 13 14 15
		f 8 -5 3 7 6 15 -12 12 -3
		mu 0 8 30 29 26 27 16 17 21 22
		f 8 -11 8 14 13 5 -1 1 -10
		mu 0 8 24 23 18 19 20 28 31 25
		f 4 -2 -18 4 -17
		mu 0 4 14 1 0 15
		f 4 -6 -20 -8 -19
		mu 0 4 2 11 10 3
		f 4 10 -22 -13 -21
		mu 0 4 4 33 12 5
		f 4 -15 -24 -16 -23
		mu 0 4 8 7 6 9
		f 4 41 24 42 -28
		mu 0 4 34 35 36 37
		f 4 44 35 47 -33
		mu 0 4 38 39 40 41
		f 4 46 -31 43 -38
		mu 0 4 42 43 44 45
		f 4 45 33 40 26
		mu 0 4 46 47 48 49
		f 8 -29 27 31 30 39 -36 36 -27
		mu 0 8 50 51 52 53 54 55 56 57
		f 8 -35 32 38 37 29 -25 25 -34
		mu 0 8 58 59 60 61 62 63 64 65
		f 4 -26 -42 28 -41
		mu 0 4 48 35 34 49
		f 4 -30 -44 -32 -43
		mu 0 4 36 45 44 37
		f 4 34 -46 -37 -45
		mu 0 4 38 66 67 39
		f 4 -39 -48 -40 -47
		mu 0 4 42 41 40 43;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "blocker";
	rename -uid "3F266207-4F9E-D12C-E5AD-E499D1459103";
	setAttr ".t" -type "double3" -2.3996791839599609 9.6003213352800909 12.00000000000002 ;
	setAttr ".r" -type "double3" 90.000000000000028 0 0 ;
	setAttr ".s" -type "double3" 17.200641317725452 17.200641317725452 17.200641317725452 ;
	setAttr ".rp" -type "double3" -8.6003208160400391 8.8817841970010827e-16 8.600321216070812 ;
	setAttr ".rpt" -type "double3" 0 -8.6003212160708014 -8.6003212160708316 ;
	setAttr ".sp" -type "double3" -0.50000000913787557 -9.8607613152626476e-31 0.5000000323946111 ;
	setAttr ".spt" -type "double3" -8.1003208069021628 8.8817841970010926e-16 8.1003211836762006 ;
	setAttr ".rman_visibilityCamera" 0;
createNode mesh -n "blockerShape" -p "blocker";
	rename -uid "CE342792-4975-CEAB-66B1-05B93A50A890";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.5 0.5 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "volume_fog";
	rename -uid "8DA71933-41A7-A610-2334-99B4C6BDE7D5";
	setAttr ".s" -type "double3" 18.144979759345269 18.144979759345269 18.144979759345269 ;
	setAttr ".rp" -type "double3" -10.867052078247058 12.500000375736411 -10.867052078247058 ;
	setAttr ".sp" -type "double3" -0.59921987192766057 0.68093165755271912 -0.59921987192766057 ;
	setAttr ".spt" -type "double3" -10.2678322063192 11.819068718183438 -10.267832206319317 ;
createNode mesh -n "volume_fogShape" -p "volume_fog";
	rename -uid "A704205A-47DF-BF68-3392-AF9A3D068B9E";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 6 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "back";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "f[2]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottom";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 1 "f[3]";
	setAttr ".gtag[2].gtagnm" -type "string" "front";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 1 "f[0]";
	setAttr ".gtag[3].gtagnm" -type "string" "left";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "f[5]";
	setAttr ".gtag[4].gtagnm" -type "string" "right";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "f[4]";
	setAttr ".gtag[5].gtagnm" -type "string" "top";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 1 "f[1]";
	setAttr ".pv" -type "double2" 0.5 0.375 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 14 ".uvst[0].uvsp[0:13]" -type "float2" 0.375 0 0.625 0 0.375
		 0.25 0.625 0.25 0.375 0.5 0.625 0.5 0.375 0.75 0.625 0.75 0.375 1 0.625 1 0.875 0
		 0.875 0.25 0.125 0 0.125 0.25;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 8 ".pt[0:7]" -type "float3"  -0.099219844 0.55447453 0.15369438 
		0.15369438 0.55447453 0.15369438 -0.099219844 0.80738878 0.15369438 0.15369438 0.80738878 
		0.15369438 -0.099219844 0.80738878 -0.099219844 0.15369438 0.80738878 -0.099219844 
		-0.099219844 0.55447453 -0.099219844 0.15369438 0.55447453 -0.099219844;
	setAttr -s 8 ".vt[0:7]"  -0.5 -0.5 0.5 0.5 -0.5 0.5 -0.5 0.5 0.5 0.5 0.5 0.5
		 -0.5 0.5 -0.5 0.5 0.5 -0.5 -0.5 -0.5 -0.5 0.5 -0.5 -0.5;
	setAttr -s 12 ".ed[0:11]"  0 1 0 2 3 0 4 5 0 6 7 0 0 2 0 1 3 0 2 4 0
		 3 5 0 4 6 0 5 7 0 6 0 0 7 1 0;
	setAttr -s 6 -ch 24 ".fc[0:5]" -type "polyFaces" 
		f 4 0 5 -2 -5
		mu 0 4 0 1 3 2
		f 4 1 7 -3 -7
		mu 0 4 2 3 5 4
		f 4 2 9 -4 -9
		mu 0 4 4 5 7 6
		f 4 3 11 -1 -11
		mu 0 4 6 7 9 8
		f 4 -12 -10 -8 -6
		mu 0 4 1 10 11 3
		f 4 10 4 6 8
		mu 0 4 12 0 2 13;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "seat_vent";
	rename -uid "07FF53B1-4F8B-3E74-D1DF-88BEB36C1B08";
	setAttr ".rp" -type "double3" -1.5704135571992239 3.7033399967416791 2.3204137387055392 ;
	setAttr ".sp" -type "double3" -1.5704135571992239 3.7033399967416791 2.3204137387055392 ;
createNode mesh -n "seat_ventShape" -p "seat_vent";
	rename -uid "97981776-49BE-960F-B21D-688DE1061A6D";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.43928542733192444 0.062844312749803066 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode mesh -n "polySurfaceShape10" -p "seat_vent";
	rename -uid "A6BC6AC1-4E0D-25F9-E68E-B48A364A64AC";
	setAttr -k off ".v";
	setAttr ".io" yes;
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:5]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.5 0.60000000149011612 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 18 ".uvst[0].uvsp[0:17]" -type "float2" 0.5 0.4375 0.5625
		 0.4375 0.5625 0.4375 0.5 0.4375 0.375 0.4375 0.375 0.4375 0.5625 0.375 0.5625 0.25
		 0.5625 0.25 0.5625 0.375 0 0.2 1 0.2 1 1 0 1 0 0.2 1 0.2 1 1 0 1;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 16 ".vt[0:15]"  3.71834469 4.033395767 -7.35916996 -10.99999905 4.033395767 -7.35916996
		 7.85917234 4.033395767 11.99999714 7.85917234 4.033395767 -3.71834302 7.85917234 4.033395767 -7.35916996
		 7.85917234 6.40668011 11.99999714 7.85917234 6.40668011 -3.71834302 7.85917234 6.40668011 -7.35916996
		 3.71834469 6.40668011 -7.35916996 -10.99999905 6.40668011 -7.35916996 -10.99999905 1 -3.71834302
		 3.71834469 1 -3.71834302 3.71834469 1 11.99999714 -10.99999905 3.42671609 -3.71834278
		 3.71834469 3.42671609 -3.71834278 3.71834469 3.42671609 11.99999714;
	setAttr -s 20 ".ed[0:19]"  0 1 0 2 3 0 4 0 0 3 4 0 4 7 0 0 8 0 1 9 0
		 2 5 0 3 6 0 5 6 0 6 7 0 7 8 0 8 9 0 10 11 0 12 11 0 13 10 0 14 11 0 15 12 0 13 14 0
		 14 15 0;
	setAttr -s 6 -ch 24 ".fc[0:5]" -type "polyFaces" 
		f 4 -3 4 11 -6
		mu 0 4 0 1 2 3
		f 4 -1 5 12 -7
		mu 0 4 4 0 3 5
		f 4 -2 7 9 -9
		mu 0 4 6 7 8 9
		f 4 -4 8 10 -5
		mu 0 4 1 6 9 2
		f 4 -19 15 13 -17
		mu 0 4 10 11 12 13
		f 4 -20 16 -15 -18
		mu 0 4 14 15 16 17;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "seat_wood";
	rename -uid "5A5A40D1-4109-5496-1463-80BF855ACFD7";
	setAttr ".t" -type "double3" 7.7183448352336885 3.0850344991536689 -6.7183448352336885 ;
	setAttr ".s" -type "double3" 8.5633105719475875 4.1700690031886314 8.5633105719475875 ;
createNode mesh -n "seat_woodShape" -p "seat_wood";
	rename -uid "4E791648-4C73-E474-0C2B-25BA8642F5C3";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.39909983390853521 0.23343481809803945 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".rman_preventPolyCracks" yes;
createNode mesh -n "polySurfaceShape11" -p "seat_wood";
	rename -uid "47CA0D68-4993-317D-9A27-96B43D302EEF";
	setAttr -k off ".v";
	setAttr ".io" yes;
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:40]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 67 ".uvst[0].uvsp[0:66]" -type "float2" 0.5 0.25 0.5625 0.25
		 0.5625 0.375 0.5 0.375 0.375 0.375 0.5 0.4375 0.375 0.4375 0.5625 0.4375 0.5 0.4375
		 0.5625 0.4375 0.5625 0.5 0.5 0.5 0.375 0.4375 0.375 0.5 0.5625 0.375 0.5625 0.25
		 0.625 0.25 0.625 0.375 0.625 0.4375 0.625 0.5 0.375 0.4375 0.375 0.5 0.625 0.25 0.5625
		 0.25 0.625 0.375 0.625 0.4375 0.625 0.5 0.5625 0.25 0.375 0.4375 1 0.2 0 0.2 1.7578206e-08
		 0.2 1 0.2 1 0.2 0 0.2 0 0.2 1 0.2 0.5625 0.375 0.5625 0.25 0.5625 0.375 0.5625 0.4375
		 0.5625 0.4375 0.5 0.4375 0.5 0.4375 0.375 0.4375 1 0 1 0 0 0 0 0 1 0.065926053 1.7699843e-08
		 0.065926045 0.5625 0.25 0.5625 0.25 0.5625 0.375 0.5625 0.375 0 0.06592603 1 0.065926053
		 0.5625 0.4375 0.5 0.4375 0.375 0.4375 0 0 0 0 0.375 0.4375 1 0 1 0 0.5625 0.4375
		 0.5 0.4375;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 57 ".vt[0:56]"  -0.46711028 0.22742093 2.18587685 -2.18587708 0.22742093 0.35033321
		 -0.46711028 0.22742093 0.35033321 0.016444266 0.93882531 -0.074832678 -0.46710908 0.93882531 -0.074832678
		 0.016445458 0.93882531 -0.5 -0.46710908 0.93882531 -0.5 -2.18587708 0.93882531 -0.074832678
		 -2.18587708 0.93882531 -0.5 0.016444266 0.93882531 2.18587685 0.016444266 0.93882531 0.35033199
		 0.49999994 0.93882531 2.18587685 0.49999994 0.93882531 0.35033199 0.49999994 0.93882531 -0.07483381
		 0.49999994 0.93882531 -0.5 -2.18587708 0.081936657 0.35033202 -0.46710908 0.081936657 0.35033202
		 -0.46710908 0.081936657 2.18587685 0.49999994 0.79654449 -0.5 0.49999994 0.79654449 -0.07483381
		 0.49999994 0.79654449 0.35033199 0.49999994 0.79654449 2.18587685 -2.18587708 0.79654449 -0.5
		 -2.18587708 0.081936657 0.37368751 -0.49046457 0.081936657 0.37368751 -0.49046457 0.081936657 2.18587685
		 -0.0069099665 0.79654449 2.18587685 -0.0069099665 0.79654449 0.35033199 -0.0069099665 0.79654449 -0.051478386
		 -0.46710908 0.79654449 -0.051478386 -2.18587708 0.79654449 -0.051478386 -2.18587708 0.17946488 0.37368748
		 -2.18587708 0.21337497 0.36684752 -0.48362461 0.21337497 0.36684752 -0.49046457 0.17946488 0.37368748
		 -0.49046457 0.17946488 2.18587685 -0.48362461 0.21337497 2.18587685 -7.0095062e-05 0.92477924 2.18587685
		 -0.0069099665 0.89086932 2.18587685 -0.0069099665 0.89086932 0.35033199 -7.0095062e-05 0.92477924 0.35033199
		 -0.0069099665 0.89086932 -0.051478386 -7.0095062e-05 0.92477924 -0.058318377 -0.46710908 0.89086932 -0.051478386
		 -0.46710908 0.92477924 -0.058318377 -2.18587708 0.89086932 -0.051478386 -2.18587708 0.92477924 -0.058318377
		 0.016445458 0.22742093 2.18587685 0.016445458 0.79654449 2.18587685 0.016445458 0.79654449 0.35033199
		 0.016445458 0.79654449 -0.07483381 -0.46710908 0.79654449 -0.07483381 -2.18587708 0.79654449 -0.07483381
		 -2.18587708 0.22742093 -0.07483381 0.016445458 0.22742093 0.35033199 0.016445458 0.22742093 -0.07483381
		 -0.46710908 0.22742093 -0.07483381;
	setAttr -s 96 ".ed[0:95]"  0 47 0 1 2 1 2 54 1 0 2 1 1 53 0 2 56 1 3 4 1
		 3 5 1 6 5 0 4 6 1 4 7 1 8 6 0 7 8 0 9 10 1 9 11 0 11 12 0 10 12 1 10 3 1 12 13 0
		 13 3 1 13 14 0 5 14 0 1 15 0 0 17 0 15 16 0 16 17 0 18 14 0 19 13 0 20 12 0 21 11 0
		 48 9 1 52 7 1 22 8 0 18 19 0 19 20 0 20 21 0 21 48 0 52 22 0 15 23 0 16 24 1 23 24 0
		 17 25 0 24 25 0 48 26 0 49 27 1 26 27 0 26 38 0 50 28 1 27 28 0 51 29 1 28 29 0 52 30 0
		 29 30 0 30 45 0 31 23 0 35 25 0 1 32 0 32 33 0 33 2 0 32 31 0 31 34 1 34 33 0 36 0 0
		 34 35 1 35 36 0 38 37 0 37 40 0 40 39 1 39 38 1 37 9 0 10 40 1 42 41 0 41 39 1 3 42 0
		 44 43 1 43 41 1 4 44 1 46 45 0 45 43 1 7 46 0 24 34 0 39 27 1 41 28 0 43 29 1 33 36 0
		 40 42 0 42 44 0 44 46 0 48 49 0 49 50 0 50 51 0 51 52 0 47 54 0 54 55 0 55 56 0 56 53 0;
	setAttr -s 41 -ch 168 ".fc[0:40]" -type "polyFaces" 
		f 4 0 92 -3 -4
		mu 0 4 0 1 2 3
		f 4 1 5 95 -5
		mu 0 4 4 3 5 6
		f 4 2 93 94 -6
		mu 0 4 3 2 7 5
		f 4 -7 7 -9 -10
		mu 0 4 8 9 10 11
		f 4 -11 9 -12 -13
		mu 0 4 12 8 11 13
		f 4 -14 14 15 -17
		mu 0 4 14 15 16 17
		f 4 -18 16 18 19
		mu 0 4 9 14 17 18
		f 4 -8 -20 20 -22
		mu 0 4 10 9 18 19
		f 4 -34 26 -21 -28
		mu 0 4 25 26 19 18
		f 4 -35 27 -19 -29
		mu 0 4 24 25 18 17
		f 4 -36 28 -16 -30
		mu 0 4 22 24 17 16
		f 4 -37 29 -15 -31
		mu 0 4 27 22 16 15
		f 4 -38 31 12 -33
		mu 0 4 21 28 12 13
		f 4 24 39 -41 -39
		mu 0 4 29 30 31 32
		f 4 25 41 -43 -40
		mu 0 4 33 34 35 36
		f 4 -89 43 45 -45
		mu 0 4 37 23 38 39
		f 4 -90 44 48 -48
		mu 0 4 40 37 39 41
		f 4 -91 47 50 -50
		mu 0 4 42 40 41 43
		f 4 -92 49 52 -52
		mu 0 4 20 42 43 44
		f 4 56 57 58 -2
		mu 0 4 45 46 47 48
		f 4 59 60 61 -58
		mu 0 4 46 49 50 47
		f 4 65 66 67 68
		mu 0 4 51 52 53 54
		f 4 69 13 70 -67
		mu 0 4 52 15 14 53
		f 4 -61 54 40 80
		mu 0 4 50 49 32 31
		f 4 -64 -81 42 -56
		mu 0 4 55 56 36 35
		f 4 -46 46 -69 81
		mu 0 4 39 38 51 54
		f 4 -49 -82 -73 82
		mu 0 4 41 39 54 57
		f 4 -51 -83 -76 83
		mu 0 4 43 41 57 58
		f 4 -53 -84 -79 -54
		mu 0 4 44 43 58 59
		f 5 22 38 -55 -60 -57
		mu 0 5 45 29 32 49 46
		f 5 55 -42 -24 -63 -65
		mu 0 5 55 35 34 60 61
		f 5 -66 -47 -44 30 -70
		mu 0 5 52 51 38 27 15
		f 5 -32 51 53 -78 -80
		mu 0 5 12 28 44 59 62
		f 4 -59 84 62 3
		mu 0 4 63 64 61 60
		f 4 -62 63 64 -85
		mu 0 4 64 56 55 61
		f 4 -68 85 71 72
		mu 0 4 54 53 65 57
		f 4 -71 17 73 -86
		mu 0 4 53 14 9 65
		f 4 -72 86 74 75
		mu 0 4 57 65 66 58
		f 4 -74 6 76 -87
		mu 0 4 65 9 8 66
		f 4 -75 87 77 78
		mu 0 4 58 66 62 59
		f 4 -77 10 79 -88
		mu 0 4 66 8 12 62;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode transform -n "seat_side";
	rename -uid "9DDBDCC8-4014-F4F2-06D5-66AB9399CFE8";
	setAttr ".t" -type "double3" 7.7183448352336885 3.0850344991536689 -6.7183448352336885 ;
	setAttr ".s" -type "double3" 8.5633105719475875 4.1700690031886314 8.5633105719475875 ;
createNode mesh -n "seat_sideShape" -p "seat_side";
	rename -uid "A561FACA-4386-B392-F789-C9BEC2C32FC3";
	setAttr -k off ".v";
	setAttr ".iog[0].og[0].gcl" -type "componentList" 1 "f[0:8]";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.6875 0.25 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 22 ".uvst[0].uvsp[0:21]" -type "float2" 0.5 0 0.5625 0 0.5625
		 0.25 0.5 0.25 0.75 0 0.8125 0 0.8125 0.25 0.75 0.25 0.625 0 0.625 0.25 0.875 0 0.875
		 0.25 0.5625 0.25 0.5625 0.25 0.625 0.25 0.5625 0.25 0.625 0.375 0.625 0.375 0.625
		 0.4375 0.625 0.4375 0.625 0.5 0.625 0.5;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 17 ".vt[0:16]"  -0.46710908 -0.5 2.18587685 0.49999994 -0.5 2.18587685
		 0.49999994 0.22742093 2.18587685 0.49999994 0.22742093 0.35033199 0.49999994 0.22742093 -0.5
		 0.49999994 -0.5 -0.5 0.49999994 -0.5 0.35033199 0.49999994 -0.5 -0.07483381 0.49999994 0.22742093 -0.07483381
		 0.016445458 -0.5 2.18587685 -0.46711028 0.22742093 2.18587685 0.016445458 0.22742093 2.18587685
		 0.49999994 0.79654449 2.18587685 0.016445458 0.79654449 2.18587685 0.49999994 0.79654449 0.35033199
		 0.49999994 0.79654449 -0.07483381 0.49999994 0.79654449 -0.5;
	setAttr -s 25 ".ed[0:24]"  0 9 0 0 10 0 1 2 0 2 3 0 3 8 0 4 5 0 5 7 0
		 6 1 0 6 3 1 7 6 0 8 4 0 7 8 1 9 1 0 11 2 0 9 11 1 2 12 0 3 14 0 8 15 0 4 16 0 11 13 0
		 10 11 0 12 13 0 14 12 0 15 14 0 16 15 0;
	setAttr -s 9 -ch 36 ".fc[0:8]" -type "polyFaces" 
		f 4 0 14 -21 -2
		mu 0 4 0 1 2 3
		f 4 -10 11 -5 -9
		mu 0 4 4 5 6 7
		f 4 -8 8 -4 -3
		mu 0 4 8 4 7 9
		f 4 -7 -6 -11 -12
		mu 0 4 5 10 11 6
		f 4 12 2 -14 -15
		mu 0 4 1 8 9 12
		f 4 13 15 21 -20
		mu 0 4 13 9 14 15
		f 4 3 16 22 -16
		mu 0 4 9 16 17 14
		f 4 4 17 23 -17
		mu 0 4 16 18 19 17
		f 4 10 18 24 -18
		mu 0 4 18 20 21 19;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
createNode lightLinker -s -n "lightLinker1";
	rename -uid "1EFF0CDE-4644-8241-5116-DB9A1DC25C01";
	setAttr -s 13 ".lnk";
	setAttr -s 13 ".slnk";
createNode shapeEditorManager -n "shapeEditorManager";
	rename -uid "3D9DDD08-45FD-D08E-E34D-7B8C798B0DD4";
createNode poseInterpolatorManager -n "poseInterpolatorManager";
	rename -uid "444F6941-47E7-1650-997A-1786BE1CF6B3";
createNode displayLayerManager -n "layerManager";
	rename -uid "B86E624C-4261-5259-19B1-769DB3326CC8";
createNode displayLayer -n "defaultLayer";
	rename -uid "87A1AEFD-4604-FA18-755F-169EE3F19724";
	setAttr ".ufem" -type "stringArray" 0  ;
createNode renderLayerManager -n "renderLayerManager";
	rename -uid "E027FF14-4529-96FF-34F5-778AA0F94AC4";
createNode renderLayer -n "defaultRenderLayer";
	rename -uid "04805DFC-4900-E0AE-868B-6FA9387B18CC";
	setAttr ".g" yes;
createNode rmanGlobals -s -n "rmanGlobals";
	rename -uid "B36B9870-4B95-3E4C-F638-34BBC5DF2D5D";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".hider_minSamples" 0;
	setAttr ".hider_maxSamples" 256;
	setAttr ".ri_pixelVariance" 0.019999999552965164;
	setAttr ".hider_incremental" no;
	setAttr ".ipr_hider_maxSamples" 1024;
	setAttr ".ipr_ri_pixelVariance" 0.019999999552965164;
	setAttr ".ipr_ri_decidither" 0;
	setAttr ".ri_maxSpecularDepth" 4;
	setAttr ".ri_maxDiffuseDepth" 3;
	setAttr ".ri_displayFilter" -type "string" "gaussian";
	setAttr ".ri_displayFilterSize" -type "float2" 2 2 ;
	setAttr ".pixelFilterMode" -type "string" "importance";
	setAttr ".renderVariant" -type "string" "ris";
	setAttr ".xpuMode" -type "long2" 1 1 ;
	setAttr ".motionBlur" 0;
	setAttr ".cameraBlur" no;
	setAttr ".shutterAngle" 180;
	setAttr ".shutterOpenEnd" 0;
	setAttr ".shutterCloseStart" 1;
	setAttr ".shutterTiming" 0;
	setAttr ".motionSamples" 2;
	setAttr ".ocioConfig" 1;
	setAttr ".ocioConfigPath" -type "string" "${RMANTREE}/lib/ocio/ACES-1.2/config.ocio";
	setAttr ".ocioColorSpaceName" -type "string" "ACES - ACEScg";
	setAttr ".ocioEnabled" 1;
	setAttr ".enableStylizedLooks" no;
	setAttr ".displayFilters[0]" -type "string" "";
	setAttr ".sampleFilters[0]" -type "string" "";
	setAttr ".outputAllShaders" no;
	setAttr ".reentrantProcedurals" yes;
	setAttr ".outputShadowAOV" 0;
	setAttr ".enableImagePlaneFilter" yes;
	setAttr ".learnLightSelection" yes;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".blueNoise" yes;
	setAttr ".geomShadowTermBias" yes;
	setAttr ".roughnessMollification" 1;
	setAttr ".opt_bucket_order" -type "string" "circle";
	setAttr ".limits_bucketsize" -type "long2" 16 16 ;
	setAttr ".limits_othreshold" -type "float3" 0.99599999 0.99599999 0.99599999 ;
	setAttr ".rfm_referenceFrame" 0;
	setAttr ".adaptiveMetric" -type "string" "variance";
	setAttr ".hider_darkfalloff" 0.02500000037252903;
	setAttr ".hider_exposurebracket" -type "float2" -1 1 ;
	setAttr ".ri_hider_adaptAll" no;
	setAttr ".dice_micropolygonlength" 1;
	setAttr ".dice_watertight" no;
	setAttr ".dice_referenceCameraType" 0;
	setAttr ".dice_referenceCamera" -type "string" "";
	setAttr ".hair_minWidth" 0.5;
	setAttr ".trace_autobias" yes;
	setAttr ".trace_bias" 0.0010000000474974513;
	setAttr ".trace_worldorigin" -type "string" "camera";
	setAttr ".trace_worldoffset" -type "float3" 0 0 0 ;
	setAttr ".opt_oslmatchcpp" no;
	setAttr ".opt_oslSIMDEnable" yes;
	setAttr ".opt_oslVerbosity" 0;
	setAttr ".opt_oslStatistics" 0;
	setAttr ".volume_aggregatespace" -type "string" "world";
	setAttr ".deep_quality" 0.75;
	setAttr ".opt_cropWindowEnable" no;
	setAttr ".opt_cropWindowTopLeft" -type "float2" 0 0 ;
	setAttr ".opt_cropWindowBottomRight" -type "float2" 1 1 ;
	setAttr ".user_sceneUnits" 1;
	setAttr ".user_iesIgnoreWatts" yes;
	setAttr ".limits_texturememory" 4096;
	setAttr ".limits_geocachememory" 4096;
	setAttr ".limits_opacitycachememory" 2048;
	setAttr ".statistics_level" 1;
	setAttr ".statistics_xmlfilename" -type "string" "";
	setAttr ".lpe_reload_definitions" -type "string" "";
	setAttr ".lpe_diffuse2" -type "string" "Diffuse,HairDiffuse,diffuse,translucent,hair4,irradiance";
	setAttr ".lpe_diffuse3" -type "string" "Subsurface,subsurface";
	setAttr ".lpe_specular2" -type "string" "Specular,HairSpecularR,specular,hair1";
	setAttr ".lpe_specular3" -type "string" "RoughSpecular,HairSpecularTRT,hair3";
	setAttr ".lpe_specular4" -type "string" "Clearcoat";
	setAttr ".lpe_specular5" -type "string" "Iridescence";
	setAttr ".lpe_specular6" -type "string" "Fuzz,HairSpecularGLINTS";
	setAttr ".lpe_specular7" -type "string" "SingleScatter,HairSpecularTT,hair2";
	setAttr ".lpe_specular8" -type "string" "Glass,specular";
	setAttr ".lpe_user2" -type "string" "Albedo,DiffuseAlbedo,SubsurfaceAlbedo,HairAlbedo";
	setAttr ".lpe_user3" -type "string" "Position";
	setAttr ".lpe_user4" -type "string" "UserColor";
	setAttr ".lpe_user5" -type "string" "";
	setAttr ".lpe_user6" -type "string" "Normal,DiffuseNormal,HairTangent,SubsurfaceNormal,SpecularNormal,RoughSpecularNormal,SingleScatterNormal,FuzzNormal,IridescenceNormal,GlassNormal";
	setAttr ".lpe_user7" -type "string" "";
	setAttr ".lpe_user8" -type "string" "";
	setAttr ".lpe_user9" -type "string" "";
	setAttr ".lpe_user10" -type "string" "";
	setAttr ".lpe_user11" -type "string" "";
	setAttr ".lpe_user12" -type "string" "";
	setAttr ".imageFileFormat" -type "string" "<scene>_<layer>_<camera>_<aov>.<f4>.<ext>";
	setAttr ".ribFileFormat" -type "string" "<camera><layer>.<f4>.rib";
	setAttr ".version" 1;
	setAttr ".take" 1;
	setAttr ".imageOutputDir" -type "string" "<ws>/images/<scene>_v<version>_t<take>";
	setAttr ".ribOutputDir" -type "string" "<ws>/renderman/rib/<scene>/v<version>_t<take>";
	setAttr -s 10 ".UserTokens";
	setAttr ".UserTokens[0].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[0].userTokenValues" -type "string" "";
	setAttr ".UserTokens[1].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[1].userTokenValues" -type "string" "";
	setAttr ".UserTokens[2].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[2].userTokenValues" -type "string" "";
	setAttr ".UserTokens[3].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[3].userTokenValues" -type "string" "";
	setAttr ".UserTokens[4].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[4].userTokenValues" -type "string" "";
	setAttr ".UserTokens[5].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[5].userTokenValues" -type "string" "";
	setAttr ".UserTokens[6].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[6].userTokenValues" -type "string" "";
	setAttr ".UserTokens[7].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[7].userTokenValues" -type "string" "";
	setAttr ".UserTokens[8].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[8].userTokenValues" -type "string" "";
	setAttr ".UserTokens[9].userTokenKeys" -type "string" "";
	setAttr ".UserTokens[9].userTokenValues" -type "string" "";
	setAttr ".rlfData" -type "string" "init";
	setAttr ".jobid" -type "string" "";
	setAttr ".txmanagerData" -type "string" (
		"{\"door_roughness.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": null, \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"pixar\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"lossless\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"data\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"9c8699c402d58ef783353b797fa0db1031a58141\"}, \"uid\": \"873adbc5a5b8629e779932881b288118a673a43e\"}, \"drain_mask.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": null, \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"pixar\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"lossless\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"data\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"9c8699c402d58ef783353b797fa0db1031a58141\"}, \"uid\": \"5b645b650c6e17f857679213b057e9f0db160182\"}, \"floor_diffuse.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"4eb237b807e010ec6144d07a7cc0addd8bda58d8\"}, \"floor_displace.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"5e59a6794aa9cc85d6421ac73a6cd3eea0398f84\"}, \"floor_specular.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"752d2e8a039fa0bf6ce9416d8409be21e2ebdb20\"}, \"handle_diffuse.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"06a8e5b3dc29be3f32926842b046862aa047b479\"}, \"handle_displace.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"1888f6dacb2420f120826836ca39686ec885ae2d\"}, \"seat_diffuse.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": \"half\", \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"openexr\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"pxr24\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"srgb_texture\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"4a18989446d512b14cf728d355429f4ec7769d64\"}, \"uid\": \"1893c55a90fe0d79f71ccdcdc4830f713e76da93\"}, \"seat_vent_mask.filename\": {\"params\": {\"texture_type\": \"regular\", \"data_type\": null, \"s_mode\": \"periodic\", \"t_mode\": \"periodic\", \"texture_format\": \"pixar\", \"texture_filter\": \"catmull-rom\", \"resize\": \"round-\", \"compression\": \"lossless\", \"compression_level\": null, \"ocioconfig\": \"C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio\", \"ociocolorspace\": \"rendering\", \"ocioconvert\": \"data\", \"ociodither\": false, \"bumprough\": [], \"mipfilter\": \"box\", \"uid\": \"9c8699c402d58ef783353b797fa0db1031a58141\"}, \"uid\": \"2d173461178b9b6bf1961435929c15c3aff3f953\"}}");
	setAttr ".rmanVersion" -type "string" "25.2";
createNode PxrPathTracer -s -n "PxrPathTracer";
	rename -uid "A01A5D35-46AD-032B-273F-119771387ACC";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".maxIndirectBounces" 8;
	setAttr ".maxContinuationLength" -1;
	setAttr ".maxNonStochasticOpacityEvents" 0;
	setAttr ".sampleMode" -type "string" "bxdf";
	setAttr ".numLightSamples" 1;
	setAttr ".numBxdfSamples" 1;
	setAttr ".numVolumeAggregateSamples" 1;
	setAttr ".numIndirectSamples" 1;
	setAttr ".numDiffuseSamples" 1;
	setAttr ".numSpecularSamples" 1;
	setAttr ".numSubsurfaceSamples" 1;
	setAttr ".numRefractionSamples" 1;
	setAttr ".allowCaustics" no;
	setAttr ".accumOpacity" no;
	setAttr ".risPathGuiding" no;
	setAttr ".rouletteDepth" 4;
	setAttr ".rouletteThreshold" 0.20000000298023224;
	setAttr ".clampDepth" 2;
	setAttr ".clampLuminance" 10;
	setAttr ".volumeAggregate" -type "string" "";
	setAttr ".volumeAggregateCamera" -type "string" "";
	setAttr ".volumeAggregateIndirect" -type "string" "";
	setAttr ".volumeAggregateTransmission" -type "string" "";
	setAttr ".jointSampling" no;
	setAttr ".jointScatteringBias" 0.5;
createNode rmanBakingGlobals -s -n "rmanBakingGlobals";
	rename -uid "C324816C-4CA1-9968-D513-6CA5BD25DF50";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".bakeMode" 0;
	setAttr ".bakingImageFileFormat" -type "string" "<scene>_<user:bakingIdentifier>_<aov>.<ext>";
	setAttr ".resolution" 512;
	setAttr ".rman_bakeudimstride" 1;
	setAttr ".rman_bakeudimoffset" 0;
	setAttr ".rman_diceDistanceLength" 0.05000000074505806;
	setAttr ".rman_bakebboxmin" -type "float3" 1e+30 1e+30 1e+30 ;
	setAttr ".rman_bakebboxmax" -type "float3" -1e+30 -1e+30 -1e+30 ;
	setAttr ".ri_maxSpecularDepth" 4;
	setAttr ".ri_maxDiffuseDepth" 1;
	setAttr ".init" 0;
createNode rmanDisplay -n "rmanDefaultBakeDisplay";
	rename -uid "5DC895F4-44D4-7FCC-0CAF-5AA3B67AF623";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".denoise" no;
	setAttr ".frameMode" 0;
	setAttr ".opticalFlow" no;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr -s 2 ".displayChannels";
	setAttr ".name" -type "string" "";
createNode rmanDisplayChannel -n "diffuse";
	rename -uid "8249E140-4A39-52A9-CA2D-CE8178B52446";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".channelType" -type "string" "color";
	setAttr ".channelSource" -type "string" "lpe:C(D[DS]*[LO])|[LO]";
	setAttr ".lpeLightGroup" -type "string" "";
	setAttr ".filter" -type "string" "inherit from display";
	setAttr ".filterwidth" -type "float2" -1 -1 ;
	setAttr ".statistics" -type "string" "";
	setAttr ".relativepixelvariance" -1;
	setAttr ".shadowthreshold" 0.0099999997764825821;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr ".name" -type "string" "diffuse";
createNode rmanDisplayChannel -n "a";
	rename -uid "67D92B8C-4C2D-BBB2-8903-FF8F924FC8B9";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".channelType" -type "string" "float";
	setAttr ".channelSource" -type "string" "a";
	setAttr ".lpeLightGroup" -type "string" "";
	setAttr ".filter" -type "string" "inherit from display";
	setAttr ".filterwidth" -type "float2" -1 -1 ;
	setAttr ".statistics" -type "string" "";
	setAttr ".relativepixelvariance" -1;
	setAttr ".shadowthreshold" 0.0099999997764825821;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr ".name" -type "string" "a";
createNode PxrPathTracer -s -n "bake_PxrPathTracer";
	rename -uid "0FC45F71-40C1-6940-27A6-648586ECBA15";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".maxIndirectBounces" 8;
	setAttr ".maxContinuationLength" -1;
	setAttr ".maxNonStochasticOpacityEvents" 0;
	setAttr ".sampleMode" -type "string" "bxdf";
	setAttr ".numLightSamples" 1;
	setAttr ".numBxdfSamples" 1;
	setAttr ".numVolumeAggregateSamples" 1;
	setAttr ".numIndirectSamples" 1;
	setAttr ".numDiffuseSamples" 1;
	setAttr ".numSpecularSamples" 1;
	setAttr ".numSubsurfaceSamples" 1;
	setAttr ".numRefractionSamples" 1;
	setAttr ".allowCaustics" no;
	setAttr ".accumOpacity" no;
	setAttr ".risPathGuiding" no;
	setAttr ".rouletteDepth" 4;
	setAttr ".rouletteThreshold" 0.20000000298023224;
	setAttr ".clampDepth" 2;
	setAttr ".clampLuminance" 10;
	setAttr ".volumeAggregate" -type "string" "";
	setAttr ".volumeAggregateCamera" -type "string" "";
	setAttr ".volumeAggregateIndirect" -type "string" "";
	setAttr ".volumeAggregateTransmission" -type "string" "";
	setAttr ".jointSampling" no;
	setAttr ".jointScatteringBias" 0.5;
createNode rmanVolumeAggregateSet -n "globalVolumeAggregate";
	rename -uid "9BAC8B5C-4A96-0874-0849-7A86821E3FF4";
lockNode -l 1 ;
createNode d_openexr -n "d_openexr";
	rename -uid "DE6F93AB-43E5-5443-3CD3-2B886E151AEE";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".asrgba" yes;
	setAttr ".autocrop" -type "string" "false";
	setAttr ".storage" -type "string" "scanline";
	setAttr ".exrpixeltype" -type "string" "half";
	setAttr ".compression" -type "string" "zips";
	setAttr ".compressionlevel" 45;
	setAttr ".forcepar" 0;
	setAttr ".metadatacount" 0;
createNode script -n "uiConfigurationScriptNode";
	rename -uid "97CAE165-4A65-F664-0BD8-FDB2C8ED02B1";
	setAttr ".b" -type "string" (
		"// Maya Mel UI Configuration File.\n//\n//  This script is machine generated.  Edit at your own risk.\n//\n//\n\nglobal string $gMainPane;\nif (`paneLayout -exists $gMainPane`) {\n\n\tglobal int $gUseScenePanelConfig;\n\tint    $useSceneConfig = $gUseScenePanelConfig;\n\tint    $nodeEditorPanelVisible = stringArrayContains(\"nodeEditorPanel1\", `getPanel -vis`);\n\tint    $nodeEditorWorkspaceControlOpen = (`workspaceControl -exists nodeEditorPanel1Window` && `workspaceControl -q -visible nodeEditorPanel1Window`);\n\tint    $menusOkayInPanels = `optionVar -q allowMenusInPanels`;\n\tint    $nVisPanes = `paneLayout -q -nvp $gMainPane`;\n\tint    $nPanes = 0;\n\tstring $editorName;\n\tstring $panelName;\n\tstring $itemFilterName;\n\tstring $panelConfig;\n\n\t//\n\t//  get current state of the UI\n\t//\n\tsceneUIReplacement -update $gMainPane;\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Top View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Top View\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|top\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"wireframe\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 1\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n"
		+ "            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n"
		+ "            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 555\n            -height 348\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n"
		+ "\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Side View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Side View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|persp\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 1\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n"
		+ "            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n"
		+ "            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -shadows 0\n            -captureSequenceNumber -1\n"
		+ "            -width 1117\n            -height 741\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Front View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Front View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|front\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"wireframe\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 1\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n"
		+ "            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n"
		+ "            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n"
		+ "            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 555\n            -height 348\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Persp View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Persp View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|render\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n"
		+ "            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 1\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n"
		+ "            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n"
		+ "            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1117\n            -height 741\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"outlinerPanel\" (localizedPanelLabel(\"ToggledOutliner\")) `;\n\tif (\"\" != $panelName) {\n"
		+ "\t\t$label = `panel -q -label $panelName`;\n\t\toutlinerPanel -edit -l (localizedPanelLabel(\"ToggledOutliner\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        outlinerEditor -e \n            -docTag \"isolOutln_fromSeln\" \n            -showShapes 0\n            -showAssignedMaterials 0\n            -showTimeEditor 1\n            -showReferenceNodes 1\n            -showReferenceMembers 1\n            -showAttributes 0\n            -showConnected 0\n            -showAnimCurvesOnly 0\n            -showMuteInfo 0\n            -organizeByLayer 1\n            -organizeByClip 1\n            -showAnimLayerWeight 1\n            -autoExpandLayers 1\n            -autoExpand 0\n            -showDagOnly 1\n            -showAssets 1\n            -showContainedOnly 1\n            -showPublishedAsConnected 0\n            -showParentContainers 0\n            -showContainerContents 1\n            -ignoreDagHierarchy 0\n            -expandConnections 0\n            -showUpstreamCurves 1\n            -showUnitlessCurves 1\n            -showCompounds 1\n"
		+ "            -showLeafs 1\n            -showNumericAttrsOnly 0\n            -highlightActive 1\n            -autoSelectNewObjects 0\n            -doNotSelectNewObjects 0\n            -dropIsParent 1\n            -transmitFilters 0\n            -setFilter \"defaultSetFilter\" \n            -showSetMembers 1\n            -allowMultiSelection 1\n            -alwaysToggleSelect 0\n            -directSelect 0\n            -isSet 0\n            -isSetMember 0\n            -showUfeItems 1\n            -displayMode \"DAG\" \n            -expandObjects 0\n            -setsIgnoreFilters 1\n            -containersIgnoreFilters 0\n            -editAttrName 0\n            -showAttrValues 0\n            -highlightSecondary 0\n            -showUVAttrsOnly 0\n            -showTextureNodesOnly 0\n            -attrAlphaOrder \"default\" \n            -animLayerFilterOptions \"allAffecting\" \n            -sortOrder \"none\" \n            -longNames 0\n            -niceNames 1\n            -showNamespace 1\n            -showPinIcons 0\n            -mapMotionTrails 0\n            -ignoreHiddenAttribute 0\n"
		+ "            -ignoreOutlinerColor 0\n            -renderFilterVisible 0\n            -renderFilterIndex 0\n            -selectionOrder \"chronological\" \n            -expandAttribute 0\n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"outlinerPanel\" (localizedPanelLabel(\"Outliner\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\toutlinerPanel -edit -l (localizedPanelLabel(\"Outliner\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        outlinerEditor -e \n            -docTag \"isolOutln_fromSeln\" \n            -showShapes 0\n            -showAssignedMaterials 0\n            -showTimeEditor 1\n            -showReferenceNodes 0\n            -showReferenceMembers 0\n            -showAttributes 0\n            -showConnected 0\n            -showAnimCurvesOnly 0\n            -showMuteInfo 0\n            -organizeByLayer 1\n            -organizeByClip 1\n            -showAnimLayerWeight 1\n            -autoExpandLayers 1\n"
		+ "            -autoExpand 0\n            -showDagOnly 1\n            -showAssets 1\n            -showContainedOnly 1\n            -showPublishedAsConnected 0\n            -showParentContainers 0\n            -showContainerContents 1\n            -ignoreDagHierarchy 0\n            -expandConnections 0\n            -showUpstreamCurves 1\n            -showUnitlessCurves 1\n            -showCompounds 1\n            -showLeafs 1\n            -showNumericAttrsOnly 0\n            -highlightActive 1\n            -autoSelectNewObjects 0\n            -doNotSelectNewObjects 0\n            -dropIsParent 1\n            -transmitFilters 0\n            -setFilter \"defaultSetFilter\" \n            -showSetMembers 1\n            -allowMultiSelection 1\n            -alwaysToggleSelect 0\n            -directSelect 0\n            -showUfeItems 1\n            -displayMode \"DAG\" \n            -expandObjects 0\n            -setsIgnoreFilters 1\n            -containersIgnoreFilters 0\n            -editAttrName 0\n            -showAttrValues 0\n            -highlightSecondary 0\n"
		+ "            -showUVAttrsOnly 0\n            -showTextureNodesOnly 0\n            -attrAlphaOrder \"default\" \n            -animLayerFilterOptions \"allAffecting\" \n            -sortOrder \"none\" \n            -longNames 0\n            -niceNames 1\n            -showNamespace 1\n            -showPinIcons 0\n            -mapMotionTrails 0\n            -ignoreHiddenAttribute 0\n            -ignoreOutlinerColor 0\n            -renderFilterVisible 0\n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"graphEditor\" (localizedPanelLabel(\"Graph Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Graph Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showAssignedMaterials 0\n                -showTimeEditor 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n"
		+ "                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -organizeByClip 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 1\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showParentContainers 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 1\n                -showCompounds 0\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 1\n                -doNotSelectNewObjects 0\n                -dropIsParent 1\n                -transmitFilters 1\n                -setFilter \"0\" \n                -showSetMembers 0\n"
		+ "                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -showUfeItems 1\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 1\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                -renderFilterVisible 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"GraphEd\");\n            animCurveEditor -e \n                -displayValues 0\n                -snapTime \"integer\" \n"
		+ "                -snapValue \"none\" \n                -showPlayRangeShades \"on\" \n                -lockPlayRangeShades \"off\" \n                -smoothness \"fine\" \n                -resultSamples 1\n                -resultScreenSamples 0\n                -resultUpdate \"delayed\" \n                -showUpstreamCurves 1\n                -keyMinScale 1\n                -stackedCurvesMin -1\n                -stackedCurvesMax 1\n                -stackedCurvesSpace 0.2\n                -preSelectionHighlight 0\n                -constrainDrag 0\n                -valueLinesToggle 1\n                -outliner \"graphEditor1OutlineEd\" \n                -highlightAffectedCurves 0\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dopeSheetPanel\" (localizedPanelLabel(\"Dope Sheet\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dope Sheet\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showAssignedMaterials 0\n                -showTimeEditor 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -organizeByClip 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 0\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showParentContainers 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 0\n                -showCompounds 1\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n"
		+ "                -highlightActive 0\n                -autoSelectNewObjects 0\n                -doNotSelectNewObjects 1\n                -dropIsParent 1\n                -transmitFilters 0\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -showUfeItems 1\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 0\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n"
		+ "                -ignoreOutlinerColor 0\n                -renderFilterVisible 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"DopeSheetEd\");\n            dopeSheetEditor -e \n                -displayValues 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -outliner \"dopeSheetPanel1OutlineEd\" \n                -showSummary 1\n                -showScene 0\n                -hierarchyBelow 0\n                -showTicks 1\n                -selectionWindow 0 0 0 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"timeEditorPanel\" (localizedPanelLabel(\"Time Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Time Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"clipEditorPanel\" (localizedPanelLabel(\"Trax Editor\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Trax Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = clipEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayValues 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -initialized 0\n                -manageSequencer 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"sequenceEditorPanel\" (localizedPanelLabel(\"Camera Sequencer\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Camera Sequencer\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = sequenceEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayValues 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -initialized 0\n"
		+ "                -manageSequencer 1 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperGraphPanel\" (localizedPanelLabel(\"Hypergraph Hierarchy\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypergraph Hierarchy\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"HyperGraphEd\");\n            hyperGraph -e \n                -graphLayoutStyle \"hierarchicalLayout\" \n                -orientation \"horiz\" \n                -mergeConnections 0\n                -zoom 1\n                -animateTransition 0\n                -showRelationships 1\n                -showShapes 0\n                -showDeformers 0\n                -showExpressions 0\n                -showConstraints 0\n                -showConnectionFromSelected 0\n                -showConnectionToSelected 0\n                -showConstraintLabels 0\n                -showUnderworld 0\n"
		+ "                -showInvisible 0\n                -transitionFrames 1\n                -opaqueContainers 0\n                -freeform 0\n                -imagePosition 0 0 \n                -imageScale 1\n                -imageEnabled 0\n                -graphType \"DAG\" \n                -heatMapDisplay 0\n                -updateSelection 1\n                -updateNodeAdded 1\n                -useDrawOverrideColor 0\n                -limitGraphTraversal -1\n                -range 0 0 \n                -iconSize \"smallIcons\" \n                -showCachedConnections 0\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperShadePanel\" (localizedPanelLabel(\"Hypershade\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypershade\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"visorPanel\" (localizedPanelLabel(\"Visor\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Visor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"nodeEditorPanel\" (localizedPanelLabel(\"Node Editor\")) `;\n\tif ($nodeEditorPanelVisible || $nodeEditorWorkspaceControlOpen) {\n\t\tif (\"\" == $panelName) {\n\t\t\tif ($useSceneConfig) {\n\t\t\t\t$panelName = `scriptedPanel -unParent  -type \"nodeEditorPanel\" -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -connectNodeOnCreation 0\n                -connectOnDrop 0\n                -copyConnectionsOnPaste 0\n                -connectionStyle \"bezier\" \n                -defaultPinnedState 0\n"
		+ "                -additiveGraphingMode 0\n                -connectedGraphingMode 1\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"rmanNodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n                -crosshairOnEdgeDragging 0\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n                -extendToShapes 1\n                -showUnitConversions 0\n                -editorMode \"default\" \n                -hasWatchpoint 0\n                $editorName;\n\t\t\t}\n\t\t} else {\n\t\t\t$label = `panel -q -label $panelName`;\n\t\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n"
		+ "                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -connectNodeOnCreation 0\n                -connectOnDrop 0\n                -copyConnectionsOnPaste 0\n                -connectionStyle \"bezier\" \n                -defaultPinnedState 0\n                -additiveGraphingMode 0\n                -connectedGraphingMode 1\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"rmanNodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n                -crosshairOnEdgeDragging 0\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n"
		+ "                -extendToShapes 1\n                -showUnitConversions 0\n                -editorMode \"default\" \n                -hasWatchpoint 0\n                $editorName;\n\t\t\tif (!$useSceneConfig) {\n\t\t\t\tpanel -e -l $label $panelName;\n\t\t\t}\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"createNodePanel\" (localizedPanelLabel(\"Create Node\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Create Node\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"polyTexturePlacementPanel\" (localizedPanelLabel(\"UV Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"UV Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"renderWindowPanel\" (localizedPanelLabel(\"Render View\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Render View\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"shapePanel\" (localizedPanelLabel(\"Shape Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tshapePanel -edit -l (localizedPanelLabel(\"Shape Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"posePanel\" (localizedPanelLabel(\"Pose Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tposePanel -edit -l (localizedPanelLabel(\"Pose Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynRelEdPanel\" (localizedPanelLabel(\"Dynamic Relationships\")) `;\n\tif (\"\" != $panelName) {\n"
		+ "\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dynamic Relationships\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"relationshipPanel\" (localizedPanelLabel(\"Relationship Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Relationship Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"referenceEditorPanel\" (localizedPanelLabel(\"Reference Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Reference Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynPaintScriptedPanelType\" (localizedPanelLabel(\"Paint Effects\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Paint Effects\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"scriptEditorPanel\" (localizedPanelLabel(\"Script Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Script Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"profilerPanel\" (localizedPanelLabel(\"Profiler Tool\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Profiler Tool\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"contentBrowserPanel\" (localizedPanelLabel(\"Content Browser\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Content Browser\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"Stereo\" (localizedPanelLabel(\"Stereo\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Stereo\")) -mbv $menusOkayInPanels  $panelName;\n{ string $editorName = ($panelName+\"Editor\");\n            stereoCameraView -e \n                -camera \"|persp\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"wireframe\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 1\n"
		+ "                -backfaceCulling 0\n                -xray 0\n                -jointXray 0\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 4 4 \n                -bumpResolution 4 4 \n                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n"
		+ "                -lowQualityLighting 0\n                -maximumNumHardwareLights 0\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -controllers 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n"
		+ "                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -bluePencil 1\n                -greasePencils 0\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 0\n                -height 0\n                -sceneRenderFilter 0\n                -displayMode \"centerEye\" \n                -viewColor 0 0 0 1 \n                -useCustomBackground 1\n                $editorName;\n            stereoCameraView -e -viewSelected 0 $editorName;\n            stereoCameraView -e \n                -pluginObjects \"gpuCacheDisplayFilter\" 1 \n                $editorName; };\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\tif ($useSceneConfig) {\n"
		+ "        string $configName = `getPanel -cwl (localizedPanelLabel(\"Current Layout\"))`;\n        if (\"\" != $configName) {\n\t\t\tpanelConfiguration -edit -label (localizedPanelLabel(\"Current Layout\")) \n\t\t\t\t-userCreated false\n\t\t\t\t-defaultImage \"vacantCell.xP:/\"\n\t\t\t\t-image \"\"\n\t\t\t\t-sc false\n\t\t\t\t-configString \"global string $gMainPane; paneLayout -e -cn \\\"single\\\" -ps 1 100 100 $gMainPane;\"\n\t\t\t\t-removeAllPanels\n\t\t\t\t-ap false\n\t\t\t\t\t(localizedPanelLabel(\"Persp View\")) \n\t\t\t\t\t\"modelPanel\"\n"
		+ "\t\t\t\t\t\"$panelName = `modelPanel -unParent -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels `;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -camera \\\"|render\\\" \\n    -useInteractiveMode 0\\n    -displayLights \\\"default\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 1\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 0\\n    -activeComponentsXray 0\\n    -displayTextures 0\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -controllers 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -bluePencil 1\\n    -greasePencils 0\\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1117\\n    -height 741\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName;\\nmodelEditor -e \\n    -pluginObjects \\\"gpuCacheDisplayFilter\\\" 1 \\n    $editorName\"\n"
		+ "\t\t\t\t\t\"modelPanel -edit -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels  $panelName;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -camera \\\"|render\\\" \\n    -useInteractiveMode 0\\n    -displayLights \\\"default\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 1\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 0\\n    -activeComponentsXray 0\\n    -displayTextures 0\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -controllers 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -bluePencil 1\\n    -greasePencils 0\\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1117\\n    -height 741\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName;\\nmodelEditor -e \\n    -pluginObjects \\\"gpuCacheDisplayFilter\\\" 1 \\n    $editorName\"\n"
		+ "\t\t\t\t$configName;\n\n            setNamedPanelLayout (localizedPanelLabel(\"Current Layout\"));\n        }\n\n        panelHistory -e -clear mainPanelHistory;\n        sceneUIReplacement -clear;\n\t}\n\n\ngrid -spacing 5 -size 12 -divisions 5 -displayAxes yes -displayGridLines yes -displayDivisionLines yes -displayPerspectiveLabels no -displayOrthographicLabels no -displayAxesBold yes -perspectiveLabelPosition axis -orthographicLabelPosition edge;\nviewManip -drawCompass 0 -compassAngle 0 -frontParameters \"\" -homeParameters \"\" -selectionLockParameters \"\";\n}\n");
	setAttr ".st" 3;
createNode script -n "sceneConfigurationScriptNode";
	rename -uid "54EBE4DD-4BCE-D509-70E3-B38F8B0EC1B1";
	setAttr ".b" -type "string" "playbackOptions -min 1 -max 500 -ast 1 -aet 500 ";
	setAttr ".st" 6;
createNode polyPlane -n "polyPlane3";
	rename -uid "BBF148E5-456A-BA62-4BE7-AE8685B42237";
	setAttr ".sw" 1;
	setAttr ".sh" 1;
	setAttr ".cuv" 2;
createNode polyExtrudeFace -n "polyExtrudeFace2";
	rename -uid "9EF04A7C-42F6-3DAD-8BE1-0183F13C0ADB";
	setAttr ".ics" -type "componentList" 1 "f[0]";
	setAttr ".ix" -type "matrix" -2.2240167782276086e-15 -5.0080405668457955 0 0 5.0080405668457955 -2.2240167782276086e-15 0 0
		 0 0 5.0080405668457955 0 -11.000000208777699 9.9959797859191895 3.0040197372436523 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" -11 7.0000005 3.3749998 ;
	setAttr ".rs" 64175;
	setAttr ".c[0]"  0 1 1;
	setAttr ".m23" no;
	setAttr ".cbn" -type "double3" -11.000000208777701 1.6000005588727184 0.59999942605193146 ;
	setAttr ".cbx" -type "double3" -11.000000208777697 12.40000009711091 6.1500000490252305 ;
createNode polyTweak -n "polyTweak5";
	rename -uid "68418CF6-43B5-1310-94FA-1EA1E376CD6F";
	setAttr ".uopa" yes;
	setAttr -s 4 ".tk[0:3]" -type "float3"  0.019967889 8.8675242e-18
		 0.12818587 1.17649984 5.2247089e-16 0.12818587 0.019967889 8.8675242e-18 0.019967889
		 1.17649984 5.2247089e-16 0.019967889;
createNode PxrSurface -n "mat_floor";
	rename -uid "F4E9501F-463E-3A49-A678-4DB15F8D76A4";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0 0 0 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.28057554364204407;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_floor_sg";
	rename -uid "7075F3A6-4E9C-E757-BCB6-EFA6F966DF2A";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo1";
	rename -uid "16DDA207-4AFE-0ADB-E8B5-82961B983260";
createNode lambert -n "lambert2";
	rename -uid "A5291F23-41D2-642B-6D08-9ABA099D019D";
createNode PxrTexture -n "floor_diffuse";
	rename -uid "14553FCA-41D3-41C0-8CB2-9585E6B49F83";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/floor_diffuse.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" yes;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture1";
createNode PxrDisplace -n "PxrDisplace1";
	rename -uid "6A930542-4D08-485F-4282-8E8225C55501";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enabled" yes;
	setAttr ".dispAmount" 0.090000003576278687;
	setAttr ".dispScalar" 0;
	setAttr ".dispVector" -type "float3" 0 0 0 ;
	setAttr ".modelDispVector" -type "float3" 0 0 0 ;
createNode PxrDispScalarLayer -n "PxrDispScalarLayer1";
	rename -uid "E442F2C3-4460-A1C1-99E0-878603BE91BA";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".overallAmount" 1;
	setAttr ".baseLayerEnabled" yes;
	setAttr ".baseLayerAmount" 0.10000000149011612;
	setAttr ".baseLayerDispScalar" 0;
	setAttr ".layer1Enabled" yes;
	setAttr ".layer1Amount" 1;
	setAttr ".layer1DispScalar" 0;
	setAttr ".layer1Mask" 1;
	setAttr ".layer1Comp" 1;
	setAttr ".layer2Enabled" no;
	setAttr ".layer2Amount" 1;
	setAttr ".layer2DispScalar" 0;
	setAttr ".layer2Mask" 1;
	setAttr ".layer2Comp" 1;
	setAttr ".layer3Enabled" no;
	setAttr ".layer3Amount" 1;
	setAttr ".layer3DispScalar" 0;
	setAttr ".layer3Mask" 1;
	setAttr ".layer3Comp" 1;
	setAttr ".layer4Enabled" no;
	setAttr ".layer4Amount" 1;
	setAttr ".layer4DispScalar" 0;
	setAttr ".layer4Mask" 1;
	setAttr ".layer4Comp" 1;
createNode PxrTexture -n "floor_displace";
	rename -uid "5B9FAF30-4309-DC04-1122-8FA9A8FBB761";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/floor_displace.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" no;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture2";
createNode PxrToFloat -n "PxrToFloat1";
	rename -uid "87E37BA5-4AA7-AEF9-73D1-AE902C36452E";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".input" -type "float3" 0 0 0 ;
	setAttr ".mode" 0;
createNode rmanDisplay -s -n "rmanDefaultDisplay";
	rename -uid "24CF8D9E-4595-B41C-25E0-52949FD9C3F1";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".denoise" yes;
	setAttr ".frameMode" 0;
	setAttr ".opticalFlow" no;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr -s 2 ".displayChannels";
	setAttr ".name" -type "string" "";
createNode d_openexr -n "d_openexr1";
	rename -uid "0783F954-4322-47B9-185D-BA9C602ADDD6";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".asrgba" yes;
	setAttr ".autocrop" -type "string" "false";
	setAttr ".storage" -type "string" "scanline";
	setAttr ".exrpixeltype" -type "string" "float";
	setAttr ".compression" -type "string" "zips";
	setAttr ".compressionlevel" 45;
	setAttr ".forcepar" 0;
	setAttr ".metadatacount" 0;
createNode rmanDisplayChannel -n "Ci";
	rename -uid "54F93B92-4241-0251-0956-4A82F837C8A6";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".channelType" -type "string" "color";
	setAttr ".channelSource" -type "string" "Ci";
	setAttr ".lpeLightGroup" -type "string" "";
	setAttr ".filter" -type "string" "inherit from display";
	setAttr ".filterwidth" -type "float2" -1 -1 ;
	setAttr ".statistics" -type "string" "";
	setAttr ".relativepixelvariance" 1;
	setAttr ".shadowthreshold" 0.0099999997764825821;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr ".name" -type "string" "Ci";
createNode rmanDisplayChannel -n "a1";
	rename -uid "CE8B19ED-406C-2F97-8DEF-09AACFB35BC0";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enable" yes;
	setAttr ".channelType" -type "string" "float";
	setAttr ".channelSource" -type "string" "a";
	setAttr ".lpeLightGroup" -type "string" "";
	setAttr ".filter" -type "string" "inherit from display";
	setAttr ".filterwidth" -type "float2" -1 -1 ;
	setAttr ".statistics" -type "string" "";
	setAttr ".relativepixelvariance" -1;
	setAttr ".shadowthreshold" 0.0099999997764825821;
	setAttr ".remapBreakPoint" 0;
	setAttr ".remapMaxValue" 0;
	setAttr ".remapSmoothness" 0;
	setAttr ".name" -type "string" "a";
createNode PxrManifold2D -n "PxrManifold2D1";
	rename -uid "5954B2B0-4BF1-D394-537B-A8B30C194808";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enableTransforms" yes;
	setAttr ".center" -type "float3" 0 0 0 ;
	setAttr ".angle" 90;
	setAttr ".scaleS" 3;
	setAttr ".scaleT" 3;
	setAttr ".offsetS" 0;
	setAttr ".offsetT" 0;
	setAttr ".invertS" no;
	setAttr ".invertT" yes;
	setAttr ".warp" 0;
	setAttr ".warpAmount" 1;
	setAttr ".randomize" no;
	setAttr ".source" 0;
	setAttr ".varName" -type "string" "";
	setAttr ".seed" 0;
	setAttr ".probability" 1;
	setAttr ".scaleNormalizedPrimvar" no;
	setAttr ".rAngleMin" 0;
	setAttr ".rAngleMax" 0;
	setAttr ".rOffsetSMin" -0.5;
	setAttr ".rOffsetSMax" 0.5;
	setAttr ".rOffsetTMin" -0.5;
	setAttr ".rOffsetTMax" 0.5;
	setAttr ".rScaleSMin" 0;
	setAttr ".rScaleSMax" 0;
	setAttr ".enableRScaleT" no;
	setAttr ".rScaleTMin" 0;
	setAttr ".rScaleTMax" 0;
	setAttr ".calcRadius" no;
	setAttr ".enableJacobianFilter" no;
	setAttr ".jacobianRadiusMult" 1;
	setAttr ".__rfk_inDisplacement" 0;
	setAttr ".verbosity" 0;
	setAttr ".name_uvSet" -type "string" "";
	setAttr ".default_uvSet" -type "float3" 0 0 0 ;
createNode polyPlane -n "polyPlane5";
	rename -uid "133BE692-4987-B2DD-7310-46A16C957289";
	setAttr ".sw" 1;
	setAttr ".sh" 1;
	setAttr ".cuv" 2;
createNode polyExtrudeEdge -n "polyExtrudeEdge11";
	rename -uid "2E627EAC-455C-B9EB-0067-269535FD8B97";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[2]";
	setAttr ".ix" -type "matrix" 17.200641317725452 0 0 0 0 -7.6386192117030359e-15 17.200641317725452 0
		 0 -17.200641317725452 -7.6386192117030359e-15 0 -2.3996791839599538 9.6003213352801016 12.000000000000004 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 11.999999 12.5 12 ;
	setAttr ".rs" 33533;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 11.999999298947031 1.0000006764173754 12 ;
	setAttr ".cbx" -type "double3" 11.999999298947031 23.999999818187085 12.000000000000007 ;
createNode polyTweak -n "polyTweak20";
	rename -uid "28E58DDC-436A-6161-AD37-9C8F274688D1";
	setAttr ".uopa" yes;
	setAttr -s 3 ".tk[1:3]" -type "float3"  0.33715943 0 0 0 -1.4972886e-16
		 -0.33715943 0.33715943 -1.4972886e-16 -0.33715943;
createNode PxrCamera -n "PxrCamera1";
	rename -uid "7A6AE712-400E-15C8-2D13-1E8682FC7F42";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".lensType" 2;
	setAttr ".fov" 1;
	setAttr ".fovEnd" 0;
	setAttr ".fStop" 16;
	setAttr ".focalLength" 0;
	setAttr ".focalDistance" 1;
	setAttr ".tilt" 0;
	setAttr ".roll" 0;
	setAttr ".focus1" -type "float3" 0 0 0 ;
	setAttr ".focus2" -type "float3" 0 0 0 ;
	setAttr ".focus3" -type "float3" 0 0 0 ;
	setAttr ".shiftX" 0;
	setAttr ".shiftY" 0;
	setAttr ".lensScale" 1;
	setAttr ".radial1" 0;
	setAttr ".radial2" 0;
	setAttr ".assymX" 0;
	setAttr ".assymY" 0;
	setAttr ".lensAsymmetryX" 0;
	setAttr ".lensAsymmetryY" 0;
	setAttr -s 2 ".distortionCtr[0:1]"  0 0;
	setAttr ".squeeze" 1;
	setAttr -s 3 ".dofPivotCenter[0:2]"  0 0 0;
	setAttr ".dofRadiusStrength" 0;
	setAttr ".dofRadiusFalloff" 1;
	setAttr -s 3 ".dofSqCtr[0:2]"  0 0 0;
	setAttr ".dofSqStrength" 0;
	setAttr ".dofSqAnamorph" 1;
	setAttr ".dofSqFalloff" 1;
	setAttr ".dofMult" 1;
	setAttr ".cocTexture" -type "string" "";
	setAttr ".numSplitDiopters" 0;
	setAttr ".splitDiopterAngle" 0;
	setAttr ".splitDiopterOffset1" 0;
	setAttr ".splitDiopterWidth1" 0;
	setAttr ".splitDiopterFocusDistance1" 0;
	setAttr ".splitDiopterOffset2" 0;
	setAttr ".splitDiopterWidth2" 0;
	setAttr ".splitDiopterFocusDistance2" 0;
	setAttr ".transverse" -type "float3" 1 1 1 ;
	setAttr ".axial" -type "float3" 0 0 0 ;
	setAttr ".natural" 0;
	setAttr ".optical" 0;
	setAttr ".sweep" -type "string" "down";
	setAttr ".duration" 1;
	setAttr ".detail" 0;
	setAttr ".enhance" -type "float3" 0 0 1 ;
	setAttr ".matte" -type "string" "";
	setAttr ".enhanceDisableDOF" 0;
	setAttr ".enhanceDisableMoBlur" 0;
	setAttr ".enhanceDiffAdjust" 0;
createNode PxrSurface -n "mat_door";
	rename -uid "680546FC-4E70-B931-08FC-2A9C92C0D83F";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.20000000298023224;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0.6388888955116272;
	setAttr ".singlescatterColor" -type "float3" 0 0 0 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 1;
	setAttr ".reflectionGain" 1;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_door_sg";
	rename -uid "49C1F21D-4669-FD50-FC57-75B0F7BE2978";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo2";
	rename -uid "4E454677-4A70-3EDA-C167-C382D5216B20";
createNode lambert -n "lambert3";
	rename -uid "CCCFCED5-4A5E-C9A2-127C-D0BDF53269F4";
createNode PxrVolume -n "PxrVolume1";
	rename -uid "0FFC6B12-4858-2F4F-F19F-2B969ADFA846";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".diffuseColor" -type "float3" 1 1 1 ;
	setAttr ".emitColor" -type "float3" 0.066891111 0.097176306 0.18036638 ;
	setAttr ".__islight" no;
	setAttr ".multiScatter" yes;
	setAttr ".velocityPrimVar" -type "string" "";
	setAttr ".velocity" -type "float3" 0 0 0 ;
	setAttr ".velocityMultiplier" 1;
	setAttr ".extinctionDistance" 0;
	setAttr ".densityFloatPrimVar" -type "string" "";
	setAttr ".densityFloat" 0.012000000104308128;
	setAttr ".densityColorPrimVar" -type "string" "";
	setAttr ".densityColor" -type "float3" 1 1 1 ;
	setAttr ".maxDensity" -1;
	setAttr ".shadowDensityMultiplier" 1;
	setAttr ".anisotropy" 0;
	setAttr ".anisotropy2" 0;
	setAttr ".blendFactor" 0;
	setAttr ".equiangularWeight" 0.5;
	setAttr ".minSamples" 4;
	setAttr ".maxSamples" 4;
	setAttr ".multiScatterOpt" no;
	setAttr ".extinctionMultiplier" 1;
	setAttr ".contributionMultiplier" 1;
createNode shadingEngine -n "PxrVolume1SG";
	rename -uid "19B3D5A8-41D9-6F45-B319-FEABE968CA76";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo3";
	rename -uid "5E2BEDBF-4D44-9488-FAFF-B8806CFE7D55";
createNode lambert -n "lambert4";
	rename -uid "839C7CA4-4F70-6992-B425-FEB06E9D06C8";
createNode polyMapSew -n "polyMapSew1";
	rename -uid "5201B4A5-4710-8F5E-622C-798EBB12584C";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:11]";
createNode polyTweak -n "polyTweak21";
	rename -uid "729D0A49-4D39-BD2B-6851-969F42C201AF";
	setAttr ".uopa" yes;
	setAttr -s 4 ".tk[4:7]" -type "float3"  0 0.027631922 0 0 0.027631922
		 0 0 0.027631922 0 0 0.027631922 0;
createNode polyMapCut -n "polyMapCut1";
	rename -uid "B3B49714-4A71-5C12-6475-EAAE2D9A0C78";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[4:5]" "e[7]" "e[9]";
createNode polyMapCut -n "polyMapCut2";
	rename -uid "258EE440-4F00-05C4-3B2F-AB9DF35B2FE3";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:3]";
createNode polyTweakUV -n "polyTweakUV1";
	rename -uid "4D109283-4961-98F8-E40A-B3BE4A3F931C";
	setAttr ".uopa" yes;
	setAttr -s 12 ".uvtk[0:11]" -type "float2" -0.19857053 0.14474218 0.17758691
		 0.07742732 -0.16300912 -0.13139558 0.21314561 -0.19870555 -0.18691975 0.15676054
		 0.1678859 0.09112367 0.20149887 -0.21072632 -0.15330841 -0.14509213 0.14761296 -1.2005583
		 0.27474916 -0.37866455 -0.14761293 1.2005583 -0.27474922 0.37866458;
createNode polyLayoutUV -n "polyLayoutUV1";
	rename -uid "A796A2D9-4D93-AB15-C0A5-028B17D16AD1";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[0]" "f[2:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV2";
	rename -uid "4FB8892F-45CB-137A-EB1F-47816F5A5D7D";
	setAttr ".uopa" yes;
	setAttr -s 8 ".uvtk[0:7]" -type "float2" 0.13385895 0.9083457 -0.82419419
		 -0.40425289 0.82418948 0.40425587 -0.13385701 -0.90834308 0.13815372 0.88907605 -0.80441034
		 -0.40356734 -0.13815689 -0.88907599 0.80440557 0.40357065;
createNode polyLayoutUV -n "polyLayoutUV2";
	rename -uid "320E9AC4-4BAE-8D1E-2136-23B0AF561AA8";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[0]" "f[2:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV3";
	rename -uid "B1F82851-4D61-BA9A-FE09-84957B978599";
	setAttr ".uopa" yes;
	setAttr -s 8 ".uvtk[0:7]" -type "float2" 0.31292617 1.044057727 -1.03744173
		 -0.33359843 1.037433863 0.3336001 -0.31292623 -1.044057727 0.31466824 1.020686388
		 -1.014084697 -0.33618408 -0.31467479 -1.020688295 1.014076829 0.33618617;
createNode polyLayoutUV -n "polyLayoutUV3";
	rename -uid "56A81E54-4A6A-4095-0AA4-9F8696283E73";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[0]" "f[2:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV4";
	rename -uid "102A9131-4124-6A35-2CDC-3AAE6DF62163";
	setAttr ".uopa" yes;
	setAttr -s 4 ".uvtk[8:11]" -type "float2" -0.034352899 1.38275385 -1.10426641
		 -0.83293712 0.034352779 -1.38275397 1.10426641 0.83293718;
createNode polyLayoutUV -n "polyLayoutUV4";
	rename -uid "108C8490-4BDA-129A-490D-288B27D79EDC";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[1]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV5";
	rename -uid "841C2F4C-4CB1-9D9B-EB25-CDA08DFCD8A2";
	setAttr ".uopa" yes;
	setAttr -s 12 ".uvtk[0:11]" -type "float2" -0.14490804 -0.19110668 -0.14489649
		 0.21591692 -0.35900569 -0.1910553 -0.35899562 0.2159674 -0.14862224 -0.18784231 -0.14879787
		 0.21285696 -0.3552807 0.2127043 -0.35510427 -0.18799537 0.37174416 -0.25042319 0.37174493
		 0.197486 0.14156932 0.19748643 0.14156854 -0.25042278;
createNode PxrTexture -n "door_roughness";
	rename -uid "342670CF-46AE-7E1F-89E4-FFB9656041E9";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/door_roughness.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0.05000000074505806;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" no;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture3";
createNode PxrSurface -n "mat_metal";
	rename -uid "C8290C03-40E6-2675-08A5-D3AED8BF6F9A";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0.17741977 0.17380735 0.17242016 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0.071695253 0.069881059 0.069179118 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.27819550037384033;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_metal_sg";
	rename -uid "FD516D82-4A2D-FEAB-8868-51884724771E";
	setAttr ".ihi" 0;
	setAttr -s 2 ".dsm";
	setAttr ".ro" yes;
	setAttr -s 2 ".gn";
createNode materialInfo -n "materialInfo4";
	rename -uid "32142671-4544-DE13-674C-28A7943ED224";
createNode lambert -n "lambert5";
	rename -uid "17D55A51-4FE7-15AF-9851-6896D3920433";
createNode PxrSurface -n "mat_room";
	rename -uid "2F459E2A-47A0-D523-B0F9-BF8A35E5C427";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0.69999999 0.69999999 0.69999999 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.20000000298023224;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_room_sg";
	rename -uid "F9F07CDC-4620-084D-175C-8493B3E7C8DE";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo5";
	rename -uid "AC2BA6BB-483A-B76F-4990-BC898D654D31";
createNode lambert -n "lambert6";
	rename -uid "FD3CD8B5-44B8-6874-6631-AD9857C0AF7F";
createNode PxrColorCorrect -n "PxrColorCorrect1";
	rename -uid "40C2EE50-4EC6-19C8-9197-C7BEA8A8143D";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputRGB" -type "float3" 0 0 0 ;
	setAttr ".inputMask" 1;
	setAttr ".invertMask" no;
	setAttr ".mixMask" 1;
	setAttr ".inputMin" -type "float3" 0 0 0 ;
	setAttr ".inputMax" -type "float3" 1 1 1 ;
	setAttr ".gamma" -type "float3" 1 1 1 ;
	setAttr ".contrast" -type "float3" 0 0 0 ;
	setAttr ".contrastPivot" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rgbGain" -type "float3" 1 1 1 ;
	setAttr ".hsv" -type "float3" 0 1 1 ;
	setAttr ".exposure" 1.7142857313156128;
	setAttr ".outputMin" -type "float3" 0 0 0 ;
	setAttr ".outputMax" -type "float3" 1 1 1 ;
	setAttr ".clampOutput" no;
	setAttr ".clampMin" -type "float3" 0 0 0 ;
	setAttr ".clampMax" -type "float3" 1 1 1 ;
createNode PxrTexture -n "floor_specular";
	rename -uid "0360F8A5-49BF-EBCD-EEEC-67B86371CA29";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/floor_specular.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0.12999999523162842;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" no;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture4";
createNode PxrColorCorrect -n "PxrColorCorrect2";
	rename -uid "579F6A34-409C-48D4-9D80-979F2959A91E";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputRGB" -type "float3" 0 0 0 ;
	setAttr ".inputMask" 1;
	setAttr ".invertMask" no;
	setAttr ".mixMask" 1;
	setAttr ".inputMin" -type "float3" 0 0 0 ;
	setAttr ".inputMax" -type "float3" 1 1 1 ;
	setAttr ".gamma" -type "float3" 1 1 1 ;
	setAttr ".contrast" -type "float3" 0 0 0 ;
	setAttr ".contrastPivot" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".rgbGain" -type "float3" 1 1 1 ;
	setAttr ".hsv" -type "float3" 0 1 1 ;
	setAttr ".exposure" 0;
	setAttr ".outputMin" -type "float3" 0 0 0 ;
	setAttr ".outputMax" -type "float3" 1 1 1 ;
	setAttr ".clampOutput" yes;
	setAttr ".clampMin" -type "float3" 0.050000001 0.050000001 0.050000001 ;
	setAttr ".clampMax" -type "float3" 0.40000001 0.40000001 0.40000001 ;
createNode PxrSurface -n "mat_drain";
	rename -uid "BCE00F7A-4E1B-6DF5-32A8-DE8F91064340";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0.54676259 0.54676259 0.54676259 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0.17266187 0.17266187 0.17266187 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.15107913315296173;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 0;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_drain_sg";
	rename -uid "8D25100F-4836-27BF-7687-229D35549496";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo6";
	rename -uid "BD863ADB-430A-7774-3644-D381666B5504";
createNode lambert -n "lambert7";
	rename -uid "0371AE64-4E97-2EDE-7ED1-DEAFCC8A2157";
createNode PxrTexture -n "drain_mask";
	rename -uid "68F8749E-403E-AEDC-D741-6B890815EB99";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/drain_mask.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" no;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture5";
createNode polyExtrudeEdge -n "polyExtrudeEdge14";
	rename -uid "31D98A80-4FAF-7239-F3AB-F3ADA7BBE40B";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[3]";
	setAttr ".ix" -type "matrix" 17.200641317725452 0 0 0 0 -7.6386192117030359e-15 17.200641317725452 0
		 0 -17.200641317725452 -7.6386192117030359e-15 0 -2.3996791839599538 9.6003213352801016 12.000000000000004 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 0.50000024 24 12 ;
	setAttr ".rs" 42229;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" -10.99999984282268 23.999999818187085 12.000000000000011 ;
	setAttr ".cbx" -type "double3" 12.000000324185146 23.999999818187085 12.000000000000011 ;
createNode polyTweak -n "polyTweak28";
	rename -uid "4FBD5D5A-4638-6AC7-2222-8880047357FB";
	setAttr ".uopa" yes;
	setAttr -s 2 ".tk[4:5]" -type "float3"  0 -1.3371594 4.9960036e-16
		 0 -1.3371594 5.5511151e-16;
createNode polyMergeVert -n "polyMergeVert3";
	rename -uid "E0FFAD1C-45CD-5C5A-6948-3289A68F8053";
	setAttr ".ics" -type "componentList" 1 "vtx[0:7]";
	setAttr ".ix" -type "matrix" 17.200641317725452 0 0 0 0 -7.6386192117030359e-15 17.200641317725452 0
		 0 -17.200641317725452 -7.6386192117030359e-15 0 -2.3996791839599538 9.6003213352801016 12.000000000000004 1;
	setAttr ".am" yes;
createNode polyTweak -n "polyTweak29";
	rename -uid "6201945A-4841-50C0-4708-CBB19C7FAEB3";
	setAttr ".uopa" yes;
	setAttr -s 2 ".tk[6:7]" -type "float3"  0 -1.33715951 6.6613381e-16
		 0 -1.33715951 6.6613381e-16;
createNode PxrSurface -n "mat_emit_blue";
	rename -uid "F7767E4A-45D4-C02E-2856-5DA98D2A18D0";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" -0.18841019 0.18082829 0.6516012 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.20000000298023224;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 1;
	setAttr ".reflectionGain" 1;
	setAttr ".refractionColor" -type "float3" 0.12623881 0.2065829 0.8743878 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 0.13703734 0.21511893 0.87680817 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 0.20164217 0.2905224 0.89543176 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_emit_blue_sg";
	rename -uid "390625C7-4873-0332-B00D-01822AC0920D";
	setAttr ".ihi" 0;
	setAttr -s 2 ".dsm";
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo7";
	rename -uid "9E98E452-4721-6FD6-4CA6-469AC766C202";
createNode lambert -n "lambert8";
	rename -uid "91957AF5-49E1-7C25-474E-658B58C0E37D";
createNode PxrVolume -n "PxrVolume2";
	rename -uid "55ED502C-4109-937C-794C-D5B90214A7C8";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".diffuseColor" -type "float3" 0.71558279 0.76962364 0.97580969 ;
	setAttr ".emitColor" -type "float3" 0.29043716 0.30376697 0.3486186 ;
	setAttr ".__islight" no;
	setAttr ".multiScatter" yes;
	setAttr ".velocityPrimVar" -type "string" "";
	setAttr ".velocity" -type "float3" 0 0 0 ;
	setAttr ".velocityMultiplier" 1;
	setAttr ".extinctionDistance" 0;
	setAttr ".densityFloatPrimVar" -type "string" "";
	setAttr ".densityFloat" 0.014999999664723873;
	setAttr ".densityColorPrimVar" -type "string" "";
	setAttr ".densityColor" -type "float3" 1 1 1 ;
	setAttr ".maxDensity" -1;
	setAttr ".shadowDensityMultiplier" 1;
	setAttr ".anisotropy" 0;
	setAttr ".anisotropy2" 0;
	setAttr ".blendFactor" 0;
	setAttr ".equiangularWeight" 0.5;
	setAttr ".minSamples" 4;
	setAttr ".maxSamples" 4;
	setAttr ".multiScatterOpt" no;
	setAttr ".extinctionMultiplier" 1;
	setAttr ".contributionMultiplier" 1;
createNode shadingEngine -n "PxrVolume2SG";
	rename -uid "A96DC632-47D2-B727-4027-F08E4BA8E6B3";
	setAttr ".ihi" 0;
	setAttr -s 2 ".dsm";
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo8";
	rename -uid "C41D2ACF-4448-045C-1203-54A66591080E";
createNode lambert -n "lambert9";
	rename -uid "2A86C36B-42F1-DE5F-CDB2-9FBF1DFBA923";
createNode polyCylinder -n "polyCylinder1";
	rename -uid "31C4489C-4774-3742-9856-4AA4801624AD";
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
	setAttr ".ouv" yes;
createNode PxrSurface -n "mat_handle";
	rename -uid "2071A0E0-4F6D-118C-B4C2-DC8ED58F4DF2";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0 0 0 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.20000000298023224;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0.60150378942489624;
	setAttr ".glowColor" -type "float3" 0 0 0 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_handle_sg";
	rename -uid "53AD12E3-4652-11CA-949F-EE857C53DED0";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo11";
	rename -uid "3BDA58AE-4798-9272-6FD2-BAB18AC45942";
createNode lambert -n "lambert10";
	rename -uid "5CF6236D-4829-5B32-7BEF-48BDC8355EE4";
createNode PxrTexture -n "handle_displace";
	rename -uid "6905D3EC-4FC8-E907-493D-94A6842D071C";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/handle_displace.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0.004999999888241291;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" yes;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture6";
createNode PxrTexture -n "handle_diffuse";
	rename -uid "DB012FE0-4226-9704-0127-83BA925E7305";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/handle_diffuse.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" yes;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture7";
createNode PxrDispScalarLayer -n "PxrDispScalarLayer2";
	rename -uid "DA776579-4868-9427-E56D-A59EB9DA84A0";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".overallAmount" 1;
	setAttr ".baseLayerEnabled" yes;
	setAttr ".baseLayerAmount" 1;
	setAttr ".baseLayerDispScalar" 0;
	setAttr ".layer1Enabled" yes;
	setAttr ".layer1Amount" 1;
	setAttr ".layer1DispScalar" 0;
	setAttr ".layer1Mask" 1;
	setAttr ".layer1Comp" 1;
	setAttr ".layer2Enabled" no;
	setAttr ".layer2Amount" 1;
	setAttr ".layer2DispScalar" 0;
	setAttr ".layer2Mask" 1;
	setAttr ".layer2Comp" 1;
	setAttr ".layer3Enabled" no;
	setAttr ".layer3Amount" 1;
	setAttr ".layer3DispScalar" 0;
	setAttr ".layer3Mask" 1;
	setAttr ".layer3Comp" 1;
	setAttr ".layer4Enabled" no;
	setAttr ".layer4Amount" 1;
	setAttr ".layer4DispScalar" 0;
	setAttr ".layer4Mask" 1;
	setAttr ".layer4Comp" 1;
createNode PxrToFloat -n "PxrToFloat3";
	rename -uid "F1D0920D-4B52-D82C-B2AD-099ACB7A59EB";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".input" -type "float3" 0 0 0 ;
	setAttr ".mode" 0;
createNode PxrDisplace -n "PxrDisplace2";
	rename -uid "E777145B-4042-CEDD-2D9F-2B9E48261B7C";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".enabled" yes;
	setAttr ".dispAmount" 0.10000000149011612;
	setAttr ".dispScalar" 0;
	setAttr ".dispVector" -type "float3" 0 0 0 ;
	setAttr ".modelDispVector" -type "float3" 0 0 0 ;
createNode PxrUnified -s -n "PxrUnified";
	rename -uid "C51331A9-40E1-4187-3BBE-45A4D07B7785";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".traceLightPaths" 1;
	setAttr ".maxIndirectBounces" 8;
	setAttr ".maxNonStochasticOpacityEvents" 0;
	setAttr ".useTraceDepth" no;
	setAttr ".maxRayDistance" 10000;
	setAttr ".catchAllLights" 0;
	setAttr ".emissionMultiplier" 1;
	setAttr ".accumOpacity" yes;
	setAttr ".numLightSamples" 1;
	setAttr ".numBxdfSamples" 1;
	setAttr ".numVolumeAggregateSamples" 1;
	setAttr ".numIndirectSamples" 1;
	setAttr ".sssOversampling" 8;
	setAttr ".allowMultilobeIndirect" 0;
	setAttr ".risPathGuiding" no;
	setAttr ".rouletteDepth" 1;
	setAttr ".rouletteLightDepth" 1;
	setAttr ".rouletteThreshold" 0.20000000298023224;
	setAttr ".directClamp" 1000000;
	setAttr ".indirectClamp" 8;
	setAttr ".causticClamp" 1000000;
	setAttr ".manifoldWalk" no;
	setAttr ".maxIterations" 10;
	setAttr ".maxInterfaces" 2;
	setAttr ".walkThreshold" 0.004999999888241291;
	setAttr ".enableVolumeCaustics" no;
	setAttr ".photonEstimationRadius" 0;
	setAttr ".photonEstimationNumber" 64;
	setAttr ".photonVisibilityRod" no;
	setAttr ".photonVisibilityRodDirectProb" 0;
	setAttr ".photonVisibilityRodMin" -type "float3" 0 0 0 ;
	setAttr ".photonVisibilityRodMax" -type "float3" 0 0 0 ;
	setAttr ".photonAdaptive" no;
	setAttr ".indirectTrainingSamples" 0;
	setAttr ".indirectSpatialBlurRadius" 0.25;
	setAttr ".indirectDirectionalBlurRadius" 0;
	setAttr ".indirectOversampling" 2;
	setAttr ".suppressNaNs" 0;
	setAttr ".enableShadingTimers" no;
	setAttr ".enableSampleTimers" no;
createNode PxrVCM -s -n "PxrVCM";
	rename -uid "5FED7138-49A1-74C7-C28D-E28DE8391862";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".connectPaths" yes;
	setAttr ".mergePaths" yes;
	setAttr ".numLightSamples" 1;
	setAttr ".numBxdfSamples" 1;
	setAttr ".maxIndirectBounces" 8;
	setAttr ".rouletteDepth" 4;
	setAttr ".rouletteThreshold" 0.20000000298023224;
	setAttr ".clampDepth" 2;
	setAttr ".clampLuminance" 10;
	setAttr ".mergeRadius" 5;
	setAttr ".timeRadius" 1;
	setAttr ".photonGuiding" 0;
	setAttr ".photonGuidingBBoxMin" -type "float3" 1e+30 1e+30 1e+30 ;
	setAttr ".photonGuidingBBoxMax" -type "float3" -1e+30 -1e+30 -1e+30 ;
createNode nodeGraphEditorInfo -n "MayaNodeEditorSavedTabsInfo";
	rename -uid "BCF38CB0-4A6B-67B4-7DF2-F5965EBF235C";
	setAttr ".tgi[0].tn" -type "string" "Untitled_1";
	setAttr ".tgi[0].vl" -type "double2" -523.80950299520418 -248.23917394167952 ;
	setAttr ".tgi[0].vh" -type "double2" 513.09521770666595 273.23917294826884 ;
	setAttr -s 7 ".tgi[0].ni";
	setAttr ".tgi[0].ni[0].x" 204.28572082519531;
	setAttr ".tgi[0].ni[0].y" 104.28571319580078;
	setAttr ".tgi[0].ni[0].nvs" 18304;
	setAttr ".tgi[0].ni[1].x" 204.28572082519531;
	setAttr ".tgi[0].ni[1].y" -77.142860412597656;
	setAttr ".tgi[0].ni[1].nvs" 18304;
	setAttr ".tgi[0].ni[2].x" -102.85713958740234;
	setAttr ".tgi[0].ni[2].y" 52.857143402099609;
	setAttr ".tgi[0].ni[2].nvs" 18304;
	setAttr ".tgi[0].ni[3].x" -410;
	setAttr ".tgi[0].ni[3].y" 52.857143402099609;
	setAttr ".tgi[0].ni[3].nvs" 18304;
	setAttr ".tgi[0].ni[4].x" -102.85713958740234;
	setAttr ".tgi[0].ni[4].y" 154.28572082519531;
	setAttr ".tgi[0].ni[4].nvs" 18304;
	setAttr ".tgi[0].ni[5].x" -254.28572082519531;
	setAttr ".tgi[0].ni[5].y" -100;
	setAttr ".tgi[0].ni[5].nvs" 18304;
	setAttr ".tgi[0].ni[6].x" -98.571426391601562;
	setAttr ".tgi[0].ni[6].y" 248.57142639160156;
	setAttr ".tgi[0].ni[6].nvs" 18304;
createNode PxrVisualizer -s -n "PxrVisualizer";
	rename -uid "1E9AF991-4F29-3FC7-CFCF-7BA6BF1A0C74";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".style" -type "string" "shaded";
	setAttr ".wireframe" yes;
	setAttr ".normalCheck" no;
	setAttr ".normalMap" no;
	setAttr ".shadedPrimVar" -type "string" "displayColor";
	setAttr ".matCap" -type "string" "";
	setAttr ".wireframeColor" -type "float3" 0 0 0 ;
	setAttr ".wireframeOpacity" 0.5;
	setAttr ".wireframeWidth" 1;
createNode PxrDirectLighting -s -n "PxrDirectLighting";
	rename -uid "A4685E4F-4E91-F67C-3367-1CB6D8DFD2F9";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".numLightSamples" 4;
	setAttr ".numBxdfSamples" 4;
createNode PxrDefault -s -n "PxrDefault";
	rename -uid "95FC18CE-4C1B-01D0-F4A7-D18B2B2B3805";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
createNode PxrOcclusion -s -n "PxrOcclusion";
	rename -uid "C670A98E-41B5-D560-F29F-278A155C243D";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".numSamples" 4;
	setAttr ".distribution" 1;
	setAttr ".cosineSpread" 1;
	setAttr ".falloff" 0;
	setAttr ".maxDistance" 0;
	setAttr ".useAlbedo" no;
createNode groupId -n "groupId18";
	rename -uid "1FCA4BA3-4469-06DF-593C-BDB54ECB40F3";
	setAttr ".ihi" 0;
createNode polyMapSew -n "polyMapSew5";
	rename -uid "54E14F81-41A2-4883-FC31-3491D2628D44";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:19]";
createNode polyTweakUV -n "polyTweakUV13";
	rename -uid "A6CD222E-4791-BA45-F835-58BB7DEEE910";
	setAttr ".uopa" yes;
	setAttr -s 16 ".uvtk[0:15]" -type "float2" 0.30000001 -0.2375 0.23750001
		 -0.2375 0.23750001 -0.2375 0.30000001 -0.2375 0.42500001 -0.2375 0.42500001 -0.2375
		 0.23750001 -0.175 0.23750001 -0.049999997 0.23750001 -0.049999997 0.23750001 -0.175
		 -0.038918853 0.44673446 -1.1044662 0.41766924 -1.099673986 -0.47557652 -0.034126639
		 -0.44651121 1.065052986 0.47777456 1.0698452 -0.41547114;
createNode polyPlanarProj -n "polyPlanarProj2";
	rename -uid "593311D2-40BE-FC42-D79F-CE8A0FBC2740";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:3]";
	setAttr ".ix" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1;
	setAttr ".ws" yes;
	setAttr ".pc" -type "double3" 3.1443793773651123 5.2200379371643066 -2.3943793773651123 ;
	setAttr ".ro" -type "double3" 0 -45.000000000000007 0 ;
	setAttr ".ps" -type "double2" 27.024446311631241 27.024446311631241 ;
	setAttr ".cam" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1;
createNode polyLayoutUV -n "polyLayoutUV10";
	rename -uid "0803EFCB-4932-741F-911C-4F822B9A5BFD";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:3]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyPlanarProj -n "polyPlanarProj3";
	rename -uid "081B1206-439E-989D-5284-1BAE80BF8B1A";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[4:5]";
	setAttr ".ix" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1;
	setAttr ".ws" yes;
	setAttr ".pc" -type "double3" 0.038758739829063416 2.2133579254150391 0.46124112606048584 ;
	setAttr ".ro" -type "double3" 0 -45.000000000000007 0 ;
	setAttr ".ps" -type "double2" 21.521985577715725 21.521985577715725 ;
	setAttr ".cam" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1;
createNode polyLayoutUV -n "polyLayoutUV11";
	rename -uid "3A6D480B-4EC3-AD91-D559-98966D1A6C01";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[4:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyLayoutUV -n "polyLayoutUV12";
	rename -uid "92DD4D9D-45A6-45AB-F3BC-50AF41C43938";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyLayoutUV -n "polyLayoutUV13";
	rename -uid "B7004098-40E1-448F-ED82-14930D3BE225";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyLayoutUV -n "polyLayoutUV14";
	rename -uid "685D9A35-458A-9D00-EEC0-27BB6938206D";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyLayoutUV -n "polyLayoutUV15";
	rename -uid "C30296A5-4A26-895E-6BE8-288F010C62AD";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV14";
	rename -uid "CC0D7976-419C-5E2B-CB6C-FDABF336ADDD";
	setAttr ".uopa" yes;
	setAttr -s 16 ".uvtk[0:15]" -type "float2" -0.02194196 -0.44363925 -0.0015566051
		 -0.44907111 0.0015566349 -0.4631092 -0.01882872 -0.45767736 -0.094400659 -0.42433205
		 -0.091287434 -0.43837017 0.016367257 -0.45384705 0.093748927 -0.47446603 0.096862197
		 -0.48850414 0.019480467 -0.46788517 -0.099799544 -0.38582009 -0.074189365 -0.38204724
		 -0.074811414 -0.3447994 -0.10042158 -0.34857222 -0.12714964 -0.38984919 -0.12777168
		 -0.35260135;
createNode polyLayoutUV -n "polyLayoutUV16";
	rename -uid "056A5FDF-4349-68C7-AC52-DD92AC2E549A";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:5]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV15";
	rename -uid "35650A41-4A0A-DB22-5D33-E298E79EB66B";
	setAttr ".uopa" yes;
	setAttr -s 16 ".uvtk[0:15]" -type "float2" 0.020499915 -0.0069787889
		 -8.9406967e-08 -0.0069790836 5.9604645e-08 -0.018728517 0.020500094 -0.018728219
		 0.093366124 -0.0069777332 0.093366295 -0.018727165 -0.018024743 -0.0069793472 -0.095841646
		 -0.0069804732 -0.095841467 -0.018729903 -0.018024564 -0.018728778 0.0016548038 -0.044793814
		 0.074521013 -0.04480727 0.074523233 -0.032793313 0.0016570389 -0.032779858 -0.0761621
		 -0.04477945 -0.076159894 -0.032765489;
createNode polyMapCut -n "polyMapCut6";
	rename -uid "DCAA7EEA-45E8-32AE-7582-128E2B31CFDB";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "e[4]" "e[16]";
createNode polyTweakUV -n "polyTweakUV16";
	rename -uid "3AF88C45-413B-B792-B57E-0592F38AA0A7";
	setAttr ".uopa" yes;
	setAttr -s 20 ".uvtk[0:19]" -type "float2" 0.37516549 0.12259757 0.48071352
		 0.12259912 -0.49345824 0.060486905 0.37516466 0.18309164 8.7260025e-07 0.1225921
		 0 0.18308617 -0.4006542 -5.8109663e-06 0 -2.933848e-08 -1.013279e-06 0.060494035
		 -0.40065506 0.060488269 -0.1983805 0.24501461 0.23798762 0.37028703 0.23797619 0.30843103
		 0.61314082 0.3083618 0.20227361 0.24494091 0.20226222 0.18308489 0.61315227 0.37021783
		 -0.19839194 0.18315858 -0.49345738 -7.1357936e-06 0.48071262 0.18309316;
createNode polyMapSew -n "polyMapSew6";
	rename -uid "2CB63FBA-494A-E822-00E2-C395E3740091";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:95]";
createNode groupId -n "groupId21";
	rename -uid "103BE725-4212-9561-FBD0-F1A86B88A931";
	setAttr ".ihi" 0;
createNode polyPlanarProj -n "polyPlanarProj4";
	rename -uid "E8BE9015-4D87-CFD8-471D-50B563EE0BA0";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:40]";
	setAttr ".ix" -type "matrix" 8.5633105719475875 0 0 0 0 4.1700690031886314 0 0 0 0 8.5633105719475875 0
		 7.7183448352336885 3.0850344991536689 -6.7183448352336885 1;
	setAttr ".ws" yes;
	setAttr ".pc" -type "double3" 3.0109846591949463 5.2072286605834961 -2.9664092063903809 ;
	setAttr ".ro" -type "double3" -15.697975582884251 -35.918690982188252 -3.84701408605031e-07 ;
	setAttr ".ps" -type "double2" 32.119196304735951 32.119196304735951 ;
	setAttr ".cam" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1;
createNode polyTweakUV -n "polyTweakUV17";
	rename -uid "94D66D8B-41DD-9835-D07F-F6A4C6C884A9";
	setAttr ".uopa" yes;
createNode polyTweakUV -n "polyTweakUV18";
	rename -uid "34B0E306-4FE2-DC69-D806-EB8122360D81";
	setAttr ".uopa" yes;
	setAttr -s 57 ".uvtk[0:56]" -type "float2" -0.012414157 0.093210608
		 -0.10635442 0.1432727 -0.0683617 0.10069239 -0.0011157393 0.053024471 0.11267345
		 0.066049755 0.032666683 0.087787688 0.17049849 0.1034534 -0.036476254 0.1212737 0.055684507
		 0.15825522 0.035035908 0.13233668 0.082380414 0.17890722 0.12764031 0.19764131 0.16600686
		 0.23753691 0.21980919 0.27963537 0.024193943 0.113563 -0.040250778 0.039095402 -0.096044898
		 0.074340701 -0.029173136 0.15218753 -0.0083562136 0.16764295 0.027884543 0.1911642
		 -0.00023525953 0.19298518 0.036282778 0.21574289 -0.022048652 0.17861962 -0.085707784
		 0.094138622 -0.044406593 0.044084191 0.2095512 0.29230338 0.16087194 0.24263728 0.11398499
		 0.069134951 -0.0011640787 0.055114925 0.00032782555 0.060009897 0.11210136 0.073576838
		 -0.01378721 0.096313298 -0.010522425 0.10037979 0.014761269 0.11756086 -0.040685356
		 0.048423409 0.021879196 0.12161469 0.028953195 0.13401973 0.03103435 0.1387465 0.05253008
		 0.1595794 0.049639225 0.16459233 0.16043501 0.24565673 0.1114427 0.066411614 -8.058548e-05
		 0.053366899 0.1111472 0.068450779 0.0003542304 0.055301905 -0.038198233 0.042367697
		 -0.038410962 0.039905131 0.026150286 0.11367136 0.026022375 0.11584663 -0.0095203519
		 0.095243424 0.033695638 0.1342985 0.051044822 0.1599983 0.16238686 0.24000376 -0.010210514
		 0.093311787 0.16374339 0.23783243 0.034569085 0.13247442 0.052618772 0.15816545;
createNode polyMapCut -n "polyMapCut7";
	rename -uid "F6D35014-4841-D7D1-0AB6-A6A3457B6858";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "e[29]" "e[32]";
createNode polyTweakUV -n "polyTweakUV19";
	rename -uid "FCB61E77-4D3B-0DB2-89F8-7EA619A29A5A";
	setAttr ".uopa" yes;
	setAttr -s 38 ".uvtk";
	setAttr ".uvtk[8]" -type "float2" -0.012868017 -0.0097029805 ;
	setAttr ".uvtk[9]" -type "float2" -0.01341629 -0.0069280863 ;
	setAttr ".uvtk[10]" -type "float2" -0.015465558 -0.0080240965 ;
	setAttr ".uvtk[11]" -type "float2" -0.015105426 -0.0099980235 ;
	setAttr ".uvtk[12]" -type "float2" -0.010966167 -0.019001245 ;
	setAttr ".uvtk[13]" -type "float2" -0.01328747 -0.019979 ;
	setAttr ".uvtk[14]" -type "float2" -0.01246053 -0.0047677159 ;
	setAttr ".uvtk[15]" -type "float2" -0.022048116 -0.00045645237 ;
	setAttr ".uvtk[16]" -type "float2" -0.012639999 -0.012145936 ;
	setAttr ".uvtk[17]" -type "float2" -0.014198661 -0.0029797554 ;
	setAttr ".uvtk[18]" -type "float2" -0.015552938 -0.0052992105 ;
	setAttr ".uvtk[19]" -type "float2" -0.0167045 -0.0065771341 ;
	setAttr ".uvtk[20]" -type "float2" -0.015839219 -0.0051241517 ;
	setAttr ".uvtk[21]" -type "float2" -0.01695478 -0.0063949823 ;
	setAttr ".uvtk[22]" -type "float2" -0.014938056 -0.0027779937 ;
	setAttr ".uvtk[23]" -type "float2" -0.018656373 -0.025209486 ;
	setAttr ".uvtk[24]" -type "float2" -0.022788703 -0.00023466349 ;
	setAttr ".uvtk[25]" -type "float2" -0.01302065 -0.020311534 ;
	setAttr ".uvtk[26]" -type "float2" -0.010464489 -0.019084692 ;
	setAttr ".uvtk[33]" -type "float2" -0.011673391 -0.0051476359 ;
	setAttr ".uvtk[34]" -type "float2" -0.022642553 -0.00019866228 ;
	setAttr ".uvtk[35]" -type "float2" -0.011864483 -0.0050557852 ;
	setAttr ".uvtk[36]" -type "float2" -0.012794077 -0.0070356727 ;
	setAttr ".uvtk[37]" -type "float2" -0.012890637 -0.0070296526 ;
	setAttr ".uvtk[38]" -type "float2" -0.012273669 -0.0096850395 ;
	setAttr ".uvtk[39]" -type "float2" -0.012405545 -0.0096871257 ;
	setAttr ".uvtk[40]" -type "float2" -0.010549054 -0.018982351 ;
	setAttr ".uvtk[45]" -type "float2" -0.022387445 -0.000233531 ;
	setAttr ".uvtk[46]" -type "float2" -0.022199512 -0.00033253431 ;
	setAttr ".uvtk[47]" -type "float2" -0.012341738 -0.004820466 ;
	setAttr ".uvtk[48]" -type "float2" -0.012215972 -0.0048776269 ;
	setAttr ".uvtk[50]" -type "float2" -0.013167858 -0.0069884658 ;
	setAttr ".uvtk[51]" -type "float2" -0.012665391 -0.0096942782 ;
	setAttr ".uvtk[52]" -type "float2" -0.010782793 -0.018960118 ;
	setAttr ".uvtk[54]" -type "float2" -0.010871857 -0.018968999 ;
	setAttr ".uvtk[55]" -type "float2" -0.013288736 -0.0069612861 ;
	setAttr ".uvtk[56]" -type "float2" -0.0127666 -0.0096982718 ;
	setAttr ".uvtk[57]" -type "float2" -0.01689297 -0.0049834847 ;
createNode polyMapCut -n "polyMapCut8";
	rename -uid "F67D64C4-4440-F0D7-F5CB-D28A982152B2";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[58]" "e[61]" "e[80]";
createNode polyMapCut -n "polyMapCut9";
	rename -uid "E025A400-484D-C7EE-1EC8-6E9F2C6B10CA";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[71]" "e[73]" "e[82]";
createNode polyMapCut -n "polyMapCut10";
	rename -uid "86668BB0-4E1B-C5A6-D2D2-2CBA38A358AC";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[15]" "e[18]" "e[20]";
createNode polyMapCut -n "polyMapCut11";
	rename -uid "5D92E3D0-4CEA-DEFC-26CF-CAB0B31B966D";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 4 "e[6]" "e[10]" "e[12:14]" "e[17]";
createNode polyTweakUV -n "polyTweakUV20";
	rename -uid "9FE7BEBD-41D4-FFDB-DE9A-F88586719444";
	setAttr ".uopa" yes;
	setAttr -s 12 ".uvtk";
	setAttr ".uvtk[10]" -type "float2" 0.088304043 0.025215924 ;
	setAttr ".uvtk[11]" -type "float2" 0.072541416 0.029825985 ;
	setAttr ".uvtk[13]" -type "float2" 0.084681034 0.033772469 ;
	setAttr ".uvtk[62]" -type "float2" 0.081975281 -0.028324604 ;
	setAttr ".uvtk[63]" -type "float2" 0.1141814 -0.0098583698 ;
	setAttr ".uvtk[64]" -type "float2" 0.034142733 -0.055897892 ;
	setAttr ".uvtk[66]" -type "float2" 0.0088950396 0.0058848262 ;
	setAttr ".uvtk[67]" -type "float2" 0.06630379 0.029980898 ;
	setAttr ".uvtk[69]" -type "float2" -0.20760298 -0.099711448 ;
	setAttr ".uvtk[70]" -type "float2" -0.19107437 -0.14463764 ;
	setAttr ".uvtk[71]" -type "float2" 0.068866625 0.034183621 ;
	setAttr ".uvtk[73]" -type "float2" 0.074964315 0.028207481 ;
createNode polyLayoutUV -n "polyLayoutUV17";
	rename -uid "E7F23264-4C20-A90B-5651-EFBF9F3F08F9";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[3:7]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV21";
	rename -uid "925BF36D-4D67-E5A6-AC05-45A6BB929E37";
	setAttr ".uopa" yes;
	setAttr -s 12 ".uvtk";
	setAttr ".uvtk[10]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[11]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[13]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[62]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[63]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[64]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[66]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[67]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[69]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[70]" -type "float2" 0.28621951 0.15848517 ;
	setAttr ".uvtk[71]" -type "float2" 0.28621948 0.15848517 ;
	setAttr ".uvtk[73]" -type "float2" 0.28621951 0.15848517 ;
createNode polyMapCut -n "polyMapCut12";
	rename -uid "E243F7BA-4964-76EF-2D9D-34BA30C653AC";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 8 "e[45:46]" "e[48]" "e[50]" "e[52:53]" "e[65]" "e[69]" "e[77]" "e[79]";
createNode polyMapSew -n "polyMapSew7";
	rename -uid "0162BB0F-4745-9689-481C-70B63245CCA5";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[71]" "e[73]" "e[82]";
createNode polyMapCut -n "polyMapCut13";
	rename -uid "3EDFF233-4883-E645-C1BD-F385FEA3DF1A";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[71]" "e[73]" "e[82]";
createNode polyTweakUV -n "polyTweakUV22";
	rename -uid "8603E41F-4166-ED31-567B-A2960CAE3A78";
	setAttr ".uopa" yes;
	setAttr -s 24 ".uvtk";
	setAttr ".uvtk[8]" -type "float2" 0.063755304 0.00045400858 ;
	setAttr ".uvtk[9]" -type "float2" 0.10105222 0.0015969872 ;
	setAttr ".uvtk[14]" -type "float2" -0.005789578 -0.0035318732 ;
	setAttr ".uvtk[15]" -type "float2" 0.0064482689 0.010550976 ;
	setAttr ".uvtk[35]" -type "float2" -0.0062955022 -0.0025491714 ;
	setAttr ".uvtk[37]" -type "float2" -0.00089740753 -0.0054322481 ;
	setAttr ".uvtk[39]" -type "float2" 0.065425605 -0.0071069598 ;
	setAttr ".uvtk[40]" -type "float2" -0.10445422 -0.00067573786 ;
	setAttr ".uvtk[45]" -type "float2" 0.0065971613 0.00965029 ;
	setAttr ".uvtk[47]" -type "float2" -0.0058893561 -0.0033268929 ;
	setAttr ".uvtk[48]" -type "float2" -0.0060005784 -0.0031109452 ;
	setAttr ".uvtk[50]" -type "float2" 0.097600162 -0.00079250336 ;
	setAttr ".uvtk[51]" -type "float2" 0.064425945 -0.0028483868 ;
	setAttr ".uvtk[52]" -type "float2" -0.10602622 0.0046126246 ;
	setAttr ".uvtk[54]" -type "float2" -0.10616706 0.0066091418 ;
	setAttr ".uvtk[55]" -type "float2" 0.09820205 0.00050956011 ;
	setAttr ".uvtk[56]" -type "float2" 0.064079851 -0.0011951327 ;
	setAttr ".uvtk[71]" -type "float2" -0.10569648 0.0086711645 ;
	setAttr ".uvtk[74]" -type "float2" 0.0067353845 0.0098778009 ;
	setAttr ".uvtk[81]" -type "float2" 0.0052527785 0.009711504 ;
	setAttr ".uvtk[82]" -type "float2" 0.00080513954 -0.0071772337 ;
	setAttr ".uvtk[83]" -type "float2" 0.099838197 -0.0048568249 ;
	setAttr ".uvtk[84]" -type "float2" -0.0013625622 -0.0071568489 ;
	setAttr ".uvtk[85]" -type "float2" 0.00039625168 -0.0075054169 ;
createNode polyLayoutUV -n "polyLayoutUV18";
	rename -uid "4028BBCF-4BEB-9889-3ABA-7AB8400BB142";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[27:28]" "f[37:40]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV23";
	rename -uid "CBE13D04-49DC-8E88-0504-9797E9EEF93A";
	setAttr ".uopa" yes;
	setAttr -s 24 ".uvtk";
	setAttr ".uvtk[8]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[9]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[14]" -type "float2" 0.086916327 0.040410995 ;
	setAttr ".uvtk[15]" -type "float2" -0.13120306 -0.074444413 ;
	setAttr ".uvtk[35]" -type "float2" 0.081805229 0.050117314 ;
	setAttr ".uvtk[37]" -type "float2" 0.12955272 0.075259805 ;
	setAttr ".uvtk[39]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[40]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[45]" -type "float2" -0.13343996 -0.07019645 ;
	setAttr ".uvtk[47]" -type "float2" 0.085797846 0.042535126 ;
	setAttr ".uvtk[48]" -type "float2" 0.084679365 0.044659019 ;
	setAttr ".uvtk[50]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[51]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[52]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[54]" -type "float2" 0.21762143 0.17267789 ;
	setAttr ".uvtk[55]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[56]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[71]" -type "float2" 0.21762146 0.17267789 ;
	setAttr ".uvtk[74]" -type "float2" -0.13232154 -0.072320372 ;
	setAttr ".uvtk[81]" -type "float2" -0.13631409 -0.064738095 ;
	setAttr ".uvtk[82]" -type "float2" 0.13242692 0.069801509 ;
	setAttr ".uvtk[83]" -type "float2" 0.21762145 0.17267789 ;
	setAttr ".uvtk[84]" -type "float2" 0.13743901 0.067014813 ;
	setAttr ".uvtk[85]" -type "float2" 0.13435811 0.068105519 ;
createNode polyLayoutUV -n "polyLayoutUV19";
	rename -uid "D08D5EA0-49C7-D038-B437-929F59D37DCE";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "f[21:22]" "f[25:26]" "f[35:36]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV24";
	rename -uid "DC6751B4-4DAC-C330-1449-D0B5CBD5A6CA";
	setAttr ".uopa" yes;
	setAttr -s 24 ".uvtk";
	setAttr ".uvtk[8]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[9]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[14]" -type "float2" 0.2051134 0.094635189 ;
	setAttr ".uvtk[15]" -type "float2" 0.2051134 0.094635248 ;
	setAttr ".uvtk[35]" -type "float2" 0.2051134 0.094635189 ;
	setAttr ".uvtk[37]" -type "float2" 0.20511346 0.094635189 ;
	setAttr ".uvtk[39]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[40]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[45]" -type "float2" 0.2051134 0.094635248 ;
	setAttr ".uvtk[47]" -type "float2" 0.20511346 0.094635189 ;
	setAttr ".uvtk[48]" -type "float2" 0.20511346 0.094635189 ;
	setAttr ".uvtk[50]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[51]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[52]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[54]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[55]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[56]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[71]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[74]" -type "float2" 0.2051134 0.094635189 ;
	setAttr ".uvtk[81]" -type "float2" 0.20511346 0.094635248 ;
	setAttr ".uvtk[82]" -type "float2" 0.20511346 0.094635189 ;
	setAttr ".uvtk[83]" -type "float2" 0.0060752197 0.0060752309 ;
	setAttr ".uvtk[84]" -type "float2" 0.2051134 0.094635189 ;
	setAttr ".uvtk[85]" -type "float2" 0.20511346 0.094635189 ;
createNode polyMapCut -n "polyMapCut14";
	rename -uid "756E51B3-45F8-C0B0-052B-6EA595509B17";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "e[1]" "e[3]";
createNode polyMapCut -n "polyMapCut15";
	rename -uid "53771F11-425B-514F-54F1-049E3767527D";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 3 "e[55]" "e[62]" "e[64]";
createNode polyMapCut -n "polyMapCut16";
	rename -uid "F53926CC-40FD-B5A5-7A6C-DABC0DABDAF8";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 5 "e[40]" "e[42]" "e[54]" "e[56]" "e[59]";
createNode polyTweakUV -n "polyTweakUV25";
	rename -uid "C182C3B5-451A-D4BA-2DE3-8EBFECE119E7";
	setAttr ".uopa" yes;
	setAttr -s 24 ".uvtk";
	setAttr ".uvtk[1]" -type "float2" -0.16761571 -0.22272617 ;
	setAttr ".uvtk[2]" -type "float2" 0.081151545 -0.01599133 ;
	setAttr ".uvtk[3]" -type "float2" 0.0017302632 -0.0019626617 ;
	setAttr ".uvtk[4]" -type "float2" 0.050015822 0.11145747 ;
	setAttr ".uvtk[5]" -type "float2" 0.079457939 0.055313408 ;
	setAttr ".uvtk[6]" -type "float2" 0.058612972 0.11207694 ;
	setAttr ".uvtk[7]" -type "float2" 0.11568815 0.0014503002 ;
	setAttr ".uvtk[29]" -type "float2" -0.0007622838 -0.0038750768 ;
	setAttr ".uvtk[30]" -type "float2" -0.00026556849 0.0017544925 ;
	setAttr ".uvtk[42]" -type "float2" 0.00028908253 -0.0042624474 ;
	setAttr ".uvtk[43]" -type "float2" -0.00084424019 0.0018452108 ;
	setAttr ".uvtk[44]" -type "float2" -0.00071424246 -0.0020324588 ;
	setAttr ".uvtk[53]" -type "float2" 0.00055009127 0.0041036308 ;
	setAttr ".uvtk[58]" -type "float2" 0.00072443485 -0.004186511 ;
	setAttr ".uvtk[59]" -type "float2" -0.00023287535 -0.0021115541 ;
	setAttr ".uvtk[86]" -type "float2" -0.228643 -0.15228692 ;
	setAttr ".uvtk[87]" -type "float2" 0.046818256 0.05205363 ;
	setAttr ".uvtk[88]" -type "float2" -0.0015824437 -0.0041143298 ;
	setAttr ".uvtk[89]" -type "float2" 0.00012843311 0.0022731423 ;
	setAttr ".uvtk[90]" -type "float2" 0.0007673502 0.0040012598 ;
	setAttr ".uvtk[92]" -type "float2" -0.00024247169 0.0044490397 ;
	setAttr ".uvtk[93]" -type "float2" -0.00064682961 0.0019389391 ;
	setAttr ".uvtk[98]" -type "float2" 0.00084501505 -0.0017051101 ;
	setAttr ".uvtk[99]" -type "float2" 0.00025624037 0.0038843751 ;
createNode polyLayoutUV -n "polyLayoutUV20";
	rename -uid "7D5FF060-48F2-85A5-A0CD-34AB608FCC29";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:2]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV26";
	rename -uid "4E12FB75-4578-B6C8-E4D3-D7900049862A";
	setAttr ".uopa" yes;
	setAttr -s 16 ".uvtk";
	setAttr ".uvtk[1]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[2]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[3]" -type "float2" 0.004029572 -0.024164796 ;
	setAttr ".uvtk[4]" -type "float2" -0.21268643 -0.22248121 ;
	setAttr ".uvtk[5]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[6]" -type "float2" -0.21268643 -0.22248121 ;
	setAttr ".uvtk[7]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[30]" -type "float2" -0.0040745735 0.023675174 ;
	setAttr ".uvtk[43]" -type "float2" -0.002744928 0.023834705 ;
	setAttr ".uvtk[44]" -type "float2" 0.0029503107 -0.023631066 ;
	setAttr ".uvtk[59]" -type "float2" 0.0034736991 -0.023762524 ;
	setAttr ".uvtk[86]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[87]" -type "float2" -0.21268645 -0.22248121 ;
	setAttr ".uvtk[89]" -type "float2" -0.0017440915 0.023954779 ;
	setAttr ".uvtk[93]" -type "float2" -0.0022445321 0.023894727 ;
	setAttr ".uvtk[98]" -type "float2" 0.0016206503 -0.023790598 ;
createNode polyLayoutUV -n "polyLayoutUV21";
	rename -uid "1418987F-434D-EFE3-55E3-06A26711A085";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[19:20]" "f[23]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV27";
	rename -uid "A110E19B-4BD8-C2FA-E43F-788CACCEE92E";
	setAttr ".uopa" yes;
	setAttr -s 16 ".uvtk";
	setAttr ".uvtk[3]" -type "float2" -0.20848867 -0.14832082 ;
	setAttr ".uvtk[29]" -type "float2" 0.13012832 0.11705184 ;
	setAttr ".uvtk[30]" -type "float2" -0.20848867 -0.14832082 ;
	setAttr ".uvtk[42]" -type "float2" 0.13915795 0.10808301 ;
	setAttr ".uvtk[43]" -type "float2" -0.20848867 -0.14832082 ;
	setAttr ".uvtk[44]" -type "float2" -0.20848867 -0.14832079 ;
	setAttr ".uvtk[53]" -type "float2" -0.13373208 -0.11463824 ;
	setAttr ".uvtk[58]" -type "float2" 0.13594341 0.10992694 ;
	setAttr ".uvtk[59]" -type "float2" -0.20848867 -0.14832079 ;
	setAttr ".uvtk[88]" -type "float2" 0.1438241 0.10742342 ;
	setAttr ".uvtk[89]" -type "float2" -0.20848867 -0.14832082 ;
	setAttr ".uvtk[90]" -type "float2" -0.13592058 -0.1119568 ;
	setAttr ".uvtk[92]" -type "float2" -0.13154352 -0.11731976 ;
	setAttr ".uvtk[93]" -type "float2" -0.20848867 -0.14832079 ;
	setAttr ".uvtk[98]" -type "float2" -0.20848867 -0.14832079 ;
	setAttr ".uvtk[99]" -type "float2" -0.14173561 -0.10483187 ;
createNode polyLayoutUV -n "polyLayoutUV22";
	rename -uid "C2F4FB81-43E4-9C4C-9607-48B8B16850AA";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 2 "f[24]" "f[33:34]";
	setAttr ".fr" no;
	setAttr ".l" 0;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".sc" 0;
	setAttr ".dl" yes;
	setAttr ".rbf" 3;
	setAttr ".lm" 1;
createNode polyTweakUV -n "polyTweakUV28";
	rename -uid "DDBC71E7-4CD5-67A5-7B31-DA960A2C480C";
	setAttr ".uopa" yes;
	setAttr -s 8 ".uvtk";
	setAttr ".uvtk[29]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[42]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[53]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[58]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[88]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[90]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[92]" -type "float2" -0.31902966 -0.29104459 ;
	setAttr ".uvtk[99]" -type "float2" -0.31902966 -0.29104459 ;
createNode deleteComponent -n "deleteComponent11";
	rename -uid "CD79DAC5-4A5F-C4DE-BEF9-55B4E073AD12";
	setAttr ".dc" -type "componentList" 1 "f[13:14]";
createNode deleteComponent -n "deleteComponent12";
	rename -uid "7AA32800-479E-3834-BA98-66AD0F50A4A1";
	setAttr ".dc" -type "componentList" 1 "f[13:16]";
createNode deleteComponent -n "deleteComponent13";
	rename -uid "5E37A340-4CDC-B19D-A2CC-13A8D182C2A2";
	setAttr ".dc" -type "componentList" 1 "f[23]";
createNode polyTweakUV -n "polyTweakUV29";
	rename -uid "603A4B5F-4FB9-07E2-27D7-B09ED1513828";
	setAttr ".uopa" yes;
	setAttr -s 87 ".uvtk[0:86]" -type "float2" 0.087283567 -0.3963376 0.12425084
		 0.017665172 0.12424602 0.11635122 0.067649655 0.10529286 0.0058406293 0.11634538
		 0.098247126 0.13920847 0.0058395118 0.139204 0.12424488 0.13920978 -0.069583394 -0.026811689
		 -0.092608429 -0.026809245 -0.024262957 0.0024077334 -0.047199778 0.0024493374 0.63227081
		 -0.62720275 -0.12872761 0.0025975145 -0.03430875 -0.046987336 -0.03430118 -0.13880637
		 0.093669116 -0.41691059 0.031781025 -0.7244606 0.013038001 -0.75991821 -0.021331415
		 -0.804483 0.0056134663 -0.75693262 -0.02906929 -0.80074102 0.025805965 -0.7225917
		 0.090927079 -0.41587192 0.088301376 -0.3813473 0.60101581 -0.65630758 0.630463 -0.6225552
		 0.076464474 0.078664027 -0.014082411 0.10132123 0.086487725 -0.38946342 0.08556021
		 -0.3918266 0.086102434 -0.3852663 -0.038394712 -0.046987575 -0.038396381 -0.026887938
		 -0.069582976 -0.022922307 0.012258522 -0.022931069 0.079557002 0.078987889 -0.014082769
		 0.10357971 0.06653937 0.10359273 -0.036089323 -0.13880652 0.081473537 -0.38375351
		 -0.035202879 -0.046987277 -0.036096953 -0.046987396 0.086012013 -0.39337853 -0.091496207
		 -0.025107175 -0.069583215 -0.0251095 0.012258284 -0.025118202 0.079563498 -0.0070714802
		 0.012258194 -0.025969237 -0.091822006 -0.02595821 -0.069583274 -0.025960594 0.088312954
		 -0.53953785 0.07871142 0.078664206 0.066864483 0.10444272 -0.0013627335 -0.017801343
		 -0.0013261363 0.0023658909 -0.00139945 -0.037968576 0.093987018 -0.5410803 -0.024336331
		 -0.037926853 -0.024299674 -0.017759619 -0.024494581 -0.12499383 -0.0015577599 -0.12503555
		 -0.12876427 -0.017569719 0.59746569 -0.65363657 -0.047236495 -0.017717956 0.012258105
		 -0.026820391 0.6331563 -0.62714684 0.63262045 -0.62726003 -0.03519531 -0.13880646
		 0.081826337 -0.38390976 0.082313605 -0.3843289 0.63006842 -0.6264838 -0.038387083
		 -0.1388067 -0.036098622 -0.0268877 -0.091495968 -0.022919983 -0.034310538 -0.02571933
		 -0.035204608 -0.02654551 0.098253027 0.01766392 0.098248199 0.11634991 0.08040265
		 0.079769276 -0.014083037 0.10527963 0.078717887 -0.0070715398 0.08652319 -0.39427114
		 0.080409177 -0.0070714056 -0.014082918 0.10442964 0.066539757 0.10133428 0.076470941
		 -0.0070717037;
createNode PxrSurface -n "mat_seat";
	rename -uid "4BED883E-48C7-78D0-65AA-EF849DE8CBD9";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0 0 0 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.20000000298023224;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 1;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_seat_sg";
	rename -uid "1282322B-4404-48A6-4699-E0B768505F9A";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo13";
	rename -uid "8AE12FDC-4BBA-B04B-BD8F-32A3D28E4AEA";
createNode lambert -n "lambert11";
	rename -uid "EA65BA81-4C0E-5154-CB3F-D1B9F054955A";
createNode PxrTexture -n "seat_diffuse";
	rename -uid "AD7349CE-43C2-115E-7D54-F8A76C052C58";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/seat_diffuse.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" yes;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture8";
createNode PxrSurface -n "mat_seat_vent";
	rename -uid "16DF46C8-4F23-4C35-5674-68B226D3D346";
	addAttr -ci true -h true -sn "aal" -ln "attributeAliasList" -dt "attributeAlias";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".inputMaterial" 0;
	setAttr ".diffuseGain" 1;
	setAttr ".diffuseColor" -type "float3" 0.27222222 0.27222222 0.27222222 ;
	setAttr ".diffuseRoughness" 0;
	setAttr ".diffuseExponent" 1;
	setAttr ".diffuseBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".diffuseDoubleSided" no;
	setAttr ".diffuseBackUseDiffuseColor" yes;
	setAttr ".diffuseBackColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".diffuseTransmitGain" 0;
	setAttr ".diffuseTransmitColor" -type "float3" 0.18000001 0.18000001 0.18000001 ;
	setAttr ".specularFresnelMode" 0;
	setAttr ".specularFaceColor" -type "float3" 0.12222222 0.12222222 0.12222222 ;
	setAttr ".specularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".specularFresnelShape" 5;
	setAttr ".specularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".specularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".specularRoughness" 0.29444444179534912;
	setAttr ".specularModelType" 0;
	setAttr ".specularAnisotropy" 0;
	setAttr ".specularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".specularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".specularDoubleSided" no;
	setAttr ".roughSpecularFresnelMode" 0;
	setAttr ".roughSpecularFaceColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularFresnelShape" 5;
	setAttr ".roughSpecularIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".roughSpecularExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularRoughness" 0.60000002384185791;
	setAttr ".roughSpecularModelType" 0;
	setAttr ".roughSpecularAnisotropy" 0;
	setAttr ".roughSpecularAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".roughSpecularDoubleSided" no;
	setAttr ".clearcoatFresnelMode" 0;
	setAttr ".clearcoatFaceColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatEdgeColor" -type "float3" 0 0 0 ;
	setAttr ".clearcoatFresnelShape" 5;
	setAttr ".clearcoatIor" -type "float3" 1.5 1.5 1.5 ;
	setAttr ".clearcoatExtinctionCoeff" -type "float3" 0 0 0 ;
	setAttr ".clearcoatThickness" 0;
	setAttr ".clearcoatAbsorptionTint" -type "float3" 0 0 0 ;
	setAttr ".clearcoatRoughness" 0;
	setAttr ".clearcoatModelType" 0;
	setAttr ".clearcoatAnisotropy" 0;
	setAttr ".clearcoatAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".clearcoatBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".clearcoatDoubleSided" no;
	setAttr ".specularEnergyCompensation" 1;
	setAttr ".clearcoatEnergyCompensation" 1;
	setAttr ".iridescenceFaceGain" 0;
	setAttr ".iridescenceEdgeGain" 0;
	setAttr ".iridescenceFresnelShape" 5;
	setAttr ".iridescenceMode" 0;
	setAttr ".iridescencePrimaryColor" -type "float3" 1 0 0 ;
	setAttr ".iridescenceSecondaryColor" -type "float3" 0 0 1 ;
	setAttr ".iridescenceRoughness" 0.20000000298023224;
	setAttr ".iridescenceAnisotropy" 0;
	setAttr ".iridescenceAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".iridescenceBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".iridescenceCurve" 1;
	setAttr ".iridescenceScale" 1;
	setAttr ".iridescenceFlip" no;
	setAttr ".iridescenceThickness" 800;
	setAttr ".iridescenceDoubleSided" no;
	setAttr ".fuzzGain" 0;
	setAttr ".fuzzColor" -type "float3" 1 1 1 ;
	setAttr ".fuzzConeAngle" 8;
	setAttr ".fuzzBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".fuzzDoubleSided" no;
	setAttr ".subsurfaceType" 0;
	setAttr ".subsurfaceGain" 0;
	setAttr ".subsurfaceColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".subsurfaceDmfp" 10;
	setAttr ".subsurfaceDmfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".shortSubsurfaceGain" 0;
	setAttr ".shortSubsurfaceColor" -type "float3" 0.89999998 0.89999998 0.89999998 ;
	setAttr ".shortSubsurfaceDmfp" 5;
	setAttr ".longSubsurfaceGain" 0;
	setAttr ".longSubsurfaceColor" -type "float3" 0.80000001 0 0 ;
	setAttr ".longSubsurfaceDmfp" 20;
	setAttr ".subsurfaceDirectionality" 0;
	setAttr ".subsurfaceBleed" 0;
	setAttr ".subsurfaceDiffuseBlend" 0;
	setAttr ".subsurfaceResolveSelfIntersections" no;
	setAttr ".subsurfaceIor" 1.3999999761581421;
	setAttr ".subsurfacePostTint" -type "float3" 1 1 1 ;
	setAttr ".subsurfaceDiffuseSwitch" 1;
	setAttr ".subsurfaceDoubleSided" no;
	setAttr ".subsurfaceTransmitGain" 0;
	setAttr ".considerBackside" yes;
	setAttr ".continuationRayMode" 0;
	setAttr ".maxContinuationHits" 2;
	setAttr ".followTopology" 0;
	setAttr ".subsurfaceSubset" -type "string" "";
	setAttr ".singlescatterGain" 0;
	setAttr ".singlescatterColor" -type "float3" 0.82999998 0.79100001 0.75300002 ;
	setAttr ".singlescatterMfp" 10;
	setAttr ".singlescatterMfpColor" -type "float3" 0.85100001 0.55699998 0.39500001 ;
	setAttr ".singlescatterDirectionality" 0;
	setAttr ".singlescatterIor" 1.2999999523162842;
	setAttr ".singlescatterBlur" 0;
	setAttr ".singlescatterDirectGain" 0;
	setAttr ".singlescatterDirectGainTint" -type "float3" 1 1 1 ;
	setAttr ".singlescatterDoubleSided" no;
	setAttr ".singlescatterConsiderBackside" yes;
	setAttr ".singlescatterContinuationRayMode" 0;
	setAttr ".singlescatterMaxContinuationHits" 2;
	setAttr ".singlescatterDirectGainMode" 0;
	setAttr ".singlescatterSubset" -type "string" "";
	setAttr ".irradianceTint" -type "float3" 1 1 1 ;
	setAttr ".irradianceRoughness" 0;
	setAttr ".unitLength" 0.10000000149011612;
	setAttr ".refractionGain" 0;
	setAttr ".reflectionGain" 0;
	setAttr ".refractionColor" -type "float3" 1 1 1 ;
	setAttr ".glassRoughness" 0.10000000149011612;
	setAttr ".glassRefractionRoughness" -1;
	setAttr ".glassRefraction2Roughness" 0;
	setAttr ".glassRefraction2Blend" 0;
	setAttr ".glassRefraction2Tint" -type "float3" 1 1 1 ;
	setAttr ".glassAnisotropy" 0;
	setAttr ".glassAnisotropyDirection" -type "float3" 0 0 0 ;
	setAttr ".glassBumpNormal" -type "float3" 0 0 0 ;
	setAttr ".glassIor" 1.5;
	setAttr ".mwWalkable" no;
	setAttr ".mwIor" -1;
	setAttr ".thinGlass" no;
	setAttr ".ignoreFresnel" no;
	setAttr ".ignoreAccumOpacity" no;
	setAttr ".blocksVolumes" no;
	setAttr ".volumeAggregate" no;
	setAttr ".volumeAggregateName" -type "string" "interiorVolumeAggregate";
	setAttr ".ssAlbedo" -type "float3" 0 0 0 ;
	setAttr ".extinction" -type "float3" 0 0 0 ;
	setAttr ".g0" 0;
	setAttr ".g1" 0;
	setAttr ".blend" 0;
	setAttr ".volumeGlow" -type "float3" 0 0 0 ;
	setAttr ".maxExtinction" -1;
	setAttr ".multiScatter" no;
	setAttr ".enableOverlappingVolumes" no;
	setAttr ".glowGain" 0;
	setAttr ".glowColor" -type "float3" 1 1 1 ;
	setAttr ".bumpNormal" -type "float3" 0 0 0 ;
	setAttr ".shadowBumpTerminator" yes;
	setAttr ".shadowColor" -type "float3" 0 0 0 ;
	setAttr ".shadowMode" 0;
	setAttr ".presence" 0;
	setAttr ".presenceCached" 1;
	setAttr ".mwStartable" no;
	setAttr ".roughnessMollificationClamp" 32;
	setAttr ".userColor" -type "float3" 0 0 0 ;
	setAttr ".utilityPattern[0]"  0;
	setAttr ".aal" -type "attributeAlias" {"g","g0"} ;
createNode shadingEngine -n "mat_seat_vent_sg";
	rename -uid "C51FFE4B-40C3-CB4F-F587-CCBB01113672";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo14";
	rename -uid "64D91029-4ECD-7F14-F360-6DAFCA5D7FCC";
createNode lambert -n "lambert12";
	rename -uid "97A39A28-45E1-5AAA-A4DC-AF909C2671B4";
createNode PxrTexture -n "seat_vent_mask";
	rename -uid "9312F709-491F-BA4F-27F2-FB9C5D45E26D";
	addAttr -ci true -h true -sn "txm_id" -ln "txm_id" -dt "string";
	setAttr ".cch" no;
	setAttr ".fzn" no;
	setAttr ".ihi" 2;
	setAttr ".nds" 0;
	setAttr ".filename" -type "string" "C:/Users/Calvin/3D Objects/steamroom//sourceimages/seatVent_mask.png";
	setAttr ".firstChannel" 0;
	setAttr ".atlasStyle" 0;
	setAttr ".invertT" yes;
	setAttr ".filter" 1;
	setAttr ".blur" 0;
	setAttr ".missingColor" -type "float3" 1 0 1 ;
	setAttr ".missingAlpha" 1;
	setAttr ".linearize" no;
	setAttr ".colorScale" -type "float3" 1 1 1 ;
	setAttr ".colorOffset" -type "float3" 0 0 0 ;
	setAttr ".saturation" 1;
	setAttr ".alphaScale" 1;
	setAttr ".alphaOffset" 0;
	setAttr ".mipBias" 0;
	setAttr ".maxResolution" 0;
	setAttr ".txm_id" -type "string" "PxrTexture10";
createNode aiOptions -s -n "defaultArnoldRenderOptions";
	rename -uid "80A2ED45-45D7-5C5D-4256-EA828FE6708E";
	setAttr ".version" -type "string" "5.2.1.1";
createNode aiAOVFilter -s -n "defaultArnoldFilter";
	rename -uid "5BCAA7A3-44F9-BE90-44E1-14AC725C829B";
createNode aiAOVDriver -s -n "defaultArnoldDriver";
	rename -uid "F68DA629-45C2-9939-8200-FA94CA80AA93";
createNode aiAOVDriver -s -n "defaultArnoldDisplayDriver";
	rename -uid "B9288092-408C-7AE9-DA8B-C282AFC28F4E";
	setAttr ".output_mode" 0;
	setAttr ".ai_translator" -type "string" "maya";
createNode groupId -n "groupId22";
	rename -uid "97D1D0F3-4E34-A6C6-5EA0-B5AE09580EA2";
	setAttr ".ihi" 0;
createNode groupId -n "groupId23";
	rename -uid "1366186C-4815-F9E1-0F6F-BFB4D3726452";
	setAttr ".ihi" 0;
createNode groupId -n "groupId24";
	rename -uid "233F89D1-4019-07DB-5E5D-8ABFC2954AA1";
	setAttr ".ihi" 0;
createNode groupId -n "groupId25";
	rename -uid "99D0A427-4EF8-8E03-F31E-50AC57A71D9E";
	setAttr ".ihi" 0;
createNode nodeGraphEditorInfo -n "hyperShadePrimaryNodeEditorSavedTabsInfo";
	rename -uid "18BE5E74-45DB-9120-AC0C-2291CAF73730";
	setAttr ".tgi[0].tn" -type "string" "Untitled_1";
	setAttr ".tgi[0].vl" -type "double2" -3035.6829660707212 -1960.4221782350642 ;
	setAttr ".tgi[0].vh" -type "double2" -1669.0268367600227 -1268.5738135216684 ;
	setAttr -s 2 ".tgi[0].ni";
	setAttr ".tgi[0].ni[0].x" -2282.857177734375;
	setAttr ".tgi[0].ni[0].y" -1325.7142333984375;
	setAttr ".tgi[0].ni[0].nvs" 1923;
	setAttr ".tgi[0].ni[1].x" -2617.142822265625;
	setAttr ".tgi[0].ni[1].y" -1325.7142333984375;
	setAttr ".tgi[0].ni[1].nvs" 2227;
select -ne :time1;
	setAttr -av -k on ".cch";
	setAttr -av -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr ".o" 13;
	setAttr -av ".unw" 13;
select -ne :hardwareRenderingGlobals;
	setAttr ".otfna" -type "stringArray" 22 "NURBS Curves" "NURBS Surfaces" "Polygons" "Subdiv Surface" "Particles" "Particle Instance" "Fluids" "Strokes" "Image Planes" "UI" "Lights" "Cameras" "Locators" "Joints" "IK Handles" "Deformers" "Motion Trails" "Components" "Hair Systems" "Follicles" "Misc. UI" "Ornaments"  ;
	setAttr ".otfva" -type "Int32Array" 22 0 1 1 1 1 1
		 1 1 1 0 0 0 0 0 0 0 0 0
		 0 0 0 0 ;
	setAttr ".fprt" yes;
select -ne :renderPartition;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr -s 13 ".st";
	setAttr -cb on ".an";
	setAttr -cb on ".pt";
select -ne :renderGlobalsList1;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -k on ".nds";
	setAttr -cb on ".bnm";
select -ne :defaultShaderList1;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr -s 18 ".s";
select -ne :postProcessList1;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr -s 2 ".p";
select -ne :defaultRenderingList1;
	setAttr -s 14 ".r";
select -ne :lightList1;
	setAttr -s 7 ".l";
select -ne :defaultTextureList1;
	setAttr -s 16 ".tx";
select -ne :initialShadingGroup;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -av -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr -s 2 ".dsm";
	setAttr -k on ".mwc";
	setAttr -cb on ".an";
	setAttr -cb on ".il";
	setAttr -cb on ".vo";
	setAttr -cb on ".eo";
	setAttr -cb on ".fo";
	setAttr -cb on ".epo";
	setAttr ".ro" yes;
select -ne :initialParticleSE;
	setAttr -av -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -av -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr -k on ".mwc";
	setAttr -cb on ".an";
	setAttr -cb on ".il";
	setAttr -cb on ".vo";
	setAttr -cb on ".eo";
	setAttr -cb on ".fo";
	setAttr -cb on ".epo";
	setAttr ".ro" yes;
select -ne :defaultRenderGlobals;
	addAttr -ci true -h true -sn "dss" -ln "defaultSurfaceShader" -dt "string";
	setAttr -k on ".cch";
	setAttr -k on ".nds";
	setAttr -k on ".macc";
	setAttr -k on ".macd";
	setAttr -k on ".macq";
	setAttr -k on ".clip";
	setAttr -k on ".edm";
	setAttr ".ren" -type "string" "renderman";
	setAttr -av -k on ".esr";
	setAttr -k on ".ors";
	setAttr -k on ".gama";
	setAttr -av -k on ".bfs";
	setAttr -k on ".be";
	setAttr -k on ".fec";
	setAttr -k on ".ofc";
	setAttr -k on ".comp";
	setAttr -k on ".cth";
	setAttr -k on ".soll";
	setAttr -k on ".rd";
	setAttr -k on ".lp";
	setAttr -k on ".sp";
	setAttr -k on ".shs";
	setAttr -k on ".lpr";
	setAttr -k on ".mm";
	setAttr -k on ".npu";
	setAttr -k on ".itf";
	setAttr -k on ".shp";
	setAttr -k on ".uf";
	setAttr -k on ".oi";
	setAttr -k on ".rut";
	setAttr -av -k on ".mbf";
	setAttr -k on ".afp";
	setAttr -k on ".pfb";
	setAttr -av -k on ".bll";
	setAttr -k on ".bls";
	setAttr -k on ".smv";
	setAttr -k on ".ubc";
	setAttr -k on ".mbc";
	setAttr -k on ".udbx";
	setAttr -k on ".smc";
	setAttr -k on ".kmv";
	setAttr -k on ".rlen";
	setAttr -av -k on ".frts";
	setAttr -k on ".tlwd";
	setAttr -k on ".tlht";
	setAttr -k on ".jfc";
	setAttr -k on ".ope";
	setAttr -k on ".oppf";
	setAttr ".dss" -type "string" "lambert1";
select -ne :defaultResolution;
	setAttr -av -k on ".cch";
	setAttr -k on ".ihi";
	setAttr -av -k on ".nds";
	setAttr -k on ".bnm";
	setAttr -av ".w" 800;
	setAttr -av ".h" 600;
	setAttr -av ".pa" 1;
	setAttr -av -k on ".al" yes;
	setAttr -av ".dar" 1.3333333730697632;
	setAttr -av -k on ".ldar";
	setAttr -k on ".dpi";
	setAttr -av -k on ".off";
	setAttr -av -k on ".fld";
	setAttr -av -k on ".zsl";
	setAttr -k on ".isu";
	setAttr -k on ".pdu";
select -ne :defaultLightSet;
	setAttr -s 7 ".dsm";
select -ne :defaultColorMgtGlobals;
	setAttr ".cfe" yes;
	setAttr ".cfp" -type "string" "C:/Program Files/Pixar/RenderManProServer-25.2/lib/ocio/ACES-1.2/config.ocio";
	setAttr ".vtn" -type "string" "sRGB (ACES)";
	setAttr ".vn" -type "string" "sRGB";
	setAttr ".dn" -type "string" "ACES";
	setAttr ".wsn" -type "string" "ACES - ACEScg";
	setAttr ".otn" -type "string" "sRGB (ACES)";
	setAttr ".potn" -type "string" "sRGB (ACES)";
select -ne :hardwareRenderGlobals;
	setAttr -k on ".cch";
	setAttr -cb on ".ihi";
	setAttr -k on ".nds";
	setAttr -cb on ".bnm";
	setAttr ".ctrs" 256;
	setAttr -av ".btrs" 512;
	setAttr -k off ".fbfm";
	setAttr -k off -cb on ".ehql";
	setAttr -k off -cb on ".eams";
	setAttr -k off -cb on ".eeaa";
	setAttr -k off -cb on ".engm";
	setAttr -k off -cb on ".mes";
	setAttr -k off -cb on ".emb";
	setAttr -av -k off -cb on ".mbbf";
	setAttr -k off -cb on ".mbs";
	setAttr -k off -cb on ".trm";
	setAttr -k off -cb on ".tshc";
	setAttr -k off ".enpt";
	setAttr -k off -cb on ".clmt";
	setAttr -k off -cb on ".tcov";
	setAttr -k off -cb on ".lith";
	setAttr -k off -cb on ".sobc";
	setAttr -k off -cb on ".cuth";
	setAttr -k off -cb on ".hgcd";
	setAttr -k off -cb on ".hgci";
	setAttr -k off -cb on ".mgcs";
	setAttr -k off -cb on ".twa";
	setAttr -k off -cb on ".twz";
	setAttr -cb on ".hwcc";
	setAttr -cb on ".hwdp";
	setAttr -cb on ".hwql";
	setAttr -k on ".hwfr";
connectAttr "PxrCamera1.msg" "renderShape.rman_cameraProjection";
connectAttr "groupId25.id" "roomShape.iog.og[0].gid";
connectAttr "mat_room_sg.mwc" "roomShape.iog.og[0].gco";
connectAttr "groupId22.id" "room_ventShape.iog.og[0].gid";
connectAttr "mat_metal_sg.mwc" "room_ventShape.iog.og[0].gco";
connectAttr "polyCylinder1.out" "light_fog_1Shape.i";
connectAttr "polyTweakUV5.out" "doorShape.i";
connectAttr "polyTweakUV5.uvtk[0]" "doorShape.uvst[0].uvtw";
connectAttr "groupId24.id" "door_beamsShape.iog.og[0].gid";
connectAttr "mat_metal_sg.mwc" "door_beamsShape.iog.og[0].gco";
connectAttr "groupId23.id" "door_handleShape.iog.og[0].gid";
connectAttr "mat_handle_sg.mwc" "door_handleShape.iog.og[0].gco";
connectAttr "polyMergeVert3.out" "blockerShape.i";
connectAttr "polyTweakUV16.out" "seat_ventShape.i";
connectAttr "polyTweakUV16.uvtk[0]" "seat_ventShape.uvst[0].uvtw";
connectAttr "polyTweakUV29.out" "seat_woodShape.i";
connectAttr "polyTweakUV29.uvtk[0]" "seat_woodShape.uvst[0].uvtw";
connectAttr "groupId18.id" "seat_sideShape.iog.og[0].gid";
connectAttr ":initialShadingGroup.mwc" "seat_sideShape.iog.og[0].gco";
relationship "link" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_floor_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_door_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "PxrVolume1SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_metal_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_room_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_drain_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_emit_blue_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "PxrVolume2SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_handle_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_seat_sg.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "mat_seat_vent_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_floor_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_door_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "PxrVolume1SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_metal_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_room_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_drain_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_emit_blue_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "PxrVolume2SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_handle_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_seat_sg.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "mat_seat_vent_sg.message" ":defaultLightSet.message";
connectAttr "layerManager.dli[0]" "defaultLayer.id";
connectAttr "renderLayerManager.rlmi[0]" "defaultRenderLayer.rlid";
connectAttr ":PxrPathTracer.msg" ":rmanGlobals.ri_integrator";
connectAttr ":rmanDefaultDisplay.msg" ":rmanGlobals.displays[0]";
connectAttr "rmanDefaultBakeDisplay.msg" ":rmanBakingGlobals.displays[0]";
connectAttr ":bake_PxrPathTracer.msg" ":rmanBakingGlobals.ri_integrator";
connectAttr "diffuse.msg" "rmanDefaultBakeDisplay.displayChannels[0]";
connectAttr "a.msg" "rmanDefaultBakeDisplay.displayChannels[1]";
connectAttr "d_openexr.msg" "rmanDefaultBakeDisplay.displayType";
connectAttr "polyTweak5.out" "polyExtrudeFace2.ip";
connectAttr "doorShape.wm" "polyExtrudeFace2.mp";
connectAttr "polyPlane3.out" "polyTweak5.ip";
connectAttr "floor_diffuse.resultRGB" "mat_floor.diffuseColor";
connectAttr "PxrColorCorrect2.resultRGB" "mat_floor.specularFaceColor";
connectAttr "mat_floor.oc" "mat_floor_sg.rman__surface";
connectAttr "lambert2.oc" "mat_floor_sg.ss";
connectAttr "floorShape.iog" "mat_floor_sg.dsm" -na;
connectAttr "PxrDisplace1.oc" "mat_floor_sg.rman__displacement";
connectAttr "mat_floor_sg.msg" "materialInfo1.sg";
connectAttr "lambert2.msg" "materialInfo1.m";
connectAttr "PxrDispScalarLayer1.resultF" "PxrDisplace1.dispScalar";
connectAttr "PxrToFloat1.resultF" "PxrDispScalarLayer1.baseLayerDispScalar";
connectAttr "PxrManifold2D1.result" "floor_displace.manifold";
connectAttr "floor_displace.resultRGB" "PxrToFloat1.input";
connectAttr "d_openexr1.msg" ":rmanDefaultDisplay.displayType";
connectAttr "Ci.msg" ":rmanDefaultDisplay.displayChannels[0]";
connectAttr "a1.msg" ":rmanDefaultDisplay.displayChannels[1]";
connectAttr "polyTweak20.out" "polyExtrudeEdge11.ip";
connectAttr "blockerShape.wm" "polyExtrudeEdge11.mp";
connectAttr "polyPlane5.out" "polyTweak20.ip";
connectAttr "PxrColorCorrect1.resultRGB" "mat_door.singlescatterColor";
connectAttr "mat_door.oc" "mat_door_sg.rman__surface";
connectAttr "lambert3.oc" "mat_door_sg.ss";
connectAttr "doorShape.iog" "mat_door_sg.dsm" -na;
connectAttr "mat_door_sg.msg" "materialInfo2.sg";
connectAttr "lambert3.msg" "materialInfo2.m";
connectAttr "PxrVolume1.oc" "PxrVolume1SG.rman__surface";
connectAttr "lambert4.oc" "PxrVolume1SG.ss";
connectAttr "volume_fogShape.iog" "PxrVolume1SG.dsm" -na;
connectAttr "PxrVolume1SG.msg" "materialInfo3.sg";
connectAttr "lambert4.msg" "materialInfo3.m";
connectAttr "polyTweak21.out" "polyMapSew1.ip";
connectAttr "polyExtrudeFace2.out" "polyTweak21.ip";
connectAttr "polyMapSew1.out" "polyMapCut1.ip";
connectAttr "polyMapCut1.out" "polyMapCut2.ip";
connectAttr "polyMapCut2.out" "polyTweakUV1.ip";
connectAttr "polyTweakUV1.out" "polyLayoutUV1.ip";
connectAttr "polyLayoutUV1.out" "polyTweakUV2.ip";
connectAttr "polyTweakUV2.out" "polyLayoutUV2.ip";
connectAttr "polyLayoutUV2.out" "polyTweakUV3.ip";
connectAttr "polyTweakUV3.out" "polyLayoutUV3.ip";
connectAttr "polyLayoutUV3.out" "polyTweakUV4.ip";
connectAttr "polyTweakUV4.out" "polyLayoutUV4.ip";
connectAttr "polyLayoutUV4.out" "polyTweakUV5.ip";
connectAttr "mat_metal.oc" "mat_metal_sg.rman__surface";
connectAttr "lambert5.oc" "mat_metal_sg.ss";
connectAttr "room_ventShape.iog.og[0]" "mat_metal_sg.dsm" -na;
connectAttr "door_beamsShape.iog.og[0]" "mat_metal_sg.dsm" -na;
connectAttr "groupId22.msg" "mat_metal_sg.gn" -na;
connectAttr "groupId24.msg" "mat_metal_sg.gn" -na;
connectAttr "mat_metal_sg.msg" "materialInfo4.sg";
connectAttr "lambert5.msg" "materialInfo4.m";
connectAttr "mat_room.oc" "mat_room_sg.rman__surface";
connectAttr "lambert6.oc" "mat_room_sg.ss";
connectAttr "roomShape.iog.og[0]" "mat_room_sg.dsm" -na;
connectAttr "groupId25.msg" "mat_room_sg.gn" -na;
connectAttr "mat_room_sg.msg" "materialInfo5.sg";
connectAttr "lambert6.msg" "materialInfo5.m";
connectAttr "door_roughness.resultRGB" "PxrColorCorrect1.inputRGB";
connectAttr "floor_specular.resultRGB" "PxrColorCorrect2.inputRGB";
connectAttr "drain_mask.resultR" "mat_drain.presence";
connectAttr "mat_drain.oc" "mat_drain_sg.rman__surface";
connectAttr "lambert7.oc" "mat_drain_sg.ss";
connectAttr "drainShape.iog" "mat_drain_sg.dsm" -na;
connectAttr "mat_drain_sg.msg" "materialInfo6.sg";
connectAttr "lambert7.msg" "materialInfo6.m";
connectAttr "polyTweak28.out" "polyExtrudeEdge14.ip";
connectAttr "blockerShape.wm" "polyExtrudeEdge14.mp";
connectAttr "polyExtrudeEdge11.out" "polyTweak28.ip";
connectAttr "polyTweak29.out" "polyMergeVert3.ip";
connectAttr "blockerShape.wm" "polyMergeVert3.mp";
connectAttr "polyExtrudeEdge14.out" "polyTweak29.ip";
connectAttr "mat_emit_blue.oc" "mat_emit_blue_sg.rman__surface";
connectAttr "lambert8.oc" "mat_emit_blue_sg.ss";
connectAttr "light_Shape2.iog" "mat_emit_blue_sg.dsm" -na;
connectAttr "light_Shape1.iog" "mat_emit_blue_sg.dsm" -na;
connectAttr "mat_emit_blue_sg.msg" "materialInfo7.sg";
connectAttr "lambert8.msg" "materialInfo7.m";
connectAttr "PxrVolume2.oc" "PxrVolume2SG.rman__surface";
connectAttr "lambert9.oc" "PxrVolume2SG.ss";
connectAttr "light_fog_1Shape.iog" "PxrVolume2SG.dsm" -na;
connectAttr "light_fog_Shape2.iog" "PxrVolume2SG.dsm" -na;
connectAttr "PxrVolume2SG.msg" "materialInfo8.sg";
connectAttr "lambert9.msg" "materialInfo8.m";
connectAttr "handle_diffuse.resultRGB" "mat_handle.diffuseColor";
connectAttr "handle_diffuse.resultRGB" "mat_handle.glowColor";
connectAttr "mat_handle.oc" "mat_handle_sg.rman__surface";
connectAttr "lambert10.oc" "mat_handle_sg.ss";
connectAttr "door_handleShape.iog.og[0]" "mat_handle_sg.dsm" -na;
connectAttr "PxrDisplace2.oc" "mat_handle_sg.rman__displacement";
connectAttr "groupId23.msg" "mat_handle_sg.gn" -na;
connectAttr "mat_handle_sg.msg" "materialInfo11.sg";
connectAttr "lambert10.msg" "materialInfo11.m";
connectAttr "PxrToFloat3.resultF" "PxrDispScalarLayer2.baseLayerDispScalar";
connectAttr "handle_displace.resultRGB" "PxrToFloat3.input";
connectAttr "PxrDispScalarLayer2.resultF" "PxrDisplace2.dispScalar";
connectAttr ":time1.msg" "MayaNodeEditorSavedTabsInfo.tgi[0].ni[3].dn";
connectAttr ":PxrUnified.msg" "MayaNodeEditorSavedTabsInfo.tgi[0].ni[5].dn";
connectAttr ":PxrVCM.msg" "MayaNodeEditorSavedTabsInfo.tgi[0].ni[6].dn";
connectAttr "polySurfaceShape10.o" "polyMapSew5.ip";
connectAttr "polyMapSew5.out" "polyTweakUV13.ip";
connectAttr "polyTweakUV13.out" "polyPlanarProj2.ip";
connectAttr "seat_ventShape.wm" "polyPlanarProj2.mp";
connectAttr "polyPlanarProj2.out" "polyLayoutUV10.ip";
connectAttr "polyLayoutUV10.out" "polyPlanarProj3.ip";
connectAttr "seat_ventShape.wm" "polyPlanarProj3.mp";
connectAttr "polyPlanarProj3.out" "polyLayoutUV11.ip";
connectAttr "polyLayoutUV11.out" "polyLayoutUV12.ip";
connectAttr "polyLayoutUV12.out" "polyLayoutUV13.ip";
connectAttr "polyLayoutUV13.out" "polyLayoutUV14.ip";
connectAttr "polyLayoutUV14.out" "polyLayoutUV15.ip";
connectAttr "polyLayoutUV15.out" "polyTweakUV14.ip";
connectAttr "polyTweakUV14.out" "polyLayoutUV16.ip";
connectAttr "polyLayoutUV16.out" "polyTweakUV15.ip";
connectAttr "polyTweakUV15.out" "polyMapCut6.ip";
connectAttr "polyMapCut6.out" "polyTweakUV16.ip";
connectAttr "polySurfaceShape11.o" "polyMapSew6.ip";
connectAttr "polyMapSew6.out" "polyPlanarProj4.ip";
connectAttr "seat_woodShape.wm" "polyPlanarProj4.mp";
connectAttr "polyPlanarProj4.out" "polyTweakUV18.ip";
connectAttr "polyTweakUV18.out" "polyMapCut7.ip";
connectAttr "polyMapCut7.out" "polyTweakUV19.ip";
connectAttr "polyTweakUV19.out" "polyMapCut8.ip";
connectAttr "polyMapCut8.out" "polyMapCut9.ip";
connectAttr "polyMapCut9.out" "polyMapCut10.ip";
connectAttr "polyMapCut10.out" "polyMapCut11.ip";
connectAttr "polyMapCut11.out" "polyTweakUV20.ip";
connectAttr "polyTweakUV20.out" "polyLayoutUV17.ip";
connectAttr "polyLayoutUV17.out" "polyTweakUV21.ip";
connectAttr "polyTweakUV21.out" "polyMapCut12.ip";
connectAttr "polyMapCut12.out" "polyMapSew7.ip";
connectAttr "polyMapSew7.out" "polyMapCut13.ip";
connectAttr "polyMapCut13.out" "polyTweakUV22.ip";
connectAttr "polyTweakUV22.out" "polyLayoutUV18.ip";
connectAttr "polyLayoutUV18.out" "polyTweakUV23.ip";
connectAttr "polyTweakUV23.out" "polyLayoutUV19.ip";
connectAttr "polyLayoutUV19.out" "polyTweakUV24.ip";
connectAttr "polyTweakUV24.out" "polyMapCut14.ip";
connectAttr "polyMapCut14.out" "polyMapCut15.ip";
connectAttr "polyMapCut15.out" "polyMapCut16.ip";
connectAttr "polyMapCut16.out" "polyTweakUV25.ip";
connectAttr "polyTweakUV25.out" "polyLayoutUV20.ip";
connectAttr "polyLayoutUV20.out" "polyTweakUV26.ip";
connectAttr "polyTweakUV26.out" "polyLayoutUV21.ip";
connectAttr "polyLayoutUV21.out" "polyTweakUV27.ip";
connectAttr "polyTweakUV27.out" "polyLayoutUV22.ip";
connectAttr "polyLayoutUV22.out" "polyTweakUV28.ip";
connectAttr "polyTweakUV28.out" "deleteComponent11.ig";
connectAttr "deleteComponent11.og" "deleteComponent12.ig";
connectAttr "deleteComponent12.og" "deleteComponent13.ig";
connectAttr "deleteComponent13.og" "polyTweakUV29.ip";
connectAttr "seat_diffuse.resultRGB" "mat_seat.diffuseColor";
connectAttr "mat_seat.oc" "mat_seat_sg.rman__surface";
connectAttr "lambert11.oc" "mat_seat_sg.ss";
connectAttr "seat_woodShape.iog" "mat_seat_sg.dsm" -na;
connectAttr "mat_seat_sg.msg" "materialInfo13.sg";
connectAttr "lambert11.msg" "materialInfo13.m";
connectAttr "seat_vent_mask.resultR" "mat_seat_vent.presence";
connectAttr "mat_seat_vent.oc" "mat_seat_vent_sg.rman__surface";
connectAttr "lambert12.oc" "mat_seat_vent_sg.ss";
connectAttr "seat_ventShape.iog" "mat_seat_vent_sg.dsm" -na;
connectAttr "mat_seat_vent_sg.msg" "materialInfo14.sg";
connectAttr "lambert12.msg" "materialInfo14.m";
connectAttr ":defaultArnoldDisplayDriver.msg" ":defaultArnoldRenderOptions.drivers"
		 -na;
connectAttr ":defaultArnoldFilter.msg" ":defaultArnoldRenderOptions.filt";
connectAttr ":defaultArnoldDriver.msg" ":defaultArnoldRenderOptions.drvr";
connectAttr "mat_seat_vent_sg.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[0].dn"
		;
connectAttr "mat_seat_vent.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[1].dn"
		;
connectAttr "mat_floor_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_door_sg.pa" ":renderPartition.st" -na;
connectAttr "PxrVolume1SG.pa" ":renderPartition.st" -na;
connectAttr "mat_metal_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_room_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_drain_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_emit_blue_sg.pa" ":renderPartition.st" -na;
connectAttr "PxrVolume2SG.pa" ":renderPartition.st" -na;
connectAttr "mat_handle_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_seat_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_seat_vent_sg.pa" ":renderPartition.st" -na;
connectAttr "mat_floor.msg" ":defaultShaderList1.s" -na;
connectAttr "PxrDisplace1.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_door.msg" ":defaultShaderList1.s" -na;
connectAttr "PxrVolume1.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_metal.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_room.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_drain.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_emit_blue.msg" ":defaultShaderList1.s" -na;
connectAttr "PxrVolume2.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_handle.msg" ":defaultShaderList1.s" -na;
connectAttr "PxrDisplace2.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_seat.msg" ":defaultShaderList1.s" -na;
connectAttr "mat_seat_vent.msg" ":defaultShaderList1.s" -na;
connectAttr "defaultRenderLayer.msg" ":defaultRenderingList1.r" -na;
connectAttr ":rmanGlobals.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrPathTracer.msg" ":defaultRenderingList1.r" -na;
connectAttr ":rmanBakingGlobals.msg" ":defaultRenderingList1.r" -na;
connectAttr ":bake_PxrPathTracer.msg" ":defaultRenderingList1.r" -na;
connectAttr "d_openexr.msg" ":defaultRenderingList1.r" -na;
connectAttr ":rmanDefaultDisplay.msg" ":defaultRenderingList1.r" -na;
connectAttr "d_openexr1.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrUnified.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrVCM.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrVisualizer.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrDirectLighting.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrDefault.msg" ":defaultRenderingList1.r" -na;
connectAttr ":PxrOcclusion.msg" ":defaultRenderingList1.r" -na;
connectAttr "PxrDiskLightShape.msg" ":lightList1.l" -na;
connectAttr "PxrDiskLight1Shape.msg" ":lightList1.l" -na;
connectAttr "PxrSphereLightShape.msg" ":lightList1.l" -na;
connectAttr "PxrRectLightShape.msg" ":lightList1.l" -na;
connectAttr "PxrRectLight1Shape.msg" ":lightList1.l" -na;
connectAttr "PxrRectLight2Shape.msg" ":lightList1.l" -na;
connectAttr "PxrRectLight3Shape.msg" ":lightList1.l" -na;
connectAttr "floor_diffuse.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrDispScalarLayer1.msg" ":defaultTextureList1.tx" -na;
connectAttr "floor_displace.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrToFloat1.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrManifold2D1.msg" ":defaultTextureList1.tx" -na;
connectAttr "door_roughness.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrColorCorrect1.msg" ":defaultTextureList1.tx" -na;
connectAttr "floor_specular.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrColorCorrect2.msg" ":defaultTextureList1.tx" -na;
connectAttr "drain_mask.msg" ":defaultTextureList1.tx" -na;
connectAttr "handle_displace.msg" ":defaultTextureList1.tx" -na;
connectAttr "handle_diffuse.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrDispScalarLayer2.msg" ":defaultTextureList1.tx" -na;
connectAttr "PxrToFloat3.msg" ":defaultTextureList1.tx" -na;
connectAttr "seat_diffuse.msg" ":defaultTextureList1.tx" -na;
connectAttr "seat_vent_mask.msg" ":defaultTextureList1.tx" -na;
connectAttr "blockerShape.iog" ":initialShadingGroup.dsm" -na;
connectAttr "seat_sideShape.iog.og[0]" ":initialShadingGroup.dsm" -na;
connectAttr "groupId18.msg" ":initialShadingGroup.gn" -na;
connectAttr "PxrDiskLight.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrDiskLight1.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrSphereLight.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrRectLight.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrRectLight1.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrRectLight2.iog" ":defaultLightSet.dsm" -na;
connectAttr "PxrRectLight3.iog" ":defaultLightSet.dsm" -na;
// End of steamroom.ma
